import { useEffect, useRef } from 'react';
import { useWalletAuth } from '@/contexts/WalletAuthContext';
import { useTradingSignals } from './useTradingSignals';
import { useBotSettings } from './useBotSettings';
import { useWalletTradingBot } from './useWalletTradingBot';
import { useToast } from '@/hooks/use-toast';
import { useAudioNotifications } from './useAudioNotifications';

export const useAutoTrading = () => {
  const { walletAddress } = useWalletAuth();
  const { signals } = useTradingSignals();
  const { settings } = useBotSettings();
  const { recordTrade } = useWalletTradingBot();
  const { toast } = useToast();
  const { playTradeExecutedSound, playProfitSound } = useAudioNotifications();
  const processedSignalsRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (!settings?.auto_trading_enabled || !walletAddress || signals.length === 0) {
      return;
    }

    const processSignals = async () => {
      for (const signal of signals) {
        const signalKey = `${signal.coinId}-${signal.timestamp}`;
        
        if (processedSignalsRef.current.has(signalKey)) {
          continue;
        }

        // Check if signal meets confidence threshold
        if (signal.confidence < 70 || signal.recommendation === 'AVOID') {
          continue;
        }

        try {
          // Execute trade via Jupiter (will be handled by edge function)
          const tradeAmount = 10; // Calculate based on risk settings
          
          recordTrade({
            trade_type: 'buy',
            mode: 'auto',
            from_token: 'USDC',
            to_token: signal.token,
            amount_in: tradeAmount,
            price: signal.entryPrice,
            status: 'pending',
            ai_confidence: signal.confidence
          });

          processedSignalsRef.current.add(signalKey);
          playTradeExecutedSound();

          toast({
            title: '🤖 Auto-Trade Executed',
            description: `Bought ${signal.token} at $${signal.entryPrice.toFixed(4)}`
          });

        } catch (error) {
          console.error('Auto-trading error:', error);
        }
      }
    };

    processSignals();
  }, [signals, settings?.auto_trading_enabled, walletAddress]);

  return {
    isAutoTradingEnabled: settings?.auto_trading_enabled || false
  };
};
