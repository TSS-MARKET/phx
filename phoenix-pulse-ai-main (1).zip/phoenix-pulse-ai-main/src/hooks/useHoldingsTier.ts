import { useState, useEffect } from "react";
import { HoldingTier } from "@/components/HoldingsVerification";
import { supabase } from "@/integrations/supabase/client";

export const useHoldingsTier = () => {
  const [tier, setTier] = useState<HoldingTier>("none");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadTierFromDatabase();
  }, []);

  const loadTierFromDatabase = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        setTier("none");
        setIsLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from("user_tiers")
        .select("tier")
        .eq("user_id", user.id)
        .single();

      if (error) {
        if (error.code === "PGRST116") {
          // No tier record exists, create one
          await supabase.from("user_tiers").insert({
            user_id: user.id,
            tier: "none",
          });
          setTier("none");
        }
      } else if (data) {
        setTier(data.tier as HoldingTier);
      }
    } catch (error) {
      console.error("Error loading tier:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateTier = async (newTier: HoldingTier) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) return;

      const { error } = await supabase
        .from("user_tiers")
        .upsert({
          user_id: user.id,
          tier: newTier,
        });

      if (error) throw error;

      setTier(newTier);
    } catch (error) {
      console.error("Error updating tier:", error);
    }
  };

  const hasAccess = (requiredTier: HoldingTier): boolean => {
    const tierLevels = { none: 0, basic: 1, premium: 2, elite: 3 };
    return tierLevels[tier] >= tierLevels[requiredTier];
  };

  return { tier, updateTier, hasAccess, isLoading };
};
