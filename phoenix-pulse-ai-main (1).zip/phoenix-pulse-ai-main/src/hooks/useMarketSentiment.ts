import { useQuery } from "@tanstack/react-query";
import { useGlobalMarketData } from "./useCoinGecko";
import { useLunarCrush } from "./useLunarCrush";

export const useMarketSentiment = () => {
  const { data: globalData } = useGlobalMarketData();
  const { data: socialData } = useLunarCrush({ endpoint: 'assets' });

  return useQuery({
    queryKey: ['market-sentiment', globalData, socialData],
    queryFn: async () => {
      // Calculate sentiment score from multiple sources
      let sentimentScore = 50; // Neutral baseline

      // Factor 1: Market cap change (30% weight)
      if (globalData?.data?.market_cap_change_percentage_24h_usd) {
        const marketChange = globalData.data.market_cap_change_percentage_24h_usd;
        sentimentScore += (marketChange / 10) * 30;
      }

      // Factor 2: Fear & Greed approximation (25% weight)
      // Derived from Bitcoin dominance and volume changes
      if (globalData?.data?.market_cap_percentage?.btc) {
        const btcDom = globalData.data.market_cap_percentage.btc;
        if (btcDom > 50) sentimentScore -= 5; // High BTC dominance = fear
        else if (btcDom < 40) sentimentScore += 10; // Low BTC dominance = greed
      }

      // Factor 3: Social sentiment (25% weight)
      if (socialData?.data) {
        const topCoins = socialData.data.slice(0, 10);
        const avgSocial = topCoins.reduce((sum: number, coin: any) => 
          sum + (coin.social_score || 50), 0) / topCoins.length;
        sentimentScore += ((avgSocial - 50) / 50) * 25;
      }

      // Factor 4: Volume trends (20% weight)
      if (globalData?.data?.total_volume_change_24h_usd) {
        const volumeChange = globalData.data.total_volume_change_24h_usd;
        if (volumeChange > 0) sentimentScore += 10;
        else sentimentScore -= 5;
      }

      // Normalize to 0-100 range
      sentimentScore = Math.max(0, Math.min(100, sentimentScore));

      // Determine sentiment label
      let label = "Neutral";
      let color = "#FFD700";
      
      if (sentimentScore >= 75) {
        label = "Extreme Greed";
        color = "#10B981";
      } else if (sentimentScore >= 60) {
        label = "Greed";
        color = "#34D399";
      } else if (sentimentScore >= 40) {
        label = "Neutral";
        color = "#FFD700";
      } else if (sentimentScore >= 25) {
        label = "Fear";
        color = "#F59E0B";
      } else {
        label = "Extreme Fear";
        color = "#EF4444";
      }

      return {
        score: Math.round(sentimentScore),
        label,
        color,
        timestamp: new Date().toISOString()
      };
    },
    enabled: !!globalData,
    refetchInterval: 60000, // Refetch every minute
    staleTime: 30000
  });
};
