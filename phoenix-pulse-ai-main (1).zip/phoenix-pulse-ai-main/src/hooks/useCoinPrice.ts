import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const useCoinPrice = (coinId: string) => {
  return useQuery({
    queryKey: ["coin-price", coinId],
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke("coingecko-data", {
        body: {
          endpoint: "/simple/price",
          params: {
            ids: coinId.toLowerCase(),
            vs_currencies: "usd",
          },
        },
      });

      if (error) throw error;
      
      return data?.[coinId.toLowerCase()]?.usd || 0;
    },
    staleTime: 30000, // 30 seconds
    refetchInterval: 60000, // Refetch every 60 seconds
    enabled: !!coinId,
  });
};
