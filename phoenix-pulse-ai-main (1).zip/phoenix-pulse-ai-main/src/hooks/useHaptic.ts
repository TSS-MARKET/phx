import { useCallback } from 'react';

type HapticPattern = 'light' | 'medium' | 'heavy' | 'success' | 'error';

export const useHaptic = () => {
  const triggerHaptic = useCallback((pattern: HapticPattern = 'light') => {
    // Check if the device supports vibration
    if (!navigator.vibrate) return;

    // Define vibration patterns for different feedback types
    const patterns = {
      light: [10],
      medium: [20],
      heavy: [30],
      success: [10, 50, 10],
      error: [30, 100, 30],
    };

    try {
      navigator.vibrate(patterns[pattern]);
    } catch (error) {
      console.warn('Haptic feedback failed:', error);
    }
  }, []);

  return { triggerHaptic };
};
