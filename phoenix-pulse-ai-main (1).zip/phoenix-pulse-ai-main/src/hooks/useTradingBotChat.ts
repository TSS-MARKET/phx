import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useWalletAuth } from '@/contexts/WalletAuthContext';
import { useToast } from '@/hooks/use-toast';

export interface ChatMessage {
  role: 'user' | 'bot';
  text: string;
  timestamp: Date;
}

export const useTradingBotChat = () => {
  const { walletAddress } = useWalletAuth();
  const { toast } = useToast();
  const [messages, setMessages] = useState<ChatMessage[]>([
    { 
      role: 'bot', 
      text: '🤖 Phoenix AI ready. Send commands like "Buy SOL $100" or "Set trailing SL 7%"',
      timestamp: new Date()
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);

  const parseCommand = (message: string): { command: string; params: any } | null => {
    const msg = message.toLowerCase().trim();

    // Buy patterns: "buy bonk now", "buy 100 bonk", "buy bonk with entry at 0.00001"
    const buyMatch = msg.match(/buy\s+(\w+)(?:\s+(\d+\.?\d*))?(?:\s+(?:with\s+entry\s+at|at)\s+\$?(\d+\.?\d*))?(?:\s+tp\s*:?\s*\$?(\d+\.?\d*))?(?:\s+sl\s*:?\s*\$?(\d+\.?\d*))?/);
    if (buyMatch) {
      return {
        command: 'buy',
        params: {
          token: buyMatch[1].toUpperCase(),
          amount: buyMatch[2] ? parseFloat(buyMatch[2]) : 100,
          entry: buyMatch[3] ? parseFloat(buyMatch[3]) : null,
          takeProfit: buyMatch[4] ? parseFloat(buyMatch[4]) : null,
          stopLoss: buyMatch[5] ? parseFloat(buyMatch[5]) : null
        }
      };
    }

    // Sell patterns: "sell bonk", "sell 50 bonk", "sell bonk at 0.00002"
    const sellMatch = msg.match(/sell\s+(\w+)(?:\s+(\d+\.?\d*))?(?:\s+at\s+\$?(\d+\.?\d*))?/);
    if (sellMatch) {
      return {
        command: 'sell',
        params: {
          token: sellMatch[1].toUpperCase(),
          amount: sellMatch[2] ? parseFloat(sellMatch[2]) : null,
          price: sellMatch[3] ? parseFloat(sellMatch[3]) : null
        }
      };
    }

    // Trailing stop loss: "set trailing sl on sol 7%", "trailing stop 5% on bonk"
    const trailingMatch = msg.match(/(?:set\s+)?trailing\s+(?:sl|stop\s*loss)\s+(?:on\s+)?(\w+)\s+(\d+\.?\d*)%?/);
    if (trailingMatch) {
      return {
        command: 'trailing_sl',
        params: {
          token: trailingMatch[1].toUpperCase(),
          percentage: parseFloat(trailingMatch[2])
        }
      };
    }

    // Take profit: "set tp for sol at 150", "take profit bonk 0.00003"
    const tpMatch = msg.match(/(?:set\s+)?(?:tp|take\s*profit)\s+(?:for\s+)?(\w+)\s+(?:at\s+)?\$?(\d+\.?\d*)/);
    if (tpMatch) {
      return {
        command: 'take_profit',
        params: {
          token: tpMatch[1].toUpperCase(),
          price: parseFloat(tpMatch[2])
        }
      };
    }

    return null;
  };

  const sendMessage = async (userMessage: string) => {
    if (!userMessage.trim() || !walletAddress) return;

    // Add user message
    const userMsg: ChatMessage = {
      role: 'user',
      text: userMessage,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    try {
      // Try to parse command first
      const parsed = parseCommand(userMessage);

      if (parsed) {
        // Generate confirmation message
        let confirmMsg = '';
        if (parsed.command === 'buy') {
          confirmMsg = `🤖 Executing BUY order for ${parsed.params.token}\n💰 Amount: ${parsed.params.amount} USDC\n${parsed.params.entry ? `📍 Entry: $${parsed.params.entry}` : '📍 Entry: Market Price'}\n${parsed.params.takeProfit ? `🎯 TP: $${parsed.params.takeProfit}` : ''}\n${parsed.params.stopLoss ? `🛡️ SL: $${parsed.params.stopLoss}` : ''}\n\nConfirm transaction in your wallet...`;
        } else if (parsed.command === 'sell') {
          confirmMsg = `🤖 Executing SELL order for ${parsed.params.token}\n${parsed.params.amount ? `💰 Amount: ${parsed.params.amount}` : '💰 Amount: All holdings'}\n${parsed.params.price ? `💵 Price: $${parsed.params.price}` : '💵 Price: Market'}\n\nConfirm transaction in your wallet...`;
        } else if (parsed.command === 'trailing_sl') {
          confirmMsg = `🤖 Setting trailing stop loss\n🪙 Token: ${parsed.params.token}\n📉 Trail: ${parsed.params.percentage}%\n\n✅ Will auto-sell if price drops ${parsed.params.percentage}% from peak.`;
        } else if (parsed.command === 'take_profit') {
          confirmMsg = `🤖 Setting take profit\n🪙 Token: ${parsed.params.token}\n🎯 Target: $${parsed.params.price}\n\n✅ Will auto-sell when target is reached.`;
        }

        const botMsg: ChatMessage = {
          role: 'bot',
          text: confirmMsg,
          timestamp: new Date()
        };
        setMessages(prev => [...prev, botMsg]);
        setIsLoading(false);
        return;
      }

      // If not a command, send to AI chatbot
      const { data, error } = await supabase.functions.invoke('trading-bot-chat', {
        body: {
          message: userMessage,
          walletAddress
        }
      });

      if (error) throw error;

      // Add bot response
      const botMsg: ChatMessage = {
        role: 'bot',
        text: data.response,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMsg]);

    } catch (error: any) {
      console.error('Chat error:', error);
      
      let errorMessage = '❌ Failed to process command. Please try again.';
      
      if (error.message?.includes('subscription')) {
        errorMessage = '⚠️ Elite subscription required to use AI Trading Bot.';
      } else if (error.message?.includes('Rate limit')) {
        errorMessage = '⏳ Rate limit reached. Please wait a moment and try again.';
      }

      const errorMsg: ChatMessage = {
        role: 'bot',
        text: errorMessage,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMsg]);

      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return {
    messages,
    isLoading,
    sendMessage
  };
};
