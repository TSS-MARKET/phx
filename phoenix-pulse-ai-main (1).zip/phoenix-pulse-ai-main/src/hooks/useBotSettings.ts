import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useWalletAuth } from '@/contexts/WalletAuthContext';
import { useToast } from '@/hooks/use-toast';

export interface BotSettings {
  risk_per_trade: number;
  max_daily_trades: number;
  slippage_tolerance: number;
  auto_trading_enabled: boolean;
  trailing_stop_enabled: boolean;
  trailing_stop_percentage: number;
  take_profit_percentage: number;
  stop_loss_percentage: number;
}

export const useBotSettings = () => {
  const { walletAddress } = useWalletAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useQuery({
    queryKey: ['bot-settings', walletAddress],
    queryFn: async () => {
      if (!walletAddress) return null;

      const { data, error } = await supabase
        .from('bot_settings')
        .select('*')
        .eq('user_id', walletAddress)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return data as BotSettings | null;
    },
    enabled: !!walletAddress
  });

  const updateSettings = useMutation({
    mutationFn: async (newSettings: Partial<BotSettings>) => {
      if (!walletAddress) throw new Error('No wallet connected');

      const { data, error } = await supabase
        .from('bot_settings')
        .upsert({
          user_id: walletAddress,
          ...newSettings,
          updated_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bot-settings', walletAddress] });
      toast({
        title: '⚙️ Settings Updated',
        description: 'PHX Hydra bot settings saved'
      });
    },
    onError: (error) => {
      console.error('Settings update error:', error);
      toast({
        title: 'Update Failed',
        description: 'Could not save bot settings',
        variant: 'destructive'
      });
    }
  });

  return {
    settings,
    isLoading,
    updateSettings: updateSettings.mutate
  };
};
