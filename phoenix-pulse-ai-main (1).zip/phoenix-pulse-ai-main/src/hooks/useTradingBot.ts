import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface TradeSignal {
  recommendation: 'strong_buy' | 'buy' | 'hold' | 'avoid';
  aiConfidence: number;
  reasoning: string;
  entryPrice: number;
  targetPrice: number;
  stopLoss: number;
  riskLevel: 'low' | 'medium' | 'high';
}

export interface TradeHistory {
  id: string;
  trade_type: 'buy' | 'sell';
  mode: 'signal' | 'auto';
  from_token: string;
  to_token: string;
  amount_in: number;
  amount_out?: number;
  price?: number;
  transaction_signature?: string;
  status: 'pending' | 'completed' | 'failed';
  profit_loss?: number;
  profit_loss_percentage?: number;
  ai_confidence?: number;
  executed_at: string;
}

export interface TradingAnalytics {
  total_trades: number;
  winning_trades: number;
  losing_trades: number;
  total_profit_loss: number;
  average_roi: number;
  best_trade_profit: number;
  worst_trade_loss: number;
  total_volume_traded: number;
}

export const useTradingBot = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tradeHistory, isLoading: isLoadingHistory } = useQuery({
    queryKey: ["trade-history"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data, error } = await supabase
        .from("trading_history")
        .select("*")
        .eq("user_id", user.id)
        .order("executed_at", { ascending: false })
        .limit(50);

      if (error) throw error;
      return data as TradeHistory[];
    },
  });

  const { data: analytics, isLoading: isLoadingAnalytics } = useQuery({
    queryKey: ["trading-analytics"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;

      const { data, error } = await supabase
        .from("user_trading_analytics")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (error && error.code !== "PGRST116") throw error;
      return data as TradingAnalytics | null;
    },
  });

  const getTradeSignal = async (fromToken: string, toToken: string, amount: number): Promise<TradeSignal> => {
    const { data, error } = await supabase.functions.invoke('trading-signals', {
      body: {
        action: 'analyzeTrade',
        fromToken,
        toToken,
        amount,
      },
    });

    if (error) throw error;
    return data;
  };

  const recordTrade = useMutation({
    mutationFn: async (trade: {
      trade_type: 'buy' | 'sell';
      mode: 'signal' | 'auto';
      from_token: string;
      to_token: string;
      amount_in: number;
      amount_out?: number;
      price?: number;
      transaction_signature?: string;
      status: 'pending' | 'completed' | 'failed';
      profit_loss?: number;
      ai_confidence?: number;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase
        .from("trading_history")
        .insert({
          user_id: user.id,
          ...trade,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["trade-history"] });
      queryClient.invalidateQueries({ queryKey: ["trading-analytics"] });
      toast({
        title: "Trade Recorded",
        description: "Your trade has been recorded successfully.",
      });
    },
  });

  return {
    tradeHistory,
    analytics,
    isLoadingHistory,
    isLoadingAnalytics,
    getTradeSignal,
    recordTrade: recordTrade.mutate,
  };
};