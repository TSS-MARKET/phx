import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useWalletAuth } from '@/contexts/WalletAuthContext';
import { useToast } from '@/hooks/use-toast';

export interface PriceAlert {
  id: string;
  token_symbol: string;
  coin_id: string;
  alert_type: 'above' | 'below';
  target_price: number;
  current_price: number;
  is_active: boolean;
  created_at: string;
}

export const usePriceAlerts = () => {
  const { walletAddress } = useWalletAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: alerts, isLoading } = useQuery({
    queryKey: ['price-alerts', walletAddress],
    queryFn: async () => {
      if (!walletAddress) return [];

      const { data, error } = await supabase
        .from('price_alerts')
        .select('*')
        .eq('user_id', walletAddress)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as PriceAlert[];
    },
    enabled: !!walletAddress
  });

  const createAlert = useMutation({
    mutationFn: async (alert: {
      token_symbol: string;
      coin_id: string;
      alert_type: 'above' | 'below';
      target_price: number;
      current_price: number;
    }) => {
      if (!walletAddress) throw new Error('No wallet connected');

      const { data, error } = await supabase
        .from('price_alerts')
        .insert({
          user_id: walletAddress,
          ...alert
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['price-alerts'] });
      toast({
        title: '🔔 Alert Created',
        description: 'You will be notified when price target is reached'
      });
    }
  });

  const deleteAlert = useMutation({
    mutationFn: async (alertId: string) => {
      const { error } = await supabase
        .from('price_alerts')
        .delete()
        .eq('id', alertId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['price-alerts'] });
      toast({
        title: 'Alert Deleted',
        description: 'Price alert removed'
      });
    }
  });

  return {
    alerts: alerts || [],
    isLoading,
    createAlert: createAlert.mutate,
    deleteAlert: deleteAlert.mutate
  };
};
