import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { usePriceAlerts } from './usePriceAlerts';
import { useCoinMarketData } from './useCoinMarketData';
import { useAudioNotifications } from './useAudioNotifications';
import { useToast } from './use-toast';
import { supabase } from '@/integrations/supabase/client';

export const usePriceMonitoring = () => {
  const { alerts } = usePriceAlerts();
  const { toast } = useToast();
  const { playTakeProfitSound } = useAudioNotifications();

  // Check alerts every minute
  useQuery({
    queryKey: ['price-monitoring', alerts],
    queryFn: async () => {
      if (!alerts || alerts.length === 0) return null;

      for (const alert of alerts) {
        try {
          // Fetch current price from CoinGecko
          const { data, error } = await supabase.functions.invoke('coingecko-data', {
            body: {
              endpoint: '/simple/price',
              params: {
                ids: alert.coin_id,
                vs_currencies: 'usd'
              }
            }
          });

          if (error) throw error;

          const currentPrice = data?.[alert.coin_id]?.usd;
          if (!currentPrice) continue;

          // Check if alert should trigger
          let shouldTrigger = false;
          if (alert.alert_type === 'above' && currentPrice >= alert.target_price) {
            shouldTrigger = true;
          } else if (alert.alert_type === 'below' && currentPrice <= alert.target_price) {
            shouldTrigger = true;
          }

          if (shouldTrigger) {
            // Trigger alert
            await supabase
              .from('price_alerts')
              .update({ 
                is_active: false, 
                triggered_at: new Date().toISOString(),
                current_price: currentPrice
              })
              .eq('id', alert.id);

            // Play sound and show toast
            playTakeProfitSound();
            toast({
              title: '🎯 Price Alert Triggered!',
              description: `${alert.token_symbol} hit $${currentPrice.toFixed(6)} (Target: $${alert.target_price.toFixed(6)})`,
              duration: 10000
            });
          }
        } catch (error) {
          console.error('Price monitoring error:', error);
        }
      }

      return Date.now();
    },
    enabled: alerts.length > 0,
    refetchInterval: 60000, // Check every minute
    staleTime: 50000
  });

  return {
    isMonitoring: alerts.length > 0
  };
};
