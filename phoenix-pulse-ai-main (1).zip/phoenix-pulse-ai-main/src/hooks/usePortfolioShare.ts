import { useToast } from "@/hooks/use-toast";
import html2canvas from "html2canvas";
import { Facebook, Linkedin, MessageCircle, Instagram } from "lucide-react";

interface PortfolioShareData {
  totalValue: number;
  totalProfit: number;
  profitPercentage: number;
  topPerformer?: string;
}

export interface PnLCardData {
  totalValue: number;
  totalInvested: number;
  totalProfit: number;
  profitPercentage: number;
  realizedPnL?: number;
  unrealizedPnL?: number;
  sparklineData?: number[];
}

export const usePortfolioShare = () => {
  const { toast } = useToast();

  const generateShareImage = async (elementId: string): Promise<string | null> => {
    try {
      const element = document.getElementById(elementId);
      if (!element) {
        throw new Error("Element not found");
      }

      const canvas = await html2canvas(element, {
        backgroundColor: "#000000",
        scale: 2,
        logging: false,
        useCORS: true,
      });

      return canvas.toDataURL("image/png");
    } catch (error) {
      console.error("Error generating share image:", error);
      toast({
        title: "Error",
        description: "Failed to generate share image",
        variant: "destructive",
      });
      return null;
    }
  };

  const shareToTwitter = (data: PortfolioShareData) => {
    const text = `📊 My Portfolio Performance\n💰 Total: $${data.totalValue.toLocaleString()}\n📈 P/L: ${data.profitPercentage >= 0 ? '+' : ''}${data.profitPercentage.toFixed(2)}%\n\nTrack your crypto with Phoenix AI! 🚀`;
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
  };

  const shareToLinkedIn = (data: PortfolioShareData) => {
    const text = `Portfolio Update: ${data.profitPercentage >= 0 ? '+' : ''}${data.profitPercentage.toFixed(2)}% return on $${data.totalValue.toLocaleString()} portfolio`;
    const url = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}`;
    window.open(url, "_blank");
  };

  const shareToFacebook = (data: PortfolioShareData) => {
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`;
    window.open(url, "_blank");
  };

  const shareToWhatsApp = (data: PortfolioShareData) => {
    const text = `📊 My Portfolio Performance\n💰 Total: $${data.totalValue.toLocaleString()}\n📈 P/L: ${data.profitPercentage >= 0 ? '+' : ''}${data.profitPercentage.toFixed(2)}%\n\nTrack your crypto with Phoenix AI! 🚀`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
  };

  const shareToInstagram = () => {
    toast({
      title: "Instagram Sharing",
      description: "Download the image and share it on Instagram",
    });
  };

  const shareToTelegram = (data: PortfolioShareData) => {
    const text = `📊 My Portfolio Performance\n💰 Total: $${data.totalValue.toLocaleString()}\n📈 P/L: ${data.profitPercentage >= 0 ? '+' : ''}${data.profitPercentage.toFixed(2)}%\n\nTrack your crypto with Phoenix AI! 🚀`;
    const url = `https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
  };

  const copyToClipboard = async (data: PortfolioShareData) => {
    const text = `📊 My Portfolio Performance\n💰 Total Value: $${data.totalValue.toLocaleString()}\n📈 Total P/L: ${data.profitPercentage >= 0 ? '+' : ''}${data.profitPercentage.toFixed(2)}% ($${Math.abs(data.totalProfit).toLocaleString()})\n\nManaged with Phoenix AI`;
    
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: "Portfolio summary copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const downloadImage = async (elementId: string, filename: string = "portfolio-performance.png") => {
    const dataUrl = await generateShareImage(elementId);
    if (!dataUrl) return;

    const link = document.createElement("a");
    link.download = filename;
    link.href = dataUrl;
    link.click();

    toast({
      title: "Downloaded!",
      description: "Portfolio image saved successfully",
    });
  };

  return {
    shareToTwitter,
    shareToLinkedIn,
    shareToFacebook,
    shareToWhatsApp,
    shareToInstagram,
    shareToTelegram,
    copyToClipboard,
    downloadImage,
    generateShareImage,
  };
};
