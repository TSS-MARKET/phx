import { useEffect, useState } from 'react';

interface LiveStats {
  activeTraders: number;
  signalsGenerated: number;
  successRate: number;
  tradingVolume: number;
}

const STORAGE_KEY = 'phoenix_live_stats';
const LAST_UPDATE_KEY = 'phoenix_stats_last_update';

const getInitialStats = (): LiveStats => {
  const stored = localStorage.getItem(STORAGE_KEY);
  const lastUpdate = localStorage.getItem(LAST_UPDATE_KEY);
  
  if (stored && lastUpdate) {
    const stats = JSON.parse(stored);
    const timePassed = Date.now() - parseInt(lastUpdate);
    const secondsPassed = Math.floor(timePassed / 1000);
    
    // Calculate increments based on time passed (reduced by half)
    const traderIncrements = Math.floor(secondsPassed) * (Math.random() * 2 + 2); // 2-4 per second
    const signalIncrements = Math.floor(secondsPassed / 10) * (Math.random() * 1 + 1); // 1-2 per 10 seconds
    const volumeIncrements = Math.floor(secondsPassed) * (Math.random() * 428 + 65); // 65-493 per second
    
    return {
      activeTraders: Math.floor(stats.activeTraders + traderIncrements),
      signalsGenerated: Math.floor(stats.signalsGenerated + signalIncrements),
      successRate: 91.83,
      tradingVolume: Math.floor(stats.tradingVolume + volumeIncrements)
    };
  }
  
  return {
    activeTraders: 12713,
    signalsGenerated: 719,
    successRate: 91.83,
    tradingVolume: 37898
  };
};

export const useLiveStats = () => {
  const [stats, setStats] = useState<LiveStats>(getInitialStats());

  useEffect(() => {
    // Update traders every 6 seconds (doubled delay)
    const traderInterval = setInterval(() => {
      setStats(prev => {
        const increment = Math.floor(Math.random() * 2) + 2; // 2-4 (halved)
        const newStats = { ...prev, activeTraders: Math.floor(prev.activeTraders + increment) };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newStats));
        localStorage.setItem(LAST_UPDATE_KEY, Date.now().toString());
        return newStats;
      });
    }, 6000);

    // Update signals every 10 seconds (doubled delay, 1-2 increment)
    const signalInterval = setInterval(() => {
      setStats(prev => {
        const increment = Math.floor(Math.random() * 1) + 1; // 1-2 (halved)
        const newStats = { ...prev, signalsGenerated: Math.floor(prev.signalsGenerated + increment) };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newStats));
        localStorage.setItem(LAST_UPDATE_KEY, Date.now().toString());
        return newStats;
      });
    }, 10000);

    // Update volume every 8 seconds (doubled delay)
    const volumeInterval = setInterval(() => {
      setStats(prev => {
        const increment = Math.floor(Math.random() * 428) + 65; // 65-493 (halved)
        const newStats = { ...prev, tradingVolume: Math.floor(prev.tradingVolume + increment) };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newStats));
        localStorage.setItem(LAST_UPDATE_KEY, Date.now().toString());
        return newStats;
      });
    }, 8000);

    return () => {
      clearInterval(traderInterval);
      clearInterval(signalInterval);
      clearInterval(volumeInterval);
    };
  }, []);

  return stats;
};
