import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface CoinGeckoParams {
  endpoint: string;
  params?: Record<string, string>;
}

export const useCoinGecko = (endpoint: string, params?: Record<string, string>) => {
  return useQuery({
    queryKey: ["coingecko", endpoint, params],
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke("coingecko-data", {
        body: { endpoint, params },
      });

      if (error) throw error;
      return data;
    },
    staleTime: 300000, // 5 minutes
    refetchInterval: 600000, // Refetch every 10 minutes
  });
};

export const useTopCoins = () => {
  return useCoinGecko("/coins/markets", {
    vs_currency: "usd",
    order: "market_cap_desc",
    per_page: "10",
    page: "1",
    sparkline: "false",
  });
};

export const useTrendingCoins = () => {
  return useCoinGecko("/search/trending");
};

export const useGlobalMarketData = () => {
  return useCoinGecko("/global");
};
