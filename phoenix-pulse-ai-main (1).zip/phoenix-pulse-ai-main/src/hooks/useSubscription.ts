import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export type SubscriptionTier = 'free' | 'pro' | 'elite';
export type SubscriptionStatus = 'active' | 'cancelled' | 'expired' | 'trialing';

export interface Subscription {
  id: string;
  user_id: string;
  tier: SubscriptionTier;
  status: SubscriptionStatus;
  stripe_subscription_id?: string;
  stripe_customer_id?: string;
  current_period_start?: string;
  current_period_end?: string;
  cancel_at_period_end: boolean;
  daily_analysis_count: number;
  last_analysis_reset: string;
  created_at: string;
  updated_at: string;
}

export const useSubscription = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: subscription, isLoading } = useQuery({
    queryKey: ["subscription"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;

      const { data, error } = await supabase
        .from("user_subscriptions")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (error && error.code !== "PGRST116") throw error;
      
      // Create default subscription if doesn't exist
      if (!data) {
        const { data: newSub, error: createError } = await supabase
          .from("user_subscriptions")
          .insert({
            user_id: user.id,
            tier: 'free',
            status: 'active',
          })
          .select()
          .single();

        if (createError) throw createError;
        return newSub;
      }

      return data;
    },
    staleTime: 30000,
  });

  const canAccessFeature = (feature: string): boolean => {
    if (!subscription) return false;

    const tier = subscription.tier;
    const status = subscription.status;

    if (status !== 'active') return false;

    switch (feature) {
      case 'unlimited_analysis':
      case 'sentiment_tracker':
      case 'portfolio_insights':
        return tier === 'pro' || tier === 'elite';
      case 'memecoin_hype':
      case 'phoenix_daily_3':
      case 'trading_bot':
      case 'alerts':
      case 'token_creator':
        return tier === 'elite';
      default:
        return false;
    }
  };

  const canAnalyzeCoin = (): boolean => {
    if (!subscription) return false;
    if (subscription.tier !== 'free') return true;
    return subscription.daily_analysis_count < 1;
  };

  const incrementAnalysisCount = useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase
        .from("user_subscriptions")
        .update({
          daily_analysis_count: (subscription?.daily_analysis_count || 0) + 1,
        })
        .eq("user_id", user.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["subscription"] });
    },
  });

  const upgradeTier = useMutation({
    mutationFn: async (newTier: SubscriptionTier) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase
        .from("user_subscriptions")
        .update({ tier: newTier })
        .eq("user_id", user.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["subscription"] });
      toast({
        title: "Subscription Updated",
        description: "Your subscription has been upgraded successfully!",
      });
    },
  });

  return {
    subscription,
    isLoading,
    canAccessFeature,
    canAnalyzeCoin,
    incrementAnalysisCount: incrementAnalysisCount.mutate,
    upgradeTier: upgradeTier.mutate,
  };
};