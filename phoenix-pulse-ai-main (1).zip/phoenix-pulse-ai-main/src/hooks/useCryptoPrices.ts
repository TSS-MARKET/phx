import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface PriceData {
  [symbol: string]: {
    usd: number;
  };
}

export const useCryptoPrices = (symbols: string[]) => {
  return useQuery({
    queryKey: ["crypto-prices", symbols.join(",")],
    queryFn: async () => {
      if (symbols.length === 0) return {};
      
      const { data, error } = await supabase.functions.invoke("coingecko-data", {
        body: {
          endpoint: "/simple/price",
          params: {
            ids: symbols.map(s => s.toLowerCase()).join(","),
            vs_currencies: "usd",
          },
        },
      });

      if (error) throw error;
      
      // Convert CoinGecko IDs back to symbols
      const priceMap: PriceData = {};
      if (data) {
        Object.entries(data).forEach(([id, value]: [string, any]) => {
          const symbol = symbols.find(s => s.toLowerCase() === id);
          if (symbol) {
            priceMap[symbol.toUpperCase()] = value;
          }
        });
      }
      
      return priceMap;
    },
    staleTime: 30000, // 30 seconds
    refetchInterval: 60000, // Refetch every 60 seconds
    enabled: symbols.length > 0,
  });
};
