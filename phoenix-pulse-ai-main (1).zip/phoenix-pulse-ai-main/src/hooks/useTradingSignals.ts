import { useQuery } from '@tanstack/react-query';
import { useWalletAuth } from '@/contexts/WalletAuthContext';

export interface TradingSignal {
  token: string;
  symbol: string;
  coinId: string;
  entryPrice: number;
  takeProfit: number;
  stopLoss: number;
  confidence: number;
  timestamp: string;
  recommendation: string;
  reasoning?: string;
  marketData?: {
    volume24h: number;
    marketCap: number;
    priceChange24h: number;
    priceChange7d: number;
  };
}

export const useTradingSignals = () => {
  const { walletAddress } = useWalletAuth();

  const { data: signals, isLoading } = useQuery({
    queryKey: ['trading-signals', walletAddress],
    queryFn: async () => {
      if (!walletAddress) return [];

      const { supabase } = await import('@/integrations/supabase/client');

      // Fetch real AI-powered signals
      const tokens = [
        { coinId: 'solana', symbol: 'SOL' },
        { coinId: 'bonk', symbol: 'BONK' },
        { coinId: 'jupiter-exchange-solana', symbol: 'JUP' },
        { coinId: 'dogwifcoin', symbol: 'WIF' },
        { coinId: 'jito-governance-token', symbol: 'JTO' }
      ];

      const { data, error } = await supabase.functions.invoke('ai-trading-signals', {
        body: { tokens }
      });

      if (error) {
        console.error('Error fetching AI signals:', error);
        return [];
      }

      return data.signals as TradingSignal[];
    },
    enabled: !!walletAddress,
    refetchInterval: 120000, // Refetch every 2 minutes
    staleTime: 60000 // Consider data stale after 1 minute
  });

  return {
    signals: signals || [],
    isLoading
  };
};
