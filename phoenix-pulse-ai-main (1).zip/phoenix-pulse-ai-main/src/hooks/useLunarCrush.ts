import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface LunarCrushParams {
  endpoint?: string;
  symbol?: string;
}

export const useLunarCrush = (params?: LunarCrushParams) => {
  return useQuery({
    queryKey: ["lunarcrush", params],
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke("lunarcrush-social", {
        body: params || { endpoint: 'assets' },
      });

      if (error) throw error;
      return data;
    },
    staleTime: 60000, // 1 minute
    refetchInterval: 300000, // Refetch every 5 minutes
  });
};
