import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

export interface WatchlistItem {
  id: string;
  symbol: string;
  name: string;
  coinId: string;
  addedAt: string;
}

export const useWatchlist = () => {
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>(() => {
    const saved = localStorage.getItem("watchlist");
    return saved ? JSON.parse(saved) : [];
  });
  const { toast } = useToast();

  useEffect(() => {
    localStorage.setItem("watchlist", JSON.stringify(watchlist));
  }, [watchlist]);

  const addToWatchlist = (coin: {
    symbol: string;
    name: string;
    coinId: string;
  }) => {
    const exists = watchlist.some((item) => item.coinId === coin.coinId);
    if (exists) {
      toast({
        title: "Already in Watchlist",
        description: `${coin.symbol} is already in your watchlist`,
        variant: "destructive",
      });
      return;
    }

    const newItem: WatchlistItem = {
      id: Date.now().toString(),
      symbol: coin.symbol,
      name: coin.name,
      coinId: coin.coinId,
      addedAt: new Date().toISOString(),
    };

    setWatchlist((prev) => [...prev, newItem]);
    toast({
      title: "Added to Watchlist",
      description: `${coin.symbol} added successfully`,
    });
  };

  const removeFromWatchlist = (id: string) => {
    setWatchlist((prev) => prev.filter((item) => item.id !== id));
    toast({
      title: "Removed from Watchlist",
      description: "Coin removed from your watchlist",
    });
  };

  const isInWatchlist = (coinId: string) => {
    return watchlist.some((item) => item.coinId === coinId);
  };

  return {
    watchlist,
    addToWatchlist,
    removeFromWatchlist,
    isInWatchlist,
  };
};
