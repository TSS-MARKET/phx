import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface CryptoPanicParams {
  currencies?: string;
  filter?: 'rising' | 'hot' | 'bullish' | 'bearish';
}

export const useCryptoPanic = (params?: CryptoPanicParams) => {
  return useQuery({
    queryKey: ["cryptopanic", params],
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke("cryptopanic-news", {
        body: params || {},
      });

      if (error) throw error;
      return data;
    },
    staleTime: 28800000, // 8 hours - to conserve API quota (90 requests/month = ~3 per day)
    refetchInterval: 28800000, // Refetch every 8 hours to stay within quota
  });
};
