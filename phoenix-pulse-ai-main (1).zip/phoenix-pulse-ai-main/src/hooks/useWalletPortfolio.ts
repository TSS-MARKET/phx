import { useQuery } from '@tanstack/react-query';
import { useWalletAuth } from '@/contexts/WalletAuthContext';
import { useConnection, useWallet } from '@solana/wallet-adapter-react';
import { PublicKey } from '@solana/web3.js';
import { useCoinPrice } from './useCoinPrice';

export interface WalletHolding {
  token: string;
  symbol: string;
  coinId: string;
  balance: number;
  value: number;
  percentage: number;
}

export const useWalletPortfolio = () => {
  const { walletAddress } = useWalletAuth();
  const { connection } = useConnection();
  const { publicKey } = useWallet();

  // Fetch SOL price
  const { data: solPrice } = useCoinPrice('solana');
  const { data: bonkPrice } = useCoinPrice('bonk');
  const { data: jupPrice } = useCoinPrice('jupiter-exchange-solana');

  const { data: portfolio, isLoading } = useQuery({
    queryKey: ['wallet-portfolio', walletAddress, solPrice, bonkPrice, jupPrice],
    queryFn: async () => {
      if (!walletAddress || !publicKey) return null;

      try {
        // Get SOL balance
        const balance = await connection.getBalance(publicKey);
        const solBalance = balance / 1e9;
        
        const holdings: WalletHolding[] = [];
        let totalValue = 0;

        // SOL holding
        if (solBalance > 0 && solPrice) {
          const solValue = solBalance * solPrice;
          holdings.push({
            token: 'SOL',
            symbol: 'SOL',
            coinId: 'solana',
            balance: solBalance,
            value: solValue,
            percentage: 0
          });
          totalValue += solValue;
        }

        // Fetch SPL token accounts
        const TOKEN_PROGRAM_ID = new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA');
        const tokenAccounts = await connection.getParsedTokenAccountsByOwner(publicKey, {
          programId: TOKEN_PROGRAM_ID
        });

        // Known token mints
        const knownTokens: Record<string, { symbol: string; coinId: string; price?: number }> = {
          'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263': { symbol: 'BONK', coinId: 'bonk', price: bonkPrice },
          'JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN': { symbol: 'JUP', coinId: 'jupiter-exchange-solana', price: jupPrice }
        };

        for (const account of tokenAccounts.value) {
          const parsedInfo = account.account.data.parsed.info;
          const mint = parsedInfo.mint;
          const tokenAmount = parsedInfo.tokenAmount;
          
          if (knownTokens[mint] && tokenAmount.uiAmount > 0) {
            const token = knownTokens[mint];
            const value = token.price ? tokenAmount.uiAmount * token.price : 0;
            
            holdings.push({
              token: token.symbol,
              symbol: token.symbol,
              coinId: token.coinId,
              balance: tokenAmount.uiAmount,
              value,
              percentage: 0
            });
            totalValue += value;
          }
        }

        // Calculate percentages
        holdings.forEach(holding => {
          holding.percentage = totalValue > 0 ? (holding.value / totalValue) * 100 : 0;
        });

        return {
          holdings,
          totalValue,
          totalPnL: 0,
          totalPnLPercentage: 0
        };
      } catch (error) {
        console.error('Error fetching wallet portfolio:', error);
        return null;
      }
    },
    enabled: !!walletAddress && !!publicKey && !!solPrice,
    refetchInterval: 30000,
    staleTime: 10000
  });

  return {
    portfolio,
    isLoading,
    totalValue: portfolio?.totalValue || 0,
    holdings: portfolio?.holdings || [],
    totalPnL: portfolio?.totalPnL || 0,
    totalPnLPercentage: portfolio?.totalPnLPercentage || 0
  };
};
