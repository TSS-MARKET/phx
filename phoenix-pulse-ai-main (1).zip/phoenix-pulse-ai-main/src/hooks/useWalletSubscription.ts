import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useWalletAuth } from '@/contexts/WalletAuthContext';
import { useToast } from '@/hooks/use-toast';

export const useWalletSubscription = () => {
  const { walletAddress, isAdmin } = useWalletAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: subscription, isLoading } = useQuery({
    queryKey: ['wallet-subscription', walletAddress],
    queryFn: async () => {
      if (!walletAddress) return null;

      const { data, error } = await supabase
        .from('user_subscriptions')
        .select('*')
        .eq('user_id', walletAddress)
        .single();

      if (error && error.code === 'PGRST116') {
        const { data: newSub } = await supabase
          .from('user_subscriptions')
          .insert({
            user_id: walletAddress,
            tier: isAdmin ? 'elite' : 'free',
            status: 'active'
          })
          .select()
          .single();
        return newSub;
      }

      return data;
    },
    enabled: !!walletAddress
  });

  const canAccessFeature = (feature: string): boolean => {
    // Admin always has full access to all features
    if (isAdmin) return true;
    
    if (!subscription) return false;

    const tier = subscription.tier;
    if (subscription.status !== 'active') return false;

    switch (feature) {
      case 'unlimited_signals':
      case 'sentiment_tracker':
      case 'portfolio_insights':
        return tier === 'pro' || tier === 'elite';
      case 'phoenix_daily_3':
      case 'trading_bot':
      case 'token_creator':
      case 'memecoin_hype':
      case 'alerts':
        return tier === 'elite';
      default:
        return false;
    }
  };

  const canFollowSignal = (): boolean => {
    if (!subscription) return false;
    if (isAdmin) return true;
    if (subscription.tier === 'pro' || subscription.tier === 'elite') return true;
    return subscription.daily_analysis_count < 1;
  };

  const incrementSignalCount = useMutation({
    mutationFn: async () => {
      if (!walletAddress) throw new Error('No wallet connected');

      const { data, error } = await supabase
        .from('user_subscriptions')
        .update({ daily_analysis_count: (subscription?.daily_analysis_count || 0) + 1 })
        .eq('user_id', walletAddress)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['wallet-subscription'] });
    }
  });

  return {
    subscription,
    isLoading,
    canAccessFeature,
    canFollowSignal,
    incrementSignalCount: incrementSignalCount.mutate
  };
};
