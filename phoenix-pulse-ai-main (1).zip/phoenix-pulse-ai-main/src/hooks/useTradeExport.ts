import { useToast } from '@/hooks/use-toast';

interface TradeData {
  executed_at: string;
  trade_type: string;
  from_token: string;
  to_token: string;
  amount_in: number;
  amount_out: number;
  entry_price: number;
  exit_price: number;
  profit_loss: number;
  profit_loss_percentage: number;
  status: string;
  transaction_signature: string;
}

export const useTradeExport = () => {
  const { toast } = useToast();

  const exportToCSV = (trades: TradeData[]) => {
    try {
      const headers = [
        'Date',
        'Type',
        'From Token',
        'To Token',
        'Amount In',
        'Amount Out',
        'Entry Price',
        'Exit Price',
        'P/L',
        'P/L %',
        'Status',
        'Transaction'
      ];

      const csvData = trades.map(trade => [
        new Date(trade.executed_at).toLocaleString(),
        trade.trade_type.toUpperCase(),
        trade.from_token,
        trade.to_token,
        trade.amount_in,
        trade.amount_out || 0,
        trade.entry_price || 0,
        trade.exit_price || 0,
        trade.profit_loss || 0,
        trade.profit_loss_percentage || 0,
        trade.status.toUpperCase(),
        trade.transaction_signature || 'N/A'
      ]);

      const csv = [
        headers.join(','),
        ...csvData.map(row => row.join(','))
      ].join('\n');

      const blob = new Blob([csv], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `phx-hydra-trades-${Date.now()}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

      toast({
        title: '📊 Export Complete',
        description: 'Trade history downloaded successfully'
      });
    } catch (error) {
      console.error('Export error:', error);
      toast({
        title: 'Export Failed',
        description: 'Could not export trade history',
        variant: 'destructive'
      });
    }
  };

  return { exportToCSV };
};
