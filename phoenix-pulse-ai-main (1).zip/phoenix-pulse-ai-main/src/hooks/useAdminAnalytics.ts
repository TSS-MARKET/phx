import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useWalletAuth } from '@/contexts/WalletAuthContext';

export interface AdminAnalytics {
  date: string;
  total_users: number;
  new_users: number;
  free_users: number;
  pro_users: number;
  elite_users: number;
  total_trades: number;
  total_volume: number;
  total_fees_collected: number;
}

export const useAdminAnalytics = () => {
  const { isAdmin, walletAddress } = useWalletAuth();

  const { data: analytics, isLoading } = useQuery({
    queryKey: ['admin-analytics', walletAddress],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('admin_analytics')
        .select('*')
        .order('date', { ascending: false })
        .limit(30);

      if (error) throw error;
      return data as AdminAnalytics[];
    },
    enabled: isAdmin
  });

  const { data: realtimeStats, isLoading: isLoadingStats } = useQuery({
    queryKey: ['admin-realtime-stats', walletAddress],
    queryFn: async () => {
      const [subscriptionsRes, tradesRes, analyticsRes] = await Promise.all([
        supabase.from('user_subscriptions').select('tier', { count: 'exact' }),
        supabase.from('trading_history').select('amount_in, fee_amount', { count: 'exact' }),
        supabase.from('user_trading_analytics').select('total_profit_loss', { count: 'exact' })
      ]);

      const subscriptions = subscriptionsRes.data || [];
      const tierCounts = {
        free: subscriptions.filter(s => s.tier === 'free').length,
        pro: subscriptions.filter(s => s.tier === 'pro').length,
        elite: subscriptions.filter(s => s.tier === 'elite').length
      };

      const trades = tradesRes.data || [];
      const totalVolume = trades.reduce((sum, t) => sum + Number(t.amount_in || 0), 0);
      const totalFees = trades.reduce((sum, t) => sum + Number(t.fee_amount || 0), 0);

      const analyticsData = analyticsRes.data || [];
      const totalPnL = analyticsData.reduce((sum, a) => sum + Number(a.total_profit_loss || 0), 0);

      return {
        totalUsers: subscriptionsRes.count || 0,
        tierCounts,
        totalTrades: tradesRes.count || 0,
        totalVolume,
        totalFees,
        totalPnL
      };
    },
    enabled: isAdmin,
    refetchInterval: 30000
  });

  return {
    analytics: analytics || [],
    realtimeStats,
    isLoading: isLoading || isLoadingStats
  };
};
