import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface PhoenixPick {
  id: string;
  pick_date: string;
  rank: number;
  coin_id: string;
  coin_name: string;
  coin_symbol: string;
  current_price: number;
  price_change_24h: number;
  market_cap: number;
  volume_24h: number;
  ai_score: number;
  ai_entry_price: number;
  ai_exit_price: number;
  ai_stop_loss: number;
  risk_level: 'low' | 'medium' | 'high';
  ai_reasoning: string;
  sentiment_score: number;
  created_at: string;
}

export const usePhoenixDaily3 = () => {
  return useQuery({
    queryKey: ["phoenix-daily-3"],
    queryFn: async () => {
      // First check if picks exist in database for today
      const today = new Date().toISOString().split('T')[0];
      const { data: existingPicks, error: dbError } = await supabase
        .from('phoenix_daily_picks')
        .select('*')
        .eq('pick_date', today)
        .order('rank', { ascending: true });

      if (!dbError && existingPicks && existingPicks.length === 3) {
        return existingPicks as PhoenixPick[];
      }

      // If not, call edge function to generate new picks
      const { data, error } = await supabase.functions.invoke('phoenix-daily-3');

      if (error) throw error;
      return data as PhoenixPick[];
    },
    staleTime: 3600000, // 1 hour
    refetchInterval: 3600000, // Refetch every hour
  });
};