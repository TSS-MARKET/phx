import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface CoinLogo {
  id: string;
  symbol: string;
  name: string;
  image: string;
}

export const useCoinLogos = (coinIds: string[]) => {
  return useQuery({
    queryKey: ["coin-logos", coinIds.join(",")],
    queryFn: async () => {
      if (coinIds.length === 0) return {};
      
      const { data, error } = await supabase.functions.invoke("coingecko-data", {
        body: {
          endpoint: "/coins/markets",
          params: {
            ids: coinIds.join(","),
            vs_currency: "usd",
            per_page: "250",
          },
        },
      });

      if (error) throw error;
      
      const logoMap: Record<string, string> = {};
      if (data) {
        data.forEach((coin: any) => {
          logoMap[coin.symbol.toUpperCase()] = coin.image;
          logoMap[coin.id] = coin.image;
        });
      }
      
      return logoMap;
    },
    staleTime: 3600000, // 1 hour
    enabled: coinIds.length > 0,
  });
};

export const useSingleCoinLogo = (coinId: string) => {
  return useQuery({
    queryKey: ["coin-logo", coinId],
    queryFn: async () => {
      if (!coinId) return null;
      
      const { data, error } = await supabase.functions.invoke("coingecko-data", {
        body: {
          endpoint: `/coins/${coinId}`,
          params: {
            localization: "false",
            tickers: "false",
            market_data: "false",
            community_data: "false",
            developer_data: "false",
          },
        },
      });

      if (error) throw error;
      
      return data?.image?.large || data?.image?.small || null;
    },
    staleTime: 3600000, // 1 hour
    enabled: !!coinId,
  });
};
