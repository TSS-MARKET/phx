import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const useCoinMarketData = (coinId: string | null) => {
  return useQuery({
    queryKey: ["coin-market-data", coinId],
    queryFn: async () => {
      if (!coinId) return null;
      
      const { data, error } = await supabase.functions.invoke("coingecko-data", {
        body: {
          endpoint: "/coins/markets",
          params: {
            ids: coinId.toLowerCase(),
            vs_currency: "usd",
            sparkline: "false",
          },
        },
      });

      if (error) throw error;
      
      return data?.[0] || null;
    },
    staleTime: 30000, // 30 seconds
    refetchInterval: 60000, // Refetch every 60 seconds
    enabled: !!coinId,
  });
};
