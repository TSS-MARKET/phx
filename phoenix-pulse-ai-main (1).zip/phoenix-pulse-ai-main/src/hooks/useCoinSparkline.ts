import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const useCoinSparkline = (coinId: string) => {
  return useQuery({
    queryKey: ["coin-sparkline", coinId],
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke("coingecko-data", {
        body: {
          endpoint: "/coins/markets",
          params: {
            ids: coinId.toLowerCase(),
            vs_currency: "usd",
            sparkline: "true",
          },
        },
      });

      if (error) throw error;
      
      return data?.[0]?.sparkline_in_7d?.price || [];
    },
    staleTime: 300000, // 5 minutes
    refetchInterval: 600000, // Refetch every 10 minutes
    enabled: !!coinId,
  });
};
