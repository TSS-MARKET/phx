import { useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import html2canvas from "html2canvas";
import phxAiLogo from "@/assets/phx-ai-logo.png";

interface PortfolioItem {
  id: string;
  symbol: string;
  name: string;
  amount: number;
  buyPrice: number;
  currentPrice: number;
  coinId?: string;
}

export const usePortfolioExport = () => {
  const { toast } = useToast();

  const exportToCSV = useCallback((portfolio: PortfolioItem[]) => {
    try {
      const headers = ["Symbol", "Name", "Amount", "Buy Price", "Current Price", "Value", "Profit/Loss", "P/L %"];
      const rows = portfolio.map(item => {
        const value = item.amount * item.currentPrice;
        const invested = item.amount * item.buyPrice;
        const profitLoss = value - invested;
        const profitLossPercent = ((profitLoss / invested) * 100).toFixed(2);
        return [item.symbol, item.name, item.amount.toString(), `$${item.buyPrice.toFixed(2)}`, `$${item.currentPrice.toFixed(2)}`, `$${value.toFixed(2)}`, `$${profitLoss.toFixed(2)}`, `${profitLossPercent}%`];
      });

      const totalValue = portfolio.reduce((sum, item) => sum + (item.amount * item.currentPrice), 0);
      const totalInvested = portfolio.reduce((sum, item) => sum + (item.amount * item.buyPrice), 0);
      const totalProfitLoss = totalValue - totalInvested;
      const totalProfitLossPercent = ((totalProfitLoss / totalInvested) * 100).toFixed(2);
      rows.push(["TOTAL", "", "", "", "", `$${totalValue.toFixed(2)}`, `$${totalProfitLoss.toFixed(2)}`, `${totalProfitLossPercent}%`]);

      const csvContent = ["Phoenix AI Portfolio Report", `Generated: ${new Date().toLocaleString()}`, "", headers.join(","), ...rows.map(row => row.join(","))].join("\n");
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const link = document.createElement("a");
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", `phoenix_ai_portfolio_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast({ title: "Export Successful", description: "Portfolio data exported to CSV" });
    } catch (error) {
      toast({ title: "Export Failed", description: "Failed to export portfolio data", variant: "destructive" });
    }
  }, [toast]);

  const exportToPDF = useCallback(async (portfolio: PortfolioItem[]) => {
    try {
      let chartImageData = "";
      const chartElement = document.querySelector('.performance-chart-container');
      if (chartElement) {
        try {
          const canvas = await html2canvas(chartElement as HTMLElement, {
            backgroundColor: '#0F1117',
            scale: 3,
            logging: false,
            useCORS: true,
          });
          chartImageData = canvas.toDataURL('image/png');
        } catch (e) {
          console.error('Failed to capture chart:', e);
        }
      }
      
      const totalValue = portfolio.reduce((sum, item) => sum + (item.amount * item.currentPrice), 0);
      const totalInvested = portfolio.reduce((sum, item) => sum + (item.amount * item.buyPrice), 0);
      const totalProfitLoss = totalValue - totalInvested;
      const totalProfitLossPercent = ((totalProfitLoss / totalInvested) * 100).toFixed(2);
      const assetCount = portfolio.length;
      
      const bestPerformer = portfolio.reduce((best, item) => {
        const itemProfit = ((item.currentPrice - item.buyPrice) / item.buyPrice) * 100;
        const bestProfit = best ? ((best.currentPrice - best.buyPrice) / best.buyPrice) * 100 : -Infinity;
        return itemProfit > bestProfit ? item : best;
      }, portfolio[0]);
      
      const worstPerformer = portfolio.reduce((worst, item) => {
        const itemProfit = ((item.currentPrice - item.buyPrice) / item.buyPrice) * 100;
        const worstProfit = worst ? ((worst.currentPrice - worst.buyPrice) / worst.buyPrice) * 100 : Infinity;
        return itemProfit < worstProfit ? item : worst;
      }, portfolio[0]);
      
      const largestHolding = portfolio.reduce((largest, item) => {
        const itemValue = item.amount * item.currentPrice;
        const largestValue = largest ? largest.amount * largest.currentPrice : 0;
        return itemValue > largestValue ? item : largest;
      }, portfolio[0]);

      // Convert logo to base64
      const logoBase64 = await fetch(phxAiLogo)
        .then(res => res.blob())
        .then(blob => new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.readAsDataURL(blob);
        }))
        .catch(() => phxAiLogo); // Fallback to direct path if conversion fails

      const htmlContent = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Phoenix AI Portfolio Report</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700;900&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Inter', sans-serif; background: linear-gradient(135deg, #0F1117 0%, #1a1f35 100%); color: #e2e8f0; padding: 40px; line-height: 1.6; }
    .container { max-width: 1200px; margin: 0 auto; background: rgba(15, 17, 23, 0.95); border-radius: 24px; padding: 60px; box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5); border: 2px solid rgba(139, 92, 246, 0.3); }
    .header { text-align: center; margin-bottom: 60px; padding: 40px; background: linear-gradient(135deg, rgba(139, 92, 246, 0.15) 0%, rgba(59, 130, 246, 0.15) 100%); border-radius: 20px; border: 2px solid rgba(139, 92, 246, 0.4); position: relative; overflow: hidden; }
    .header::before { content: ''; position: absolute; top: -50%; left: -50%; width: 200%; height: 200%; background: radial-gradient(circle, rgba(139, 92, 246, 0.1) 0%, transparent 70%); }
    .logo-container { display: flex; align-items: center; justify-content: center; gap: 25px; margin-bottom: 25px; position: relative; z-index: 1; }
    .logo { width: 120px; height: 120px; border-radius: 20px; box-shadow: 0 20px 40px rgba(139, 92, 246, 0.4), 0 0 80px rgba(139, 92, 246, 0.3); border: 3px solid rgba(139, 92, 246, 0.6); object-fit: cover; }
    .brand-title { font-family: 'Orbitron', sans-serif; font-size: 64px; font-weight: 900; background: linear-gradient(135deg, #8b5cf6 0%, #3b82f6 50%, #06b6d4 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; letter-spacing: 4px; text-shadow: 0 0 40px rgba(139, 92, 246, 0.5); line-height: 1.2; }
    .report-title { font-family: 'Orbitron', sans-serif; font-size: 28px; font-weight: 600; color: #a78bfa; margin-top: 15px; letter-spacing: 2px; position: relative; z-index: 1; }
    .report-date { font-size: 16px; color: #94a3b8; margin-top: 12px; font-weight: 500; position: relative; z-index: 1; }
    .summary-section { display: grid; grid-template-columns: repeat(4, 1fr); gap: 25px; margin-bottom: 50px; }
    .summary-card { background: linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, rgba(59, 130, 246, 0.05) 100%); padding: 30px; border-radius: 16px; border: 2px solid rgba(139, 92, 246, 0.3); text-align: center; }
    .summary-label { font-size: 14px; color: #94a3b8; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px; font-weight: 600; }
    .summary-value { font-size: 32px; font-weight: 700; color: #ffffff; font-family: 'Orbitron', sans-serif; }
    .positive { color: #06b6d4; text-shadow: 0 0 20px rgba(6, 182, 212, 0.5); }
    .negative { color: #ef4444; }
    .chart-section { margin-bottom: 50px; }
    .chart-container { background: rgba(15, 17, 23, 0.8); padding: 30px; border-radius: 16px; border: 2px solid rgba(139, 92, 246, 0.3); }
    .chart-image { width: 100%; height: auto; border-radius: 12px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3); }
    .section-title { font-family: 'Orbitron', sans-serif; font-size: 28px; font-weight: 700; color: #a78bfa; margin-bottom: 25px; padding-bottom: 15px; border-bottom: 2px solid rgba(139, 92, 246, 0.3); letter-spacing: 1px; }
    .holdings-table { width: 100%; border-collapse: separate; border-spacing: 0 12px; margin-bottom: 50px; }
    .holdings-table thead th { background: linear-gradient(135deg, rgba(139, 92, 246, 0.2) 0%, rgba(59, 130, 246, 0.15) 100%); padding: 20px; text-align: left; font-weight: 700; color: #a78bfa; text-transform: uppercase; font-size: 13px; letter-spacing: 1px; border: 2px solid rgba(139, 92, 246, 0.3); }
    .holdings-table thead th:first-child { border-top-left-radius: 12px; border-bottom-left-radius: 12px; }
    .holdings-table thead th:last-child { border-top-right-radius: 12px; border-bottom-right-radius: 12px; }
    .holdings-table tbody tr { background: rgba(15, 17, 23, 0.6); }
    .holdings-table tbody td { padding: 20px; border-top: 1px solid rgba(139, 92, 246, 0.2); border-bottom: 1px solid rgba(139, 92, 246, 0.2); font-size: 15px; }
    .holdings-table tbody td:first-child { border-left: 1px solid rgba(139, 92, 246, 0.2); border-top-left-radius: 12px; border-bottom-left-radius: 12px; font-weight: 700; color: #ffffff; }
    .holdings-table tbody td:last-child { border-right: 1px solid rgba(139, 92, 246, 0.2); border-top-right-radius: 12px; border-bottom-right-radius: 12px; }
    .holdings-table tfoot td { padding: 25px 20px; font-weight: 700; font-size: 18px; background: linear-gradient(135deg, rgba(139, 92, 246, 0.2) 0%, rgba(59, 130, 246, 0.15) 100%); border: 2px solid rgba(139, 92, 246, 0.4); }
    .holdings-table tfoot td:first-child { border-top-left-radius: 12px; border-bottom-left-radius: 12px; }
    .holdings-table tfoot td:last-child { border-top-right-radius: 12px; border-bottom-right-radius: 12px; }
    .insights-section { display: grid; grid-template-columns: repeat(3, 1fr); gap: 25px; margin-bottom: 40px; }
    .insight-card { background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(139, 92, 246, 0.05) 100%); padding: 25px; border-radius: 16px; border: 2px solid rgba(59, 130, 246, 0.3); }
    .insight-title { font-size: 14px; color: #60a5fa; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px; font-weight: 600; }
    .insight-value { font-size: 24px; font-weight: 700; color: #ffffff; margin-bottom: 8px; }
    .insight-detail { font-size: 13px; color: #94a3b8; }
    .watermark { position: fixed; bottom: 30px; right: 30px; opacity: 0.5; font-family: 'Orbitron', sans-serif; font-size: 16px; color: #8b5cf6; display: flex; align-items: center; gap: 12px; z-index: 9999; }
    .watermark-logo { width: 50px; height: 50px; border-radius: 10px; box-shadow: 0 0 20px rgba(139, 92, 246, 0.4); }
    @media print { body { background: white; padding: 0; } .container { box-shadow: none; border: none; } .watermark { position: fixed; bottom: 20px; right: 20px; } }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="logo-container">
        <img src="${logoBase64}" alt="Phoenix AI" class="logo" />
        <h1 class="brand-title">PHOENIX AI</h1>
      </div>
      <h2 class="report-title">PORTFOLIO PERFORMANCE REPORT</h2>
      <p class="report-date">Generated on ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
    </div>
    <div class="summary-section">
      <div class="summary-card"><div class="summary-label">Total Value</div><div class="summary-value">$${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div></div>
      <div class="summary-card"><div class="summary-label">Total P/L</div><div class="summary-value ${totalProfitLoss >= 0 ? 'positive' : 'negative'}">${totalProfitLoss >= 0 ? '+' : ''}$${Math.abs(totalProfitLoss).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div></div>
      <div class="summary-card"><div class="summary-label">P/L Percentage</div><div class="summary-value ${totalProfitLoss >= 0 ? 'positive' : 'negative'}">${totalProfitLoss >= 0 ? '+' : ''}${totalProfitLossPercent}%</div></div>
      <div class="summary-card"><div class="summary-label">Assets</div><div class="summary-value">${assetCount}</div></div>
    </div>
    ${chartImageData ? `<div class="chart-section"><h3 class="section-title">Portfolio Performance</h3><div class="chart-container"><img src="${chartImageData}" alt="Performance Chart" class="chart-image" /></div></div>` : ''}
    <div class="insights-section">
      <div class="insight-card"><div class="insight-title">Best Performer</div><div class="insight-value">${bestPerformer?.symbol || 'N/A'}</div><div class="insight-detail">${bestPerformer ? `+${(((bestPerformer.currentPrice - bestPerformer.buyPrice) / bestPerformer.buyPrice) * 100).toFixed(2)}%` : 'N/A'}</div></div>
      <div class="insight-card"><div class="insight-title">Worst Performer</div><div class="insight-value">${worstPerformer?.symbol || 'N/A'}</div><div class="insight-detail">${worstPerformer ? `${(((worstPerformer.currentPrice - worstPerformer.buyPrice) / worstPerformer.buyPrice) * 100).toFixed(2)}%` : 'N/A'}</div></div>
      <div class="insight-card"><div class="insight-title">Largest Position</div><div class="insight-value">${largestHolding?.symbol || 'N/A'}</div><div class="insight-detail">${largestHolding ? `$${(largestHolding.amount * largestHolding.currentPrice).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : 'N/A'}</div></div>
    </div>
    <h3 class="section-title">Detailed Holdings Breakdown</h3>
    <table class="holdings-table">
      <thead><tr><th>Asset</th><th>Amount</th><th>Buy Price</th><th>Current Price</th><th>Value</th><th>Invested</th><th>P/L</th><th>P/L %</th></tr></thead>
      <tbody>
        ${portfolio.map(item => {
          const value = item.amount * item.currentPrice;
          const invested = item.amount * item.buyPrice;
          const profitLoss = value - invested;
          const profitLossPercent = ((profitLoss / invested) * 100).toFixed(2);
          return `<tr><td>${item.symbol}</td><td>${item.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 })}</td><td>$${item.buyPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td><td>$${item.currentPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td><td>$${value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td><td>$${invested.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td><td class="${profitLoss >= 0 ? 'positive' : 'negative'}">${profitLoss >= 0 ? '+' : ''}$${Math.abs(profitLoss).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td><td class="${profitLoss >= 0 ? 'positive' : 'negative'}">${profitLoss >= 0 ? '+' : ''}${profitLossPercent}%</td></tr>`;
        }).join('')}
      </tbody>
      <tfoot><tr><td><strong>TOTAL</strong></td><td>-</td><td>-</td><td>-</td><td><strong>$${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong></td><td><strong>$${totalInvested.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong></td><td class="${totalProfitLoss >= 0 ? 'positive' : 'negative'}"><strong>${totalProfitLoss >= 0 ? '+' : ''}$${Math.abs(totalProfitLoss).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong></td><td class="${totalProfitLoss >= 0 ? 'positive' : 'negative'}"><strong>${totalProfitLoss >= 0 ? '+' : ''}${totalProfitLossPercent}%</strong></td></tr></tfoot>
    </table>
  </div>
  <div class="watermark">
    <img src="${logoBase64}" alt="Phoenix AI" class="watermark-logo" />
    <span>Powered by Phoenix AI</span>
  </div>
</body>
</html>`;

      const blob = new Blob([htmlContent], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `phoenix_ai_portfolio_${new Date().toISOString().split('T')[0]}.html`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast({ title: "Export Successful", description: "Portfolio exported as HTML. Open in browser and print to PDF." });
    } catch (error) {
      toast({ title: "Export Failed", description: "Failed to export portfolio", variant: "destructive" });
    }
  }, [toast]);

  return { exportToCSV, exportToPDF };
};
