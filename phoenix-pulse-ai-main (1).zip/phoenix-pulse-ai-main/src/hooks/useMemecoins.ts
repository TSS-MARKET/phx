import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface MemecoinParams {
  search?: string;
}

export const useMemecoins = (params?: MemecoinParams) => {
  return useQuery({
    queryKey: ["memecoins", params],
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke("memecoin-hype", {
        body: params || {},
      });

      if (error) throw error;
      return data;
    },
    staleTime: 30000, // 30 seconds
    refetchInterval: 60000, // Refetch every 60 seconds
  });
};
