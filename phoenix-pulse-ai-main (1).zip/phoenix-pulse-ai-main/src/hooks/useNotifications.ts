import { useState, useCallback } from 'react';
import { NotificationToast } from '@/components/ui/notification-toast';

export const useNotifications = () => {
  const [notifications, setNotifications] = useState<NotificationToast[]>([]);

  const addNotification = useCallback((
    type: NotificationToast['type'],
    title: string,
    message: string
  ) => {
    const notification: NotificationToast = {
      id: `${Date.now()}-${Math.random()}`,
      type,
      title,
      message,
      timestamp: Date.now(),
    };

    setNotifications(prev => [notification, ...prev].slice(0, 5)); // Keep max 5 notifications

    // Auto dismiss after 5 seconds
    setTimeout(() => {
      dismissNotification(notification.id);
    }, 5000);
  }, []);

  const dismissNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  return {
    notifications,
    addNotification,
    dismissNotification,
  };
};
