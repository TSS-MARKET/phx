import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useWalletAuth } from '@/contexts/WalletAuthContext';
import { useToast } from '@/hooks/use-toast';

export interface TradeSignal {
  recommendation: 'strong_buy' | 'buy' | 'hold' | 'avoid';
  aiConfidence: number;
  reasoning: string;
  entryPrice: number;
  targetPrice: number;
  stopLoss: number;
  riskLevel: 'low' | 'medium' | 'high';
}

export const useWalletTradingBot = () => {
  const { walletAddress } = useWalletAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tradeHistory, isLoading: isLoadingHistory } = useQuery({
    queryKey: ['trade-history', walletAddress],
    queryFn: async () => {
      if (!walletAddress) return [];

      const { data, error } = await supabase
        .from('trading_history')
        .select('*')
        .eq('user_id', walletAddress)
        .order('executed_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      return data;
    },
    enabled: !!walletAddress
  });

  const { data: analytics, isLoading: isLoadingAnalytics } = useQuery({
    queryKey: ['trading-analytics', walletAddress],
    queryFn: async () => {
      if (!walletAddress) return null;

      const { data, error } = await supabase
        .from('user_trading_analytics')
        .select('*')
        .eq('user_id', walletAddress)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
    enabled: !!walletAddress
  });

  const getTradeSignal = async (fromToken: string, toToken: string, amount: number): Promise<TradeSignal> => {
    const { data, error } = await supabase.functions.invoke('jupiter-trading', {
      body: {
        action: 'analyzeTrade',
        fromToken,
        toToken,
        amount,
        walletAddress
      }
    });

    if (error) throw error;
    return data;
  };

  const recordTrade = useMutation({
    mutationFn: async (trade: {
      trade_type: 'buy' | 'sell';
      mode: 'signal' | 'auto';
      from_token: string;
      to_token: string;
      amount_in: number;
      amount_out?: number;
      price?: number;
      transaction_signature?: string;
      status: 'pending' | 'completed' | 'failed';
      profit_loss?: number;
      ai_confidence?: number;
      fee_amount?: number;
    }) => {
      if (!walletAddress) throw new Error('No wallet connected');

      const { data, error } = await supabase
        .from('trading_history')
        .insert({
          user_id: walletAddress,
          ...trade
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trade-history'] });
      queryClient.invalidateQueries({ queryKey: ['trading-analytics'] });
      toast({
        title: 'Trade Recorded',
        description: 'Your trade has been recorded successfully.'
      });
    }
  });

  return {
    tradeHistory,
    analytics,
    isLoadingHistory,
    isLoadingAnalytics,
    getTradeSignal,
    recordTrade: recordTrade.mutate
  };
};
