import { useQuery } from "@tanstack/react-query";

interface CoinDetails {
  market_cap: number;
  total_volume: number;
  high_24h: number;
  low_24h: number;
  price_change_percentage_24h: number;
  circulating_supply: number;
  total_supply: number;
}

export const useCoinDetails = (coinId: string) => {
  return useQuery({
    queryKey: ["coin-details", coinId],
    queryFn: async () => {
      const response = await fetch(
        `https://api.coingecko.com/api/v3/coins/${coinId}?localization=false&tickers=false&community_data=false&developer_data=false`
      );
      
      if (!response.ok) {
        throw new Error("Failed to fetch coin details");
      }
      
      const data = await response.json();
      
      return {
        market_cap: data.market_data?.market_cap?.usd || 0,
        total_volume: data.market_data?.total_volume?.usd || 0,
        high_24h: data.market_data?.high_24h?.usd || 0,
        low_24h: data.market_data?.low_24h?.usd || 0,
        price_change_percentage_24h: data.market_data?.price_change_percentage_24h || 0,
        circulating_supply: data.market_data?.circulating_supply || 0,
        total_supply: data.market_data?.total_supply || 0,
      } as CoinDetails;
    },
    staleTime: 60000, // 1 minute
    enabled: !!coinId,
  });
};
