import { useEffect, useRef } from "react";
import phxLogo from "@/assets/phx-ai-logo.png";
import html2canvas from "html2canvas";
import { Sparkline } from "@/components/ui/sparkline";

interface PortfolioPnLData {
  totalValue: number;
  totalInvested: number;
  totalProfit: number;
  profitPercentage: number;
  realizedPnL?: number;
  unrealizedPnL?: number;
  sparklineData?: number[];
}

interface PnLCardGeneratorProps {
  data: PortfolioPnLData;
  onCapture?: (dataUrl: string) => void;
}

export const PnLCardGenerator = ({ data, onCapture }: PnLCardGeneratorProps) => {
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (onCapture && cardRef.current) {
      const timer = setTimeout(async () => {
        if (cardRef.current) {
          const canvas = await html2canvas(cardRef.current, {
            backgroundColor: "#000000",
            scale: 2,
            logging: false,
            useCORS: true,
          });
          onCapture(canvas.toDataURL("image/png"));
        }
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [data, onCapture]);

  const isPositive = data.profitPercentage >= 0;
  const realizedPnL = data.realizedPnL || 0;
  const unrealizedPnL = data.unrealizedPnL || data.totalProfit;

  return (
    <div
      ref={cardRef}
      className="relative w-[900px] h-[1200px] rounded-3xl overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #0a0a1a 0%, #1a1a2e 100%)",
      }}
    >
      {/* Cyan Border Glow */}
      <div className="absolute inset-0 rounded-3xl" style={{
        padding: "3px",
        background: "linear-gradient(135deg, #00d9ff 0%, #0099cc 50%, #00d9ff 100%)",
      }}>
        <div className="w-full h-full rounded-3xl" style={{
          background: "linear-gradient(135deg, #0a0a1a 0%, #1a1a2e 100%)",
        }} />
      </div>

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col p-12">
        {/* Branding Header - More Prominent */}
        <div className="flex flex-col items-center mb-8">
          <img src={phxLogo} alt="PHX AI" className="w-48 h-48 mb-4" />
          <h1 className="text-6xl font-black mb-6" style={{ 
            fontFamily: "'Orbitron', sans-serif",
            background: "linear-gradient(135deg, #4169e1 0%, #00d9ff 100%)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            letterSpacing: "0.1em"
          }}>
            PHX AI
          </h1>
          <div className="inline-block px-8 py-3 rounded-full" style={{
            background: isPositive ? "rgba(16, 185, 129, 0.2)" : "rgba(239, 68, 68, 0.2)",
            border: `3px solid ${isPositive ? "#10b981" : "#ef4444"}`
          }}>
            <span className="text-4xl font-bold" style={{ 
              color: isPositive ? "#10b981" : "#ef4444",
              fontFamily: "'Orbitron', sans-serif"
            }}>
              {isPositive ? "+" : ""}{data.profitPercentage.toFixed(2)}%
            </span>
          </div>
        </div>

        {/* Main Value */}
        <div className="mb-12">
          <p className="text-6xl font-black" style={{ 
            color: isPositive ? "#10b981" : "#ef4444",
            textShadow: isPositive 
              ? "0 0 40px rgba(16, 185, 129, 0.5)"
              : "0 0 40px rgba(239, 68, 68, 0.5)"
          }}>
            ${data.totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-6 mb-8">
          <div>
            <p className="text-lg mb-2" style={{ color: "#94a3b8" }}>Invested Capital:</p>
            <p className="text-4xl font-bold text-white">
              ${data.totalInvested.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <p className="text-sm mt-1" style={{ color: "#64748b" }}>
              ${(data.totalInvested / 1000).toFixed(3)}
            </p>
          </div>
          <div>
            <p className="text-lg mb-2" style={{ color: "#94a3b8" }}>Realized PNL:</p>
            <p className="text-4xl font-bold" style={{ color: isPositive ? "#10b981" : "#ef4444" }}>
              ${realizedPnL.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <p className="text-sm mt-1" style={{ color: "#64748b" }}>
              ${(realizedPnL / 1000).toFixed(3)}
            </p>
          </div>
          <div>
            <p className="text-lg mb-2" style={{ color: "#94a3b8" }}>Current Value:</p>
            <p className="text-4xl font-bold text-white">
              ${data.totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <p className="text-sm mt-1" style={{ color: "#64748b" }}>
              ${(data.totalValue / 1000).toFixed(3)}
            </p>
          </div>
          <div>
            <p className="text-lg mb-2" style={{ color: "#94a3b8" }}>Unrealized PNL:</p>
            <p className="text-4xl font-bold" style={{ color: isPositive ? "#10b981" : "#ef4444" }}>
              ${unrealizedPnL.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <p className="text-sm mt-1" style={{ color: "#64748b" }}>
              ${(unrealizedPnL / 1000).toFixed(3)}
            </p>
          </div>
        </div>

        {/* Divider */}
        <div className="w-full h-px mb-6" style={{ background: "#00d9ff" }} />

        {/* Bottom Section - Sparkline */}
        <div className="flex flex-col mt-auto">
          <p className="text-lg mb-4" style={{ 
            color: "#94a3b8",
            fontFamily: "'Orbitron', sans-serif"
          }}>
            Performance Trend
          </p>
          <div className="w-full h-24 flex items-center">
            {data.sparklineData && data.sparklineData.length > 0 ? (
              <Sparkline 
                data={data.sparklineData} 
                color={isPositive ? "#10b981" : "#ef4444"}
                height={80}
                width={800}
                showGlow={true}
              />
            ) : (
              <svg width="800" height="80" className="opacity-80">
                <polyline
                  points="0,40 200,35 400,45 600,30 800,40"
                  fill="none"
                  stroke={isPositive ? "#10b981" : "#ef4444"}
                  strokeWidth="3"
                />
              </svg>
            )}
          </div>
          <p className="text-sm mt-4 text-center" style={{ 
            color: "#64748b",
            fontFamily: "'Orbitron', sans-serif"
          }}>
            phoenixai.app
          </p>
        </div>
      </div>
    </div>
  );
};
