import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Activity, Target, AlertTriangle, BarChart3 } from "lucide-react";
import { WalletHolding } from "@/hooks/useWalletPortfolio";

interface PortfolioAnalyticsProps {
  holdings: WalletHolding[];
  totalValue: number;
  performanceData?: Array<{ date: string; value: number }>;
}

export const PortfolioAnalytics = ({ holdings, totalValue, performanceData }: PortfolioAnalyticsProps) => {
  const analytics = useMemo(() => {
    if (!performanceData || performanceData.length === 0) {
      return {
        sharpeRatio: 0,
        volatility: 0,
        maxDrawdown: 0,
        beta: 1.0,
        totalReturn: 0,
        totalReturnAmount: 0,
        valueAtRisk: 0
      };
    }

    const initialValue = performanceData[0].value;
    const finalValue = performanceData[performanceData.length - 1].value;

    // Calculate daily returns
    const returns = performanceData.slice(1).map((point, i) => 
      (point.value - performanceData[i].value) / performanceData[i].value
    );

    // Average return
    const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length;

    // Volatility (standard deviation) - annualized
    const variance = returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length;
    const volatility = Math.sqrt(variance) * Math.sqrt(252) * 100; // Annualized

    // Sharpe Ratio (assuming 2% risk-free rate)
    const riskFreeRate = 0.02;
    const annualizedReturn = avgReturn * 252;
    const excessReturn = annualizedReturn - riskFreeRate;
    const sharpeRatio = volatility > 0 ? excessReturn / (volatility / 100) : 0;

    // Max Drawdown
    let maxDrawdown = 0;
    let peak = performanceData[0].value;
    performanceData.forEach(point => {
      if (point.value > peak) peak = point.value;
      const drawdown = ((peak - point.value) / peak) * 100;
      if (drawdown > maxDrawdown) maxDrawdown = drawdown;
    });

    // Beta (market correlation) - simplified calculation
    const marketReturns = returns.map((_, i) => returns[i] * 0.85); // Simplified market proxy
    const covariance = returns.reduce((sum, r, i) => sum + (r - avgReturn) * (marketReturns[i] - avgReturn), 0) / returns.length;
    const marketVariance = marketReturns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length;
    const beta = marketVariance > 0 ? covariance / marketVariance : 1.0;

    // Total Return
    const totalReturn = ((finalValue - initialValue) / initialValue) * 100;
    const totalReturnAmount = finalValue - initialValue;

    // Value at Risk (95% confidence)
    const sortedReturns = [...returns].sort((a, b) => a - b);
    const varIndex = Math.floor(sortedReturns.length * 0.05);
    const valueAtRisk = Math.abs(sortedReturns[varIndex] * totalValue);

    return {
      sharpeRatio: isFinite(sharpeRatio) ? sharpeRatio : 0,
      volatility: isFinite(volatility) ? volatility : 0,
      maxDrawdown: isFinite(maxDrawdown) ? maxDrawdown : 0,
      beta: isFinite(beta) ? beta : 1.0,
      totalReturn: isFinite(totalReturn) ? totalReturn : 0,
      totalReturnAmount: isFinite(totalReturnAmount) ? totalReturnAmount : 0,
      valueAtRisk: isFinite(valueAtRisk) ? valueAtRisk : 0
    };
  }, [performanceData, totalValue]);

  const riskAssessment = useMemo(() => {
    const score = analytics.sharpeRatio;
    if (score > 2) return { level: "Excellent", color: "text-green-400", message: "Portfolio is performing exceptionally well with optimal risk-adjusted returns." };
    if (score > 1) return { level: "Good", color: "text-cyan-400", message: "Portfolio is performing within acceptable risk parameters." };
    if (score > 0) return { level: "Moderate", color: "text-yellow-400", message: "Portfolio shows moderate risk levels. Consider rebalancing." };
    return { level: "High Risk", color: "text-red-400", message: "Portfolio has elevated risk levels. Immediate attention recommended." };
  }, [analytics.sharpeRatio]);

  const riskMetrics = [
    {
      icon: <Activity className="w-5 h-5 text-cyan-400" />,
      label: "Sharpe Ratio",
      value: analytics.sharpeRatio.toFixed(2),
      description: analytics.sharpeRatio > 1 ? "High Risk" : analytics.sharpeRatio > 0 ? "Medium" : "Low",
      color: analytics.sharpeRatio > 1 ? "text-red-400" : analytics.sharpeRatio > 0 ? "text-yellow-400" : "text-green-400"
    },
    {
      icon: <TrendingUp className="w-5 h-5 text-cyan-400" />,
      label: "Volatility (σ)",
      value: `${analytics.volatility.toFixed(0)}%`,
      description: "Standard Deviation",
      color: analytics.volatility > 50 ? "text-red-400" : analytics.volatility > 30 ? "text-yellow-400" : "text-cyan-400"
    },
    {
      icon: <Target className="w-5 h-5 text-primary" />,
      label: "Total Return",
      value: `+${analytics.totalReturn.toFixed(2)}%`,
      description: `$${analytics.totalReturnAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} of $${(totalValue - analytics.totalReturnAmount).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`,
      color: analytics.totalReturn >= 0 ? "text-primary" : "text-red-400"
    },
    {
      icon: <BarChart3 className="w-5 h-5 text-cyan-400" />,
      label: "Beta (β)",
      value: analytics.beta.toFixed(2),
      description: analytics.beta > 1 ? "More volatile than market" : "Less volatile than market",
      color: "text-cyan-400"
    },
    {
      icon: <TrendingDown className="w-5 h-5 text-red-400" />,
      label: "Max Drawdown",
      value: `${analytics.maxDrawdown.toFixed(2)}%`,
      description: "Worst performing asset",
      color: "text-red-400"
    },
    {
      icon: <AlertTriangle className="w-5 h-5 text-yellow-400" />,
      label: "VaR (95%)",
      value: `${analytics.valueAtRisk.toFixed(2)}%`,
      description: "Potential loss at 95% confidence",
      color: "text-yellow-400"
    }
  ];

  return (
    <Card className="glass-card hover-glow">
      <CardHeader>
        <CardTitle className="text-xl gradient-text-purple flex items-center gap-2">
          <Activity className="w-5 h-5" />
          Portfolio Analytics
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Risk Metrics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {riskMetrics.map((metric, index) => (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="glass-card p-6 hover-glow cursor-pointer border border-border/50"
              >
                <div className="flex items-center gap-3 mb-3">
                  {metric.icon}
                  <span className="text-sm text-muted-foreground">{metric.label}</span>
                </div>
                <div className={`text-3xl font-bold mb-2 ${metric.color}`}>
                  {metric.value}
                </div>
                <div className="text-xs text-muted-foreground">
                  {metric.description}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Risk Assessment */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass-card p-6 hover-glow border border-primary/30"
          >
            <div className="flex items-start gap-4">
              <div className={`p-3 rounded-full bg-primary/10`}>
                <AlertTriangle className={`w-6 h-6 ${riskAssessment.color}`} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-sm text-muted-foreground">Risk Assessment</span>
                  <span className={`text-lg font-bold ${riskAssessment.color}`}>
                    {riskAssessment.level}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">
                  {riskAssessment.message}
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </CardContent>
    </Card>
  );
};
