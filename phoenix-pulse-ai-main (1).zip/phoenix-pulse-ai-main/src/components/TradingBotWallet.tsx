import { useState, useEffect, useRef } from 'react';
import { useSwipeable } from 'react-swipeable';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { useWalletAuth } from '@/contexts/WalletAuthContext';
import { useToast } from '@/hooks/use-toast';
import { useCoinLogos } from '@/hooks/useCoinLogos';
import { useTradingBotChat } from '@/hooks/useTradingBotChat';
import { useVoiceCommand } from '@/hooks/useVoiceCommand';
import { useTradingSignals } from '@/hooks/useTradingSignals';
import { useWalletTradingBot } from '@/hooks/useWalletTradingBot';
import { useWalletPortfolio } from '@/hooks/useWalletPortfolio';
import { useCoinPrice } from '@/hooks/useCoinPrice';
import { useBotSettings } from '@/hooks/useBotSettings';
import { usePriceAlerts } from '@/hooks/usePriceAlerts';
import { useTradeExport } from '@/hooks/useTradeExport';
import { useAutoTrading } from '@/hooks/useAutoTrading';
import { useAudioNotifications } from '@/hooks/useAudioNotifications';
import { usePriceMonitoring } from '@/hooks/usePriceMonitoring';
import { useCardTilt } from '@/hooks/useCardTilt';
import { supabase } from '@/integrations/supabase/client';
import { TradingBotSettings } from '@/components/TradingBotSettings';
import { CoinSearchDialog } from '@/components/CoinSearchDialog';
import { WalletCopyTrading } from '@/components/WalletCopyTrading';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useCoinGecko } from '@/hooks/useCoinGecko';
import { PremiumChart } from '@/components/ui/premium-chart';
import { ParticleBackground } from '@/components/ui/particle-background';
import { LoadingSkeleton, ChartSkeleton } from '@/components/ui/loading-skeleton';
import { useHaptic } from '@/hooks/useHaptic';
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Settings, 
  Send, 
  Zap,
  Target,
  BarChart3,
  Sparkles,
  Bot,
  ShoppingCart,
  ArrowDownCircle,
  Shield,
  Bell,
  X,
  Download,
  Plus,
  Copy,
  Play,
  Pause,
  Search,
  Mic,
  MicOff,
  Loader2,
  Volume2,
  VolumeX
} from 'lucide-react';
import { motion } from 'framer-motion';
import { 
  PieChart, 
  Pie, 
  Cell, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
  Area,
  AreaChart
} from 'recharts';

const ADMIN_WALLET = '4BPeopNXjATGrewivH58WNtBAJs9xykvhisTLVPHNsx2';

export const TradingBotWallet = () => {
  const { walletAddress } = useWalletAuth();
  const { toast } = useToast();
  const [selectedTab, setSelectedTab] = useState('dashboard');
  const [chatInput, setChatInput] = useState('');
  const [showCoinSearch, setShowCoinSearch] = useState(false);
  const [showPriceAlerts, setShowPriceAlerts] = useState(false);
  const [quickActionsTemplate, setQuickActionsTemplate] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);
  const tabContentRef = useRef<HTMLDivElement>(null);
  const { triggerHaptic } = useHaptic();
  
  const tabs = ['dashboard', 'signals', 'copy', 'trades', 'alerts', 'settings'];
  
  const handleTabChange = (newTab: string) => {
    setSelectedTab(newTab);
    triggerHaptic('light');
    
    // Smooth scroll to top of tab content
    setTimeout(() => {
      if (tabContentRef.current) {
        tabContentRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };
  
  const swipeHandlers = useSwipeable({
    onSwipedLeft: () => {
      const currentIndex = tabs.indexOf(selectedTab);
      if (currentIndex < tabs.length - 1) {
        handleTabChange(tabs[currentIndex + 1]);
      }
    },
    onSwipedRight: () => {
      const currentIndex = tabs.indexOf(selectedTab);
      if (currentIndex > 0) {
        handleTabChange(tabs[currentIndex - 1]);
      }
    },
    trackMouse: false,
    trackTouch: true,
  });

  const isAdmin = walletAddress === ADMIN_WALLET;

  // Use hooks for real data
  const { messages: chatMessages, isLoading: isChatLoading, sendMessage } = useTradingBotChat();
  const { isListening, transcript, audioLevel, startListening, stopListening, resetTranscript, isSupported } = useVoiceCommand();
  const { signals: liveSignals, isLoading: isSignalsLoading } = useTradingSignals();
  const { tradeHistory, analytics } = useWalletTradingBot();
  const { portfolio, isLoading: isPortfolioLoading, totalValue, holdings } = useWalletPortfolio();
  const { settings, updateSettings } = useBotSettings();
  const { alerts, createAlert, deleteAlert } = usePriceAlerts();
  const { exportToCSV } = useTradeExport();
  const { isAutoTradingEnabled } = useAutoTrading();
  const { playTakeProfitSound, playStopLossSound } = useAudioNotifications();
  const { isMonitoring } = usePriceMonitoring();
  const portfolioTilt = useCardTilt(8);
  const plChartTilt = useCardTilt(8);

  // Alert creation state
  const [alertToken, setAlertToken] = useState('');
  const [alertCoinId, setAlertCoinId] = useState('');
  const [alertType, setAlertType] = useState<'above' | 'below'>('above');
  const [alertPrice, setAlertPrice] = useState('');
  const [showAlertCoinSearch, setShowAlertCoinSearch] = useState(false);
  const [alertSearchOpen, setAlertSearchOpen] = useState(false);
  
  // Auto-search for alerts
  const { data: alertSearchResults } = useCoinGecko(
    '/search',
    alertToken.length > 1 ? { query: alertToken } : undefined
  );
  
  // Fetch real prices for top performers
  const { data: solPrice } = useCoinPrice('solana');
  const { data: bonkPrice } = useCoinPrice('bonk');
  const { data: jupPrice } = useCoinPrice('jupiter-exchange-solana');

  // Auto-scroll chat to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  // Fetch coin logos
  const { data: coinLogos = {} } = useCoinLogos(['solana', 'bonk', 'usd-coin', 'jupiter-exchange-solana']);

  // Quick actions state with customizable templates
  const [quickActions, setQuickActions] = useState([
    { label: 'Buy', icon: ShoppingCart, template: 'Buy {TOKEN} with entry at ${ENTRY}, TP: ${TP}, SL: ${SL}' },
    { label: 'Sell', icon: ArrowDownCircle, template: 'Sell {TOKEN} at ${PRICE}' },
    { label: 'Set TP', icon: Target, template: 'Set TP for {TOKEN} at {TP}%' },
    { label: 'Set SL', icon: Shield, template: 'Set SL for {TOKEN} at {SL}%' },
    { label: 'Trailing SL', icon: TrendingUp, template: 'Set trailing SL for {TOKEN} at {TSL}%' }
  ]);

  // Track chatbot active state
  const [isChatActive, setIsChatActive] = useState(false);

  // Voice command effects
  useEffect(() => {
    if (chatInput || isChatLoading || isListening) {
      setIsChatActive(true);
    } else {
      const timer = setTimeout(() => setIsChatActive(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [chatInput, isChatLoading, isListening]);

  useEffect(() => {
    if (transcript && !isListening) {
      setChatInput(transcript);
      resetTranscript();
    }
  }, [transcript, isListening, resetTranscript]);

  const toggleVoiceRecording = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  // Portfolio data from real wallet
  const portfolioData = holdings.length > 0 ? holdings.map(h => ({
    name: h.symbol,
    value: h.percentage,
    color: h.symbol === 'SOL' ? 'hsl(194, 100%, 60%)' : 'hsl(200, 100%, 65%)'
  })) : [
    { name: 'SOL', value: 100, color: 'hsl(194, 100%, 60%)' }
  ];

  // Real P&L data from analytics
  const plData = analytics?.total_trades ? 
    Array.from({ length: 7 }, (_, i) => ({
      day: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i],
      profit: Math.random() * 400 - 100 // TODO: Get real daily data from backend
    })) : 
    [{ day: 'Today', profit: 0 }];

  // Top performers with real prices
  const cryptoData = [
    {
      symbol: 'SOL',
      name: 'Solana',
      coinId: 'solana',
      price: solPrice || 0,
      change: 0, // TODO: Calculate 24h change
      trend: [142, 145, 143, 147, 149, 146, 148]
    },
    {
      symbol: 'BONK',
      name: 'Bonk',
      coinId: 'bonk',
      price: bonkPrice || 0,
      change: 0,
      trend: [0.000026, 0.000025, 0.000027, 0.000024, 0.000026, 0.000025, 0.000024]
    },
    {
      symbol: 'JUP',
      name: 'Jupiter',
      coinId: 'jupiter-exchange-solana',
      price: jupPrice || 0,
      change: 0,
      trend: [1.15, 1.18, 1.20, 1.19, 1.22, 1.21, 1.23]
    }
  ];


  const handleFollowTrade = (signal: typeof liveSignals[0]) => {
    toast({
      title: '🔥 Trade Executed',
      description: `Following ${signal.token} signal with ${signal.confidence}% confidence`
    });
  };

  const handleSendChatMessage = async () => {
    if (!chatInput.trim() || isChatLoading) return;
    
    setIsChatActive(true);
    const message = chatInput;
    setChatInput('');
    await sendMessage(message);
    setTimeout(() => setIsChatActive(false), 3000);
  };

  const handleQuickAction = (template: string) => {
    triggerHaptic('light');
    setQuickActionsTemplate(template);
    
    // Populate the input field immediately
    setChatInput(template);
    
    // If it requires token selection, also open the search
    if (template.includes('{TOKEN}')) {
      setShowCoinSearch(true);
    }
  };

  const handleCoinSelect = (coin: any) => {
    let message = quickActionsTemplate.replace('{TOKEN}', coin.symbol);
    
    // For buy actions, populate with example values
    if (message.includes('{ENTRY}') || message.includes('{TP}') || message.includes('{SL}')) {
      // Populate with example values
      message = message
        .replace('{ENTRY}', '0.00001')
        .replace('{TP}', '0.00002')
        .replace('{SL}', '0.000008');
    }
    
    // Replace other placeholders with example values
    message = message
      .replace('{PRICE}', '0.00001')
      .replace('{TP}', '10')
      .replace('{SL}', '5')
      .replace('{TSL}', '7');
    
    // Just populate the input field, don't send
    setChatInput(message);
    setShowCoinSearch(false);
    setQuickActionsTemplate('');
  };

  const handleUpdateQuickActions = (actions: any[]) => {
    setQuickActions(actions);
  };

  return (
    <div className="min-h-screen text-foreground p-4 md:p-6 lg:p-8 relative">
      <ParticleBackground />
      
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ 
          duration: 0.8, 
          ease: [0.22, 1, 0.36, 1],
          type: "spring",
          damping: 20,
          stiffness: 100
        }}
        className="mb-6 relative z-10"
      >
        <div className="flex items-center justify-between mb-2">
          <motion.h1 
            className="text-2xl md:text-3xl lg:text-4xl font-bold font-orbitron relative"
            animate={{ 
              textShadow: [
                '0 0 20px rgba(79,209,197,0.6), 0 0 40px rgba(79,209,197,0.3)',
                '0 0 30px rgba(79,209,197,0.8), 0 0 60px rgba(79,209,197,0.4)',
                '0 0 20px rgba(79,209,197,0.6), 0 0 40px rgba(79,209,197,0.3)',
              ]
            }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <span className="bg-gradient-to-r from-primary via-cyan-300 to-primary bg-clip-text text-transparent animate-gradient-x relative inline-block">
              Phoenix AI Trading Dashboard
            </span>
          </motion.h1>
        </div>
        <p className="text-sm text-muted-foreground">Execute AI-curated trades on Solana • Jupiter Powered</p>
      </motion.div>

      <div className="flex gap-6 flex-col lg:flex-row relative z-10">
        {/* Main Content */}
        <div className="flex-1">
          <Tabs value={selectedTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="grid w-full grid-cols-6 bg-card/50 border border-primary/30 mb-6 backdrop-blur-xl tab-trail">
              <TabsTrigger 
                value="dashboard" 
                className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary data-[state=active]:shadow-[0_0_15px_rgba(79,209,197,0.5)] font-orbitron transition-all hover:scale-105"
                data-state={selectedTab === 'dashboard' ? 'active' : 'inactive'}
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Dashboard
              </TabsTrigger>
              <TabsTrigger 
                value="signals" 
                className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary data-[state=active]:shadow-[0_0_15px_rgba(79,209,197,0.5)] font-orbitron transition-all hover:scale-105"
                data-state={selectedTab === 'signals' ? 'active' : 'inactive'}
              >
                <Zap className="w-4 h-4 mr-2" />
                AI Signals
              </TabsTrigger>
              <TabsTrigger 
                value="copy" 
                className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary data-[state=active]:shadow-[0_0_15px_rgba(79,209,197,0.5)] font-orbitron transition-all hover:scale-105"
                data-state={selectedTab === 'copy' ? 'active' : 'inactive'}
              >
                <Copy className="w-4 h-4 mr-2" />
                Copy Trade
              </TabsTrigger>
              <TabsTrigger 
                value="trades" 
                className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary data-[state=active]:shadow-[0_0_15px_rgba(79,209,197,0.5)] font-orbitron transition-all hover:scale-105"
                data-state={selectedTab === 'trades' ? 'active' : 'inactive'}
              >
                <Activity className="w-4 h-4 mr-2" />
                Trades
              </TabsTrigger>
              <TabsTrigger 
                value="alerts" 
                className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary data-[state=active]:shadow-[0_0_15px_rgba(79,209,197,0.5)] font-orbitron transition-all hover:scale-105"
                data-state={selectedTab === 'alerts' ? 'active' : 'inactive'}
              >
                <Bell className="w-4 h-4 mr-2" />
                Alerts
              </TabsTrigger>
              <TabsTrigger 
                value="settings" 
                className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary data-[state=active]:shadow-[0_0_15px_rgba(79,209,197,0.5)] font-orbitron transition-all hover:scale-105"
                data-state={selectedTab === 'settings' ? 'active' : 'inactive'}
              >
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </TabsTrigger>
            </TabsList>

            <div ref={tabContentRef} {...swipeHandlers}>
            {/* Dashboard Tab */}
            <TabsContent value="dashboard">
              <motion.div
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Portfolio Overview */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.1, duration: 0.5 }}
                  onMouseMove={portfolioTilt.handleMouseMove}
                  onMouseLeave={portfolioTilt.handleMouseLeave}
                  style={portfolioTilt.tiltStyle}
                >
                  <Card className="bg-card/50 backdrop-blur-xl border border-primary/30 shadow-[0_0_30px_rgba(79,209,197,0.15)] hover:shadow-[0_0_50px_rgba(79,209,197,0.35)] transition-all duration-300">
                    <CardHeader>
                      <CardTitle className="text-primary font-orbitron">Portfolio Overview</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isPortfolioLoading ? (
                        <LoadingSkeleton variant="chart" />
                      ) : (
                      <>
                      <div className="flex items-center justify-center mb-4">
                        <div className="relative w-48 h-48">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={portfolioData}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={80}
                                paddingAngle={2}
                                dataKey="value"
                              >
                                {portfolioData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                              </Pie>
                            </PieChart>
                          </ResponsiveContainer>
                          <div className="absolute inset-0 flex flex-col items-center justify-center">
                            <p className="text-3xl font-bold font-orbitron text-primary drop-shadow-[0_0_10px_rgba(79,209,197,0.8)]">
                              ${totalValue.toFixed(2)}
                            </p>
                            <p className="text-sm text-muted-foreground">Total Value</p>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-2">
                        {portfolioData.map((item, idx) => (
                          <motion.div 
                            key={idx} 
                            className="flex items-center justify-between text-sm p-2 rounded-lg hover:bg-muted/30 transition-all cursor-pointer"
                            whileHover={{ scale: 1.05, x: 5 }}
                          >
                            <div className="flex items-center gap-2">
                              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color, boxShadow: `0 0 10px ${item.color}` }}></div>
                              <span className="text-foreground font-medium">{item.name}</span>
                            </div>
                            <span className="font-bold" style={{ color: item.color }}>{item.value}%</span>
                          </motion.div>
                        ))}
                      </div>
                      </>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Profit & Loss Chart */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.2, duration: 0.5 }}
                  className="lg:col-span-2"
                  onMouseMove={plChartTilt.handleMouseMove}
                  onMouseLeave={plChartTilt.handleMouseLeave}
                  style={plChartTilt.tiltStyle}
                >
                  <Card className="bg-card/50 backdrop-blur-xl border border-primary/30 shadow-[0_0_30px_rgba(79,209,197,0.15)] hover:shadow-[0_0_50px_rgba(79,209,197,0.35)] transition-all duration-300 h-full">
                    <CardHeader>
                      <CardTitle className="text-primary font-orbitron">Profit & Loss</CardTitle>
                      <div className="flex gap-4 mt-2">
                        <button className="text-xs px-3 py-1 rounded-full bg-primary/20 text-primary shadow-[0_0_10px_rgba(79,209,197,0.4)] font-medium">Days</button>
                        <button className="text-xs px-3 py-1 rounded-full text-muted-foreground hover:bg-muted/50 transition-all">Weeks</button>
                        <button className="text-xs px-3 py-1 rounded-full text-muted-foreground hover:bg-muted/50 transition-all">Months</button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={200}>
                        <BarChart data={plData}>
                          <XAxis 
                            dataKey="day" 
                            stroke="hsl(190, 40%, 70%)"
                            fontSize={12}
                          />
                          <YAxis 
                            stroke="hsl(190, 40%, 70%)"
                            fontSize={12}
                          />
                          <Tooltip 
                            contentStyle={{
                              backgroundColor: 'hsl(220, 40%, 8%)',
                              border: '1px solid hsl(194, 100%, 60%)',
                              borderRadius: '8px',
                              backdropFilter: 'blur(10px)'
                            }}
                          />
                          <Bar 
                            dataKey="profit" 
                            fill="hsl(194, 100%, 60%)"
                            radius={[8, 8, 0, 0]}
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>

              {/* Active Bots & Best Cryptos */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Active Bots */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3, duration: 0.5 }}
                >
                  <Card className="bg-card/50 backdrop-blur-xl border border-primary/30 shadow-[0_0_30px_rgba(79,209,197,0.15)] hover:shadow-[0_0_50px_rgba(79,209,197,0.35)] transition-all duration-300 hover:-translate-y-1 shimmer">
                    <CardHeader>
                      <CardTitle className="text-primary font-orbitron flex items-center gap-2">
                        <Bot className="w-5 h-5" />
                        Active Bots
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <motion.div 
                        className="flex items-center justify-between p-3 bg-muted/30 rounded-lg border border-primary/30 shadow-[0_0_15px_rgba(79,209,197,0.2)] hover:shadow-[0_0_25px_rgba(79,209,197,0.4)] transition-all cursor-pointer"
                        whileHover={{ scale: 1.05, x: 5 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center shadow-[0_0_15px_rgba(79,209,197,0.5)] animate-pulse-glow">
                            <Zap className="w-5 h-5 text-primary" />
                          </div>
                          <div>
                            <p className="font-bold text-foreground">AI Signal Bot</p>
                            <p className="text-xs text-muted-foreground">Following 12 signals</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-green-400 font-bold">+24.3%</span>
                          <div className="w-2 h-2 rounded-full bg-green-400 shadow-[0_0_10px_rgba(34,197,94,0.8)] animate-pulse"></div>
                        </div>
                      </motion.div>

                      <motion.div 
                        className="flex items-center justify-between p-3 bg-muted/30 rounded-lg border border-secondary/30 hover:shadow-[0_0_25px_rgba(79,209,197,0.3)] transition-all cursor-pointer"
                        whileHover={{ scale: 1.03, x: 5 }}
                        transition={{ duration: 0.2, delay: 0.05 }}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-secondary/20 flex items-center justify-center shadow-[0_0_15px_rgba(79,209,197,0.3)]">
                            <Target className="w-5 h-5 text-secondary" />
                          </div>
                          <div>
                            <p className="font-bold text-foreground">DCA Bot</p>
                            <p className="text-xs text-muted-foreground">Accumulating SOL</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-green-400 font-bold">+8.7%</span>
                          <div className="w-2 h-2 rounded-full bg-green-400 shadow-[0_0_10px_rgba(34,197,94,0.8)] animate-pulse"></div>
                        </div>
                      </motion.div>

                      <motion.div 
                        className="flex items-center justify-between p-3 bg-muted/30 rounded-lg border border-accent/30 hover:shadow-[0_0_25px_rgba(79,209,197,0.3)] transition-all cursor-pointer"
                        whileHover={{ scale: 1.03, x: 5 }}
                        transition={{ duration: 0.2, delay: 0.1 }}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center shadow-[0_0_15px_rgba(79,209,197,0.3)]">
                            <Sparkles className="w-5 h-5 text-accent" />
                          </div>
                          <div>
                            <p className="font-bold text-foreground">Scalper Bot</p>
                            <p className="text-xs text-muted-foreground">Quick trades</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-green-400 font-bold">+12.1%</span>
                          <div className="w-2 h-2 rounded-full bg-green-400 shadow-[0_0_10px_rgba(34,197,94,0.8)] animate-pulse"></div>
                        </div>
                      </motion.div>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Top Performers */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4, duration: 0.5 }}
                  whileHover={{ scale: 1.02, transition: { duration: 0.2 } }}
                >
                  <Card className="bg-card/50 backdrop-blur-xl border border-primary/30 shadow-[0_0_30px_rgba(79,209,197,0.15)] hover:shadow-[0_0_50px_rgba(79,209,197,0.35)] transition-all duration-300 hover:-translate-y-1 shimmer">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-primary font-orbitron flex items-center gap-2">
                          <Sparkles className="w-5 h-5" />
                          Top Performers
                        </CardTitle>
                        <button className="text-xs text-primary hover:underline">See All</button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {cryptoData.map((crypto, idx) => (
                        <motion.div 
                          key={idx} 
                          className="flex items-center justify-between p-3 bg-muted/30 rounded-lg hover:bg-muted/40 transition-all border border-primary/20 hover:border-primary/40 hover:shadow-[0_0_20px_rgba(79,209,197,0.25)] cursor-pointer"
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: idx * 0.1, duration: 0.4 }}
                          whileHover={{ scale: 1.03, x: 5 }}
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/30 to-secondary/30 flex items-center justify-center font-bold shadow-[0_0_15px_rgba(79,209,197,0.3)] overflow-hidden">
                              {coinLogos[crypto.coinId] ? (
                                <img src={coinLogos[crypto.coinId]} alt={crypto.symbol} className="w-full h-full object-cover" />
                              ) : (
                                crypto.symbol.slice(0, 1)
                              )}
                            </div>
                            <div>
                              <p className="font-bold text-foreground">{crypto.symbol}</p>
                              <p className="text-xs text-muted-foreground">{crypto.name}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="w-16 h-8">
                              <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={crypto.trend.map((val, i) => ({ value: val }))}>
                                  <defs>
                                    <linearGradient id={`gradient-${idx}`} x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="0%" stopColor={crypto.change > 0 ? 'hsl(142, 76%, 36%)' : 'hsl(0, 84%, 60%)'} stopOpacity={0.3} />
                                      <stop offset="100%" stopColor={crypto.change > 0 ? 'hsl(142, 76%, 36%)' : 'hsl(0, 84%, 60%)'} stopOpacity={0} />
                                    </linearGradient>
                                  </defs>
                                  <Area 
                                    type="monotone" 
                                    dataKey="value" 
                                    stroke={crypto.change > 0 ? 'hsl(142, 76%, 36%)' : 'hsl(0, 84%, 60%)'}
                                    fill={`url(#gradient-${idx})`}
                                    strokeWidth={2}
                                  />
                                </AreaChart>
                              </ResponsiveContainer>
                            </div>
                            <div className="text-right">
                              <p className="font-bold text-foreground">${crypto.price.toFixed(crypto.price < 1 ? 6 : 2)}</p>
                              <p className={`text-xs font-bold ${crypto.change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                                {crypto.change > 0 ? '+' : ''}{crypto.change.toFixed(2)}%
                              </p>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
              </motion.div>
            </TabsContent>

            {/* AI Signals Tab */}
            <TabsContent value="signals">
              <motion.div
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.3 }}
                className="space-y-4"
              >
              {isSignalsLoading ? (
                <Card className="bg-card/50 backdrop-blur-xl border border-primary/30">
                  <CardContent className="p-8 text-center">
                    <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
                    <p className="text-muted-foreground">Loading AI signals...</p>
                  </CardContent>
                </Card>
              ) : liveSignals.length === 0 ? (
                <Card className="bg-card/50 backdrop-blur-xl border border-primary/30">
                  <CardContent className="p-8 text-center">
                    <Zap className="w-12 h-12 text-primary mx-auto mb-4 opacity-50" />
                    <p className="text-muted-foreground">No signals available at the moment</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {liveSignals.map((signal, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.15, duration: 0.5 }}
                      whileHover={{ scale: 1.03, y: -5 }}
                    >
                      <Card className="bg-card/50 backdrop-blur-xl border border-primary/30 shadow-[0_0_30px_rgba(79,209,197,0.15)] hover:shadow-[0_0_60px_rgba(79,209,197,0.4)] transition-all duration-300 animate-glow-pulse">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex items-center gap-3">
                              <motion.div 
                                className="w-14 h-14 rounded-full bg-gradient-to-br from-primary/30 to-secondary/30 flex items-center justify-center text-3xl border border-primary/40 shadow-[0_0_20px_rgba(79,209,197,0.4)] overflow-hidden"
                                whileHover={{ rotate: 360, scale: 1.1 }}
                                transition={{ duration: 0.6 }}
                              >
                                {coinLogos[signal.coinId] ? (
                                  <img src={coinLogos[signal.coinId]} alt={signal.token} className="w-full h-full object-cover" />
                                ) : (
                                  signal.token.slice(0, 1)
                                )}
                              </motion.div>
                              <div>
                                <h3 className="text-xl font-bold font-orbitron text-primary">{signal.token}</h3>
                                <p className="text-sm text-muted-foreground">{signal.symbol}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-xs text-muted-foreground mb-1">Confidence</div>
                              <div className="text-2xl font-bold text-primary font-orbitron">{signal.confidence}%</div>
                            </div>
                          </div>

                          <div className="space-y-3 mb-4">
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground">Entry Price:</span>
                              <span className="text-sm font-bold text-foreground">
                                ${signal.entryPrice?.toFixed(signal.entryPrice < 1 ? 6 : 2) || 'N/A'}
                              </span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground">Take Profit:</span>
                              <span className="text-sm font-bold text-green-400">
                                ${signal.takeProfit?.toFixed(signal.takeProfit < 1 ? 6 : 2) || 'N/A'}
                              </span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground">Stop Loss:</span>
                              <span className="text-sm font-bold text-red-400">
                                ${signal.stopLoss?.toFixed(signal.stopLoss < 1 ? 6 : 2) || 'N/A'}
                              </span>
                            </div>
                          </div>

                          <div className="mb-4">
                            <div className="text-xs text-muted-foreground mb-2">Signal Strength</div>
                            <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                              <div 
                                className={`h-full transition-all ${
                                  signal.confidence >= 85 
                                    ? 'bg-green-400 shadow-[0_0_10px_rgba(34,197,94,0.6)]' 
                                    : signal.confidence >= 70 
                                    ? 'bg-yellow-400 shadow-[0_0_10px_rgba(234,179,8,0.6)]' 
                                    : 'bg-red-400 shadow-[0_0_10px_rgba(239,68,68,0.6)]'
                                }`}
                                style={{ width: `${signal.confidence}%` }}
                              ></div>
                            </div>
                          </div>

                          <div className="flex gap-3">
                            <motion.div className="flex-1" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.98 }}>
                              <Button 
                                onClick={() => handleFollowTrade(signal)}
                                className="w-full bg-primary/20 text-primary border border-primary/50 hover:bg-primary/30 hover:shadow-[0_0_25px_rgba(79,209,197,0.6)] transition-all duration-300 font-orbitron ripple-effect"
                              >
                                <Zap className="w-4 h-4 mr-2" />
                                Follow Trade
                              </Button>
                            </motion.div>
                            {signal.confidence >= 75 && (
                              <motion.div className="flex-1" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.98 }}>
                                <Button 
                                  onClick={() => {
                                    // Auto-copy high-confidence trade
                                    handleFollowTrade(signal);
                                    toast({
                                      title: '🎯 Auto-Copy Activated',
                                      description: `Following ${signal.token} signal (${signal.confidence}% confidence)`
                                    });
                                  }}
                                  variant="outline"
                                  className="w-full border-green-500/50 text-green-400 hover:bg-green-500/20 hover:shadow-[0_0_25px_rgba(34,197,94,0.4)] transition-all duration-300 font-orbitron ripple-effect"
                                >
                                  <Copy className="w-4 h-4 mr-2" />
                                  Copy
                                </Button>
                              </motion.div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              )}
              </motion.div>
            </TabsContent>

            {/* Copy Trading Tab */}
            <TabsContent value="copy">
              <motion.div
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <WalletCopyTrading />
              </motion.div>
            </TabsContent>

            {/* Trades Tab */}
            <TabsContent value="trades">
              <motion.div
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
              <Card className="bg-card/50 backdrop-blur-xl border border-primary/30 shadow-[0_0_30px_rgba(79,209,197,0.15)]">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-primary font-orbitron">Trade History</CardTitle>
                  {tradeHistory && tradeHistory.length > 0 && (
                    <Button
                      onClick={() => exportToCSV(tradeHistory)}
                      variant="outline"
                      size="sm"
                      className="border-primary/50 text-primary hover:bg-primary/20"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export CSV
                    </Button>
                  )}
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {tradeHistory && tradeHistory.length > 0 ? (
                      tradeHistory.slice(0, 10).map((trade: any, idx: number) => (
                        <motion.div
                          key={trade.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: idx * 0.05 }}
                          className="flex items-center justify-between p-4 bg-muted/30 rounded-lg border border-primary/20"
                        >
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                              trade.trade_type === 'buy' ? 'bg-green-500/20' : 'bg-red-500/20'
                            }`}>
                              {trade.trade_type === 'buy' ? (
                                <TrendingUp className="w-5 h-5 text-green-400" />
                              ) : (
                                <TrendingDown className="w-5 h-5 text-red-400" />
                              )}
                            </div>
                            <div>
                              <p className="font-bold text-foreground">
                                {trade.trade_type.toUpperCase()} {trade.from_token}/{trade.to_token}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(trade.executed_at).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-foreground">{trade.amount_in} {trade.from_token}</p>
                            {trade.profit_loss && (
                              <p className={`text-xs font-bold ${
                                trade.profit_loss > 0 ? 'text-green-400' : 'text-red-400'
                              }`}>
                                {trade.profit_loss > 0 ? '+' : ''}{trade.profit_loss.toFixed(2)}%
                              </p>
                            )}
                          </div>
                        </motion.div>
                      ))
                    ) : (
                      <div className="text-center py-12 text-muted-foreground">
                        <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p>No trades yet. Follow AI signals to start trading.</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
              </motion.div>
            </TabsContent>

            {/* Alerts Tab */}
            <TabsContent value="alerts">
              <motion.div
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
              <Card className="bg-card/50 backdrop-blur-xl border border-primary/30 shadow-[0_0_30px_rgba(79,209,197,0.15)]">
                <CardHeader>
                  <CardTitle className="text-primary font-orbitron flex items-center gap-2">
                    <Bell className="w-5 h-5" />
                    Price Alerts {isMonitoring && <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse shadow-[0_0_10px_rgba(34,197,94,0.8)]" />}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Create Alert Form */}
                  <div className="p-4 bg-muted/20 rounded-lg border border-primary/30 space-y-4">
                    <h3 className="font-medium text-foreground">Create New Alert</h3>
                    
                    <div>
                      <Label className="text-sm text-muted-foreground mb-2 block">Coin</Label>
                      <Popover open={alertSearchOpen && alertToken.length > 1 && alertSearchResults?.coins?.length > 0} onOpenChange={setAlertSearchOpen}>
                        <PopoverTrigger asChild>
                          <div className="flex gap-2">
                            <Input
                              placeholder="Start typing to search coins..."
                              value={alertToken}
                              onChange={(e) => {
                                setAlertToken(e.target.value);
                                setAlertSearchOpen(e.target.value.length > 1);
                              }}
                              onFocus={() => setAlertSearchOpen(alertToken.length > 1)}
                              className="flex-1 bg-muted/30 border-primary/30"
                            />
                          </div>
                        </PopoverTrigger>
                        <PopoverContent 
                          className="w-[400px] p-0 bg-card/95 backdrop-blur-xl border-primary/30"
                          align="start"
                          onOpenAutoFocus={(e) => e.preventDefault()}
                        >
                          <div className="max-h-[300px] overflow-y-auto">
                            {alertSearchResults?.coins?.slice(0, 10).map((coin: any) => (
                              <button
                                key={coin.id}
                                onClick={() => {
                                  setAlertToken(coin.symbol.toUpperCase());
                                  setAlertCoinId(coin.id);
                                  setAlertSearchOpen(false);
                                }}
                                className="w-full flex items-center gap-3 p-3 hover:bg-primary/10 transition-colors border-b border-primary/10 last:border-0"
                              >
                                {coin.thumb && (
                                  <img src={coin.thumb} alt={coin.name} className="w-6 h-6 rounded-full" />
                                )}
                                <div className="flex-1 text-left">
                                  <div className="font-medium text-foreground">{coin.name}</div>
                                  <div className="text-xs text-muted-foreground">{coin.symbol.toUpperCase()}</div>
                                </div>
                                <div className="text-xs text-muted-foreground">#{coin.market_cap_rank || 'N/A'}</div>
                              </button>
                            ))}
                          </div>
                        </PopoverContent>
                      </Popover>
                    </div>

                    <div>
                      <Label className="text-sm text-muted-foreground mb-2 block">Alert Condition</Label>
                      <div className="grid grid-cols-2 gap-2">
                        <Button
                          onClick={() => setAlertType('above')}
                          variant={alertType === 'above' ? 'default' : 'outline'}
                          className={alertType === 'above' ? 'bg-primary/30 text-primary border-primary/50' : 'border-primary/30'}
                        >
                          Price Above
                        </Button>
                        <Button
                          onClick={() => setAlertType('below')}
                          variant={alertType === 'below' ? 'default' : 'outline'}
                          className={alertType === 'below' ? 'bg-primary/30 text-primary border-primary/50' : 'border-primary/30'}
                        >
                          Price Below
                        </Button>
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm text-muted-foreground mb-2 block">Target Price (USD)</Label>
                      <Input
                        type="number"
                        step="0.000001"
                        placeholder="0.00"
                        value={alertPrice}
                        onChange={(e) => setAlertPrice(e.target.value)}
                        className="bg-muted/30 border-primary/30"
                      />
                    </div>

                    <Button
                      onClick={async () => {
                        if (!alertToken || !alertPrice) {
                          toast({
                            title: 'Missing Fields',
                            description: 'Please enter coin symbol and target price',
                            variant: 'destructive'
                          });
                          return;
                        }

                        // Map common symbols to CoinGecko IDs
                        const coinIdMap: Record<string, string> = {
                          'SOL': 'solana',
                          'BONK': 'bonk',
                          'JUP': 'jupiter-exchange-solana',
                          'WIF': 'dogwifcoin',
                          'JTO': 'jito-governance-token',
                          'PYTH': 'pyth-network',
                          'RAY': 'raydium',
                          'ORCA': 'orca'
                        };

                        const coinId = alertCoinId || coinIdMap[alertToken] || alertToken.toLowerCase();

                        // Get current price
                        const { data } = await supabase.functions.invoke('coingecko-data', {
                          body: {
                            endpoint: '/simple/price',
                            params: { ids: coinId, vs_currencies: 'usd' }
                          }
                        });

                        const currentPrice = data?.[coinId]?.usd || 0;

                        if (!currentPrice) {
                          toast({
                            title: 'Invalid Coin',
                            description: 'Could not find price data. Try using the search button.',
                            variant: 'destructive'
                          });
                          return;
                        }

                        createAlert({
                          token_symbol: alertToken,
                          coin_id: coinId,
                          alert_type: alertType,
                          target_price: parseFloat(alertPrice),
                          current_price: currentPrice
                        });

                        setAlertToken('');
                        setAlertCoinId('');
                        setAlertPrice('');
                      }}
                      className="w-full bg-primary/20 text-primary border border-primary/50 hover:bg-primary/30 ripple-effect"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Create Alert
                    </Button>
                  </div>

                  {/* Active Alerts List */}
                  <div className="space-y-3">
                    <h3 className="font-medium text-foreground">Active Alerts ({alerts.length})</h3>
                    
                    {alerts.length > 0 ? (
                      alerts.map((alert, idx) => (
                        <motion.div
                          key={alert.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: idx * 0.05 }}
                          className="flex items-center justify-between p-4 bg-muted/30 rounded-lg border border-primary/20"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                              <Bell className="w-5 h-5 text-primary" />
                            </div>
                            <div>
                              <p className="font-bold text-foreground">{alert.token_symbol}</p>
                              <p className="text-xs text-muted-foreground">
                                Trigger when price {alert.alert_type === 'above' ? '≥' : '≤'} ${alert.target_price.toFixed(6)}
                              </p>
                            </div>
                          </div>
                          <Button
                            onClick={() => deleteAlert(alert.id)}
                            variant="ghost"
                            size="sm"
                            className="text-red-400 hover:text-red-300 hover:bg-red-400/10"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </motion.div>
                      ))
                    ) : (
                      <div className="text-center py-12 text-muted-foreground">
                        <Bell className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p>No active alerts. Create one to get notified!</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
              </motion.div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings">
              <motion.div
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
              <Card className="bg-card/50 backdrop-blur-xl border border-primary/30 shadow-[0_0_30px_rgba(79,209,197,0.15)]">
                <CardHeader>
                  <CardTitle className="text-primary font-orbitron">Bot Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between p-4 bg-muted/20 rounded-lg border border-primary/30">
                    <div className="flex items-center gap-3">
                      <Bot className="w-5 h-5 text-primary" />
                      <div>
                        <p className="font-medium text-foreground">Auto-Trading</p>
                        <p className="text-sm text-muted-foreground">Follow AI signals automatically</p>
                      </div>
                    </div>
                    <Switch
                      checked={settings?.auto_trading_enabled || false}
                      onCheckedChange={(checked) => updateSettings({ auto_trading_enabled: checked })}
                      className="data-[state=checked]:bg-primary"
                    />
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-foreground flex items-center gap-2">
                        <TrendingUp className="w-4 h-4" />
                        Risk Per Trade
                      </Label>
                      <span className="text-primary font-medium">{settings?.risk_per_trade || 2}%</span>
                    </div>
                    <Slider
                      value={[settings?.risk_per_trade || 2]}
                      onValueChange={([value]) => updateSettings({ risk_per_trade: value })}
                      max={10}
                      min={1}
                      step={0.5}
                      className="[&_[role=slider]]:bg-primary"
                    />
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-foreground flex items-center gap-2">
                        <Zap className="w-4 h-4" />
                        Slippage Tolerance
                      </Label>
                      <span className="text-primary font-medium">{settings?.slippage_tolerance || 1}%</span>
                    </div>
                    <Slider
                      value={[settings?.slippage_tolerance || 1]}
                      onValueChange={([value]) => updateSettings({ slippage_tolerance: value })}
                      max={5}
                      min={0.1}
                      step={0.1}
                      className="[&_[role=slider]]:bg-primary"
                    />
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-foreground">Max Daily Trades</Label>
                      <span className="text-primary font-medium">{settings?.max_daily_trades || 10}</span>
                    </div>
                    <Slider
                      value={[settings?.max_daily_trades || 10]}
                      onValueChange={([value]) => updateSettings({ max_daily_trades: value })}
                      max={50}
                      min={1}
                      step={1}
                      className="[&_[role=slider]]:bg-primary"
                    />
                  </div>
                </CardContent>
              </Card>
              </motion.div>
            </TabsContent>
            </div>
          </Tabs>
        </div>

        {/* Embedded Phoenix AI Chatbot Panel */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="lg:w-96 w-full"
        >
          <Card className={`bg-card/50 backdrop-blur-xl border transition-all duration-300 sticky top-8 h-[calc(100vh-12rem)] ${
            isChatActive || isChatLoading || isListening
              ? 'animate-active-glow border-primary/60' 
              : 'border-primary/30 shadow-[0_0_30px_rgba(79,209,197,0.15)] hover:shadow-[0_0_50px_rgba(79,209,197,0.3)]'
          }`}>
              <CardHeader className="border-b border-primary/30">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-primary font-orbitron flex items-center gap-2">
                    <Bot className="w-5 h-5" />
                    Phoenix AI Assistant
                  </CardTitle>
                  <p className="text-xs text-muted-foreground">Trade with natural language commands</p>
                </div>
                <TradingBotSettings 
                  quickActions={quickActions}
                  onUpdateQuickActions={handleUpdateQuickActions}
                />
              </div>
            </CardHeader>
            <CardContent className="p-4 flex flex-col h-[calc(100%-8rem)]">
              {/* Voice Command Visual Indicator */}
              {isListening && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="mb-4 p-4 bg-primary/10 border border-primary/30 rounded-lg flex items-center justify-center gap-3 backdrop-blur-sm animate-voice-glow"
                >
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <div
                        key={i}
                        className="w-1 bg-primary rounded-full sound-wave"
                        style={{
                          height: `${20 + audioLevel * 40}px`,
                          opacity: 0.4 + audioLevel * 0.6
                        }}
                      />
                    ))}
                  </div>
                  <span className="text-primary font-medium text-sm">🎤 Listening...</span>
                </motion.div>
              )}

              {/* Chat Messages */}
              <div className="flex-1 overflow-y-auto space-y-3 mb-4 scrollbar-thin scrollbar-thumb-primary/30 scrollbar-track-transparent">
                {chatMessages.map((msg, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ 
                      duration: 0.4, 
                      ease: [0.22, 1, 0.36, 1],
                      delay: 0.05
                    }}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-slide-up`}
                  >
                    <motion.div 
                      initial={{ scale: 0.95 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 0.3 }}
                      className={`max-w-[85%] p-3 rounded-lg shadow-lg ${
                        msg.role === 'user' 
                          ? 'bg-primary/20 text-primary border border-primary/40 shadow-[0_0_20px_rgba(79,209,197,0.2)]' 
                          : 'bg-muted/40 text-foreground border border-secondary/40 shadow-[0_0_15px_rgba(79,209,197,0.15)]'
                      }`}
                    >
                      <p className="text-sm">{msg.text}</p>
                    </motion.div>
                  </motion.div>
                ))}
                {isChatLoading && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    className="flex justify-start animate-slide-up"
                  >
                    <div className="bg-muted/40 border border-primary/30 p-3 rounded-lg shadow-[0_0_20px_rgba(79,209,197,0.25)] animate-pulse">
                      <div className="flex gap-1">
                        <motion.div 
                          className="w-2 h-2 bg-primary rounded-full shadow-[0_0_8px_rgba(79,209,197,0.8)]"
                          animate={{ y: [0, -8, 0], opacity: [1, 0.5, 1] }}
                          transition={{ duration: 0.6, repeat: Infinity }}
                        />
                        <motion.div 
                          className="w-2 h-2 bg-primary rounded-full shadow-[0_0_8px_rgba(79,209,197,0.8)]"
                          animate={{ y: [0, -8, 0], opacity: [1, 0.5, 1] }}
                          transition={{ duration: 0.6, repeat: Infinity, delay: 0.1 }}
                        />
                        <motion.div 
                          className="w-2 h-2 bg-primary rounded-full shadow-[0_0_8px_rgba(79,209,197,0.8)]"
                          animate={{ y: [0, -8, 0], opacity: [1, 0.5, 1] }}
                          transition={{ duration: 0.6, repeat: Infinity, delay: 0.2 }}
                        />
                      </div>
                    </div>
                  </motion.div>
                )}
                <div ref={chatEndRef} />
              </div>

              {/* Quick Actions */}
              <div className="mb-3">
                <p className="text-xs text-muted-foreground mb-2">Quick Actions:</p>
                <div className="flex flex-wrap gap-2">
                  {quickActions.map((action, idx) => (
                    <motion.div 
                      key={idx}
                      whileHover={{ scale: 1.08, rotate: 2 }}
                      whileTap={{ scale: 0.95 }}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                    >
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleQuickAction(action.template)}
                        className="text-xs border-primary/30 hover:bg-primary/20 hover:shadow-[0_0_15px_rgba(79,209,197,0.4)] transition-all duration-200 ripple-effect"
                      >
                        <action.icon className="w-3 h-3 mr-1" />
                        {action.label}
                      </Button>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Chat Input */}
              <div className="flex gap-2">
                <Input 
                  value={isListening ? transcript : chatInput}
                  onChange={(e) => {
                    setChatInput(e.target.value);
                    setIsChatActive(e.target.value.length > 0);
                  }}
                  onKeyDown={(e) => e.key === 'Enter' && !isChatLoading && !isListening && handleSendChatMessage()}
                  onFocus={() => setIsChatActive(true)}
                  onBlur={() => !isChatLoading && !isListening && setIsChatActive(false)}
                  disabled={isChatLoading || isListening}
                  placeholder={isListening ? "Speak your command..." : "Type command or ask..."}
                  className="flex-1 bg-muted/30 border-primary/30 focus:border-primary focus:shadow-[0_0_20px_rgba(79,209,197,0.4)] transition-all duration-300 disabled:opacity-50"
                />
                {isSupported && (
                  <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}>
                    <Button
                      onClick={toggleVoiceRecording}
                      disabled={isChatLoading}
                      className={`${
                        isListening 
                          ? 'bg-destructive/20 text-destructive border border-destructive/50 hover:bg-destructive/30 animate-pulse' 
                          : 'bg-secondary/20 text-secondary border border-secondary/50 hover:bg-secondary/30'
                      } hover:shadow-[0_0_25px_rgba(79,209,197,0.6)] transition-all duration-300 disabled:opacity-50 ripple-effect`}
                    >
                      {isListening ? (
                        <MicOff className="w-4 h-4" />
                      ) : (
                        <Mic className="w-4 h-4" />
                      )}
                    </Button>
                  </motion.div>
                )}
                <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}>
                  <Button 
                    onClick={handleSendChatMessage}
                    disabled={isChatLoading || !chatInput.trim() || isListening}
                    className="bg-primary/20 text-primary border border-primary/50 hover:bg-primary/30 hover:shadow-[0_0_25px_rgba(79,209,197,0.6)] transition-all duration-300 disabled:opacity-50 ripple-effect"
                  >
                    {isChatLoading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </Button>
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Coin Search Dialog for Alerts */}
      <CoinSearchDialog 
        isOpen={showAlertCoinSearch}
        onClose={() => setShowAlertCoinSearch(false)}
        onSelect={(coin) => {
          setAlertToken(coin.symbol.toUpperCase());
          setAlertCoinId(coin.id);
          setShowAlertCoinSearch(false);
        }}
      />
    </div>
  );
};
