import { motion } from "framer-motion";
import { ReactNode } from "react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

interface ScrollAnimated3DProps {
  children: ReactNode;
  delay?: number;
  className?: string;
}

export const ScrollAnimated3D = ({ children, delay = 0, className = "" }: ScrollAnimated3DProps) => {
  const { ref, isVisible } = useScrollAnimation({ threshold: 0.05 });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 10 }}
      animate={isVisible ? { opacity: 1, y: 0 } : { opacity: 0, y: 10 }}
      transition={{
        duration: 0.3,
        delay,
        ease: "easeOut",
      }}
      className={className}
      style={{ willChange: isVisible ? 'auto' : 'opacity, transform' }}
    >
      {children}
    </motion.div>
  );
};
