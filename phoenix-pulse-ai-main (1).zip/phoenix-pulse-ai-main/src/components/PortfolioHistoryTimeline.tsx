import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { TrendingUp, TrendingDown, Calendar } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

interface PortfolioSnapshot {
  date: string;
  totalValue: number;
  profitPercentage: number;
  totalInvested: number;
}

interface PortfolioHistoryTimelineProps {
  currentValue: number;
  currentInvested: number;
  profitPercentage: number;
}

export const PortfolioHistoryTimeline = ({
  currentValue,
  currentInvested,
  profitPercentage,
}: PortfolioHistoryTimelineProps) => {
  const [history, setHistory] = useState<PortfolioSnapshot[]>([]);

  useEffect(() => {
    // Load history from localStorage
    const storedHistory = localStorage.getItem("portfolioHistory");
    if (storedHistory) {
      setHistory(JSON.parse(storedHistory));
    }
  }, []);

  useEffect(() => {
    // Save current snapshot daily
    const today = format(new Date(), "yyyy-MM-dd");
    const lastSnapshot = history[history.length - 1];

    if (!lastSnapshot || lastSnapshot.date !== today) {
      const newSnapshot: PortfolioSnapshot = {
        date: today,
        totalValue: currentValue,
        profitPercentage,
        totalInvested: currentInvested,
      };

      const updatedHistory = [...history, newSnapshot].slice(-30); // Keep last 30 days
      setHistory(updatedHistory);
      localStorage.setItem("portfolioHistory", JSON.stringify(updatedHistory));
    }
  }, [currentValue, profitPercentage, currentInvested]);

  const chartData = history.map((snapshot) => ({
    date: format(new Date(snapshot.date), "MMM dd"),
    value: snapshot.totalValue,
    profit: snapshot.profitPercentage,
  }));

  const overallChange =
    history.length > 1
      ? ((history[history.length - 1].totalValue - history[0].totalValue) /
          history[0].totalValue) *
        100
      : 0;

  const isPositive = overallChange >= 0;

  if (history.length === 0) {
    return (
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <Calendar className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-bold">Portfolio History</h3>
        </div>
        <p className="text-muted-foreground text-sm">
          Start tracking your portfolio to see historical performance data.
        </p>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="p-6 hover:shadow-lg hover:border-primary/50 transition-all duration-300">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Calendar className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-bold">Portfolio History</h3>
          </div>
          <div className="flex items-center gap-2">
            {isPositive ? (
              <TrendingUp className="w-5 h-5 text-green-500" />
            ) : (
              <TrendingDown className="w-5 h-5 text-red-500" />
            )}
            <span
              className={`text-sm font-bold ${
                isPositive ? "text-green-500" : "text-red-500"
              }`}
            >
              {isPositive ? "+" : ""}
              {overallChange.toFixed(2)}%
            </span>
          </div>
        </div>

        <ResponsiveContainer width="100%" height={250}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis
              dataKey="date"
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
            />
            <YAxis
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
              tickFormatter={(value) => `$${value.toLocaleString()}`}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
              }}
              formatter={(value: any, name: string) =>
                name === "value"
                  ? `$${value.toLocaleString()}`
                  : `${value.toFixed(2)}%`
              }
            />
            <Line
              type="monotone"
              dataKey="value"
              stroke="hsl(var(--primary))"
              strokeWidth={2}
              dot={{ fill: "hsl(var(--primary))", r: 4 }}
              activeDot={{ r: 6 }}
            />
          </LineChart>
        </ResponsiveContainer>

        <div className="grid grid-cols-3 gap-4 mt-6">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Start Value</p>
            <p className="text-sm font-bold">
              ${history[0].totalValue.toLocaleString()}
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Current Value</p>
            <p className="text-sm font-bold">
              $
              {history[history.length - 1].totalValue.toLocaleString()}
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Days Tracked</p>
            <p className="text-sm font-bold">{history.length}</p>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};
