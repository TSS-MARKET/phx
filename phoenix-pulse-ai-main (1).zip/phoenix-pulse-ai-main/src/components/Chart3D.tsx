import { useRef, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Line, Text } from "@react-three/drei";
import * as THREE from "three";

interface Chart3DProps {
  data: Array<{ time: string; price: number }>;
  color?: string;
}

const PriceLine = ({ data, color = "#06b6d4" }: Chart3DProps) => {
  const groupRef = useRef<THREE.Group>(null);

  // Convert data to 3D points
  const points = useMemo(() => {
    if (!data || data.length === 0) return [];
    
    const maxPrice = Math.max(...data.map(d => d.price));
    const minPrice = Math.min(...data.map(d => d.price));
    const priceRange = maxPrice - minPrice;

    return data.map((d, i) => {
      const x = (i / (data.length - 1)) * 10 - 5; // -5 to 5
      const y = ((d.price - minPrice) / priceRange) * 5; // 0 to 5
      const z = 0;
      return new THREE.Vector3(x, y, z);
    });
  }, [data]);

  useFrame(({ clock }) => {
    if (groupRef.current) {
      groupRef.current.rotation.z = Math.sin(clock.getElapsedTime() * 0.2) * 0.05;
    }
  });

  if (points.length === 0) return null;

  return (
    <group ref={groupRef}>
      <Line
        points={points}
        color={color}
        lineWidth={3}
        opacity={0.8}
        transparent
      />
      
      {/* Add glowing effect */}
      <Line
        points={points}
        color={color}
        lineWidth={6}
        opacity={0.2}
        transparent
      />
      
      {/* Data points */}
      {points.map((point, i) => (
        <mesh key={i} position={point}>
          <sphereGeometry args={[0.1, 16, 16]} />
          <meshStandardMaterial
            color={color}
            emissive={color}
            emissiveIntensity={0.5}
          />
        </mesh>
      ))}
    </group>
  );
};

const GridHelper = () => {
  return (
    <>
      <gridHelper args={[10, 10, "#06b6d4", "#1a4d5c"]} position={[0, -0.5, 0]} />
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1} />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#06b6d4" />
    </>
  );
};

export const Chart3D = ({ data }: Chart3DProps) => {
  if (!data || data.length === 0) {
    return (
      <div className="w-full h-[400px] flex items-center justify-center glass-card rounded-xl">
        <p className="text-muted-foreground">Loading chart data...</p>
      </div>
    );
  }

  return (
    <div className="w-full h-[400px] glass-card rounded-xl overflow-hidden border border-primary/20">
      <Canvas
        camera={{ position: [8, 5, 8], fov: 50 }}
        style={{ background: "transparent" }}
      >
        <GridHelper />
        <PriceLine data={data} />
        <OrbitControls
          enableDamping
          dampingFactor={0.05}
          rotateSpeed={0.5}
          enableZoom={true}
          enablePan={true}
        />
      </Canvas>
      
      {/* Labels */}
      <div className="absolute bottom-4 left-4 right-4 flex justify-between text-xs text-muted-foreground">
        <span>{data[0]?.time}</span>
        <span className="text-primary font-semibold">Interactive 3D Chart</span>
        <span>{data[data.length - 1]?.time}</span>
      </div>
    </div>
  );
};
