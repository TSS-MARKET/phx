import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, TrendingUp } from "lucide-react";
import { useCoinGecko } from "@/hooks/useCoinGecko";
import { motion } from "framer-motion";

interface CoinSearchDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (coin: any) => void;
}

export const CoinSearchDialog = ({ isOpen, onClose, onSelect }: CoinSearchDialogProps) => {
  const [searchQuery, setSearchQuery] = useState("");
  const { data: searchResults, isLoading } = useCoinGecko(
    "/search",
    searchQuery ? { query: searchQuery } : undefined
  );

  const coins = searchResults?.coins || [];

  const handleSelect = (coin: any) => {
    onSelect({
      id: coin.id,
      symbol: coin.symbol.toUpperCase(),
      name: coin.name,
      image: coin.large || coin.thumb,
    });
    onClose();
    setSearchQuery("");
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-card max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="text-2xl glow-cyan">Search Cryptocurrency</DialogTitle>
        </DialogHeader>
        
        <div className="relative">
          <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
          <Input
            placeholder="Search by name or symbol (e.g., Bitcoin, BTC)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            autoFocus
          />
        </div>

        <div className="space-y-2 overflow-y-auto max-h-[400px]">
          {isLoading && (
            <div className="text-center py-8 text-muted-foreground">
              Searching...
            </div>
          )}
          
          {!searchQuery && (
            <div className="text-center py-8 text-muted-foreground">
              <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Start typing to search for cryptocurrencies</p>
            </div>
          )}

          {searchQuery && coins.length === 0 && !isLoading && (
            <div className="text-center py-8 text-muted-foreground">
              No cryptocurrencies found
            </div>
          )}

          {coins.map((coin: any, index: number) => (
            <Button
              key={coin.id}
              variant="ghost"
              className="w-full justify-start p-4 h-auto hover:bg-primary/10 transition-colors"
              onClick={() => handleSelect(coin)}
            >
              <img
                src={coin.thumb}
                alt={coin.name}
                className="w-8 h-8 rounded-full mr-3 flex-shrink-0"
              />
              <div className="flex-1 text-left min-w-0">
                <div className="font-bold truncate">{coin.name}</div>
                <div className="text-sm text-muted-foreground truncate">
                  {coin.symbol.toUpperCase()}
                </div>
              </div>
              {coin.market_cap_rank && (
                <div className="text-xs text-muted-foreground flex-shrink-0 ml-2">
                  Rank #{coin.market_cap_rank}
                </div>
              )}
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
};
