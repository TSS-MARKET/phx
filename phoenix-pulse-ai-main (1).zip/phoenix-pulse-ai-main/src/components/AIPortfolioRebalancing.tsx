import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { Brain, Sparkles, AlertCircle, Loader2, CheckCircle, TrendingUp, TrendingDown, Info, Activity, Shield, Target, ArrowRight, Wallet, Check } from "lucide-react";
import { WalletHolding } from "@/hooks/useWalletPortfolio";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@solana/wallet-adapter-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";

interface AIPortfolioRebalancingProps {
  holdings: WalletHolding[];
  totalValue: number;
}

interface RebalancingSuggestion {
  type: "reduce" | "increase" | "diversify";
  token: string;
  currentPercent: number;
  targetPercent: number;
  amount: number;
  reason: string;
}

export const AIPortfolioRebalancing = ({ holdings, totalValue }: AIPortfolioRebalancingProps) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [showExecutionDialog, setShowExecutionDialog] = useState(false);
  const [selectedSuggestion, setSelectedSuggestion] = useState<RebalancingSuggestion | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const { toast } = useToast();
  const { connected } = useWallet();

  const portfolioHealth = useMemo(() => {
    if (holdings.length === 0) return { status: "Unknown", riskLevel: "N/A", score: 0 };

    const maxConcentration = Math.max(...holdings.map(h => h.percentage));
    const diversificationScore = holdings.length >= 5 ? 100 : (holdings.length / 5) * 100;
    
    let riskScore = 0;
    if (maxConcentration > 70) riskScore = 100;
    else if (maxConcentration > 50) riskScore = 80;
    else if (maxConcentration > 40) riskScore = 60;
    else if (maxConcentration > 30) riskScore = 40;
    else riskScore = 20;

    const combinedScore = ((100 - riskScore) + diversificationScore) / 2;

    if (combinedScore >= 80) return { status: "Excellent", riskLevel: "Low", score: combinedScore, color: "text-green-400" };
    if (combinedScore >= 60) return { status: "Good", riskLevel: "Moderate", score: combinedScore, color: "text-cyan-400" };
    if (combinedScore >= 40) return { status: "Fair", riskLevel: "Medium-High", score: combinedScore, color: "text-yellow-400" };
    return { status: "Needs Attention", riskLevel: "High", score: combinedScore, color: "text-red-400" };
  }, [holdings]);

  const rebalancingSuggestions = useMemo(() => {
    if (holdings.length === 0 || !showSuggestions) return [];

    const suggestions: RebalancingSuggestion[] = [];
    
    // Check for over-concentration
    const sortedHoldings = [...holdings].sort((a, b) => b.percentage - a.percentage);
    const maxHolding = sortedHoldings[0];
    
    if (maxHolding && maxHolding.percentage > 40) {
      suggestions.push({
        type: "reduce",
        token: maxHolding.token,
        currentPercent: maxHolding.percentage,
        targetPercent: 30,
        amount: ((maxHolding.percentage - 30) / 100) * totalValue,
        reason: "Reduce concentration risk - position is over-allocated"
      });
    }

    // Check for under-diversification
    if (holdings.length < 5) {
      suggestions.push({
        type: "diversify",
        token: "Additional Assets",
        currentPercent: 0,
        targetPercent: 15,
        amount: (15 / 100) * totalValue,
        reason: "Increase diversification by adding more quality assets"
      });
    }

    // Small positions that need adjustment
    const smallPositions = holdings.filter(h => h.percentage < 8 && h.percentage > 2);
    if (smallPositions.length > 0) {
      const smallestHolding = smallPositions[0];
      suggestions.push({
        type: "increase",
        token: smallestHolding.token,
        currentPercent: smallestHolding.percentage,
        targetPercent: 12,
        amount: ((12 - smallestHolding.percentage) / 100) * totalValue,
        reason: "Increase allocation for better portfolio impact"
      });
    }

    return suggestions.slice(0, 3);
  }, [holdings, totalValue, showSuggestions]);

  const keyActions = useMemo(() => {
    if (!showSuggestions || rebalancingSuggestions.length === 0) return [];
    
    return rebalancingSuggestions.map(suggestion => {
      if (suggestion.type === "reduce") {
        return `Sell ${(suggestion.currentPercent - suggestion.targetPercent).toFixed(0)}% of ${suggestion.token}`;
      } else if (suggestion.type === "increase") {
        return `Buy more ${suggestion.token} to reach ${suggestion.targetPercent.toFixed(0)}% allocation`;
      } else {
        return "Diversify into established large-cap cryptocurrencies (e.g., BTC, ETH) and blue-chip altcoins";
      }
    });
  }, [rebalancingSuggestions, showSuggestions]);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsAnalyzing(false);
    setShowSuggestions(true);
    toast({
      title: "Analysis Complete",
      description: "AI has analyzed your portfolio and generated rebalancing suggestions.",
    });
  };

  const handleExecuteSuggestion = (suggestion: RebalancingSuggestion) => {
    if (!connected) {
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet to execute trades.",
        variant: "destructive",
      });
      return;
    }
    setSelectedSuggestion(suggestion);
    setShowExecutionDialog(true);
  };

  const executeRebalancing = async () => {
    if (!selectedSuggestion) return;
    
    setIsExecuting(true);
    
    // Simulate trade execution
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    setIsExecuting(false);
    setShowExecutionDialog(false);
    
    toast({
      title: "Rebalancing Executed",
      description: `Successfully executed ${selectedSuggestion.type} action for ${selectedSuggestion.token}`,
    });
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="glass-card hover-glow border-primary/20">
          <CardHeader className="border-b border-primary/10">
            <CardTitle className="flex items-center justify-between">
              <motion.div 
                className="flex items-center gap-3"
                whileHover={{ scale: 1.02 }}
              >
                <div className="p-2 rounded-lg bg-gradient-to-br from-primary/20 to-secondary/20">
                  <TrendingUp className="w-6 h-6 text-primary" />
                </div>
                <span className="text-2xl font-bold gradient-text-purple">AI Portfolio Rebalancing</span>
              </motion.div>
              <Button
                onClick={handleAnalyze}
                disabled={isAnalyzing || holdings.length === 0}
                className="gap-2 bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"
                size="lg"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Brain className="w-5 h-5" />
                    Analyze Portfolio
                  </>
                )}
              </Button>
            </CardTitle>
          </CardHeader>
          
          <CardContent className="pt-6">
            <AnimatePresence mode="wait">
              {!showSuggestions ? (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="glass-card p-12 text-center"
                >
                  <motion.div
                    animate={{ 
                      scale: [1, 1.1, 1],
                      rotate: [0, 5, -5, 0]
                    }}
                    transition={{ 
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  >
                    <Sparkles className="w-16 h-16 mx-auto mb-6 text-primary" />
                  </motion.div>
                  <h3 className="text-xl font-bold mb-3 gradient-text-cyan">AI-Powered Portfolio Analysis</h3>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    Click "Analyze Portfolio" to receive personalized rebalancing recommendations based on your current holdings and market conditions.
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  key="results"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="space-y-6"
                >
                  {/* Disclaimer */}
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-start gap-3 p-4 rounded-lg bg-primary/5 border border-primary/20"
                  >
                    <Info className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      These suggestions are AI-generated and should not be considered financial advice. Always do your own research.
                    </p>
                  </motion.div>

                  {rebalancingSuggestions.length === 0 ? (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="glass-card p-8 text-center"
                    >
                      <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-400" />
                      <h3 className="text-xl font-bold mb-2 text-green-400">Portfolio is Well Balanced</h3>
                      <p className="text-muted-foreground">
                        No rebalancing needed at this time. Your portfolio allocation is optimal.
                      </p>
                    </motion.div>
                  ) : (
                    <>
                      {/* Portfolio Health Summary */}
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="grid grid-cols-1 md:grid-cols-3 gap-4"
                      >
                        <div className="glass-card p-4 hover-glow">
                          <div className="flex items-center gap-3 mb-2">
                            <Shield className="w-5 h-5 text-primary" />
                            <span className="text-sm text-muted-foreground">Portfolio Health</span>
                          </div>
                          <p className={`text-2xl font-bold ${portfolioHealth.color}`}>
                            {portfolioHealth.status}
                          </p>
                        </div>

                        <div className="glass-card p-4 hover-glow">
                          <div className="flex items-center gap-3 mb-2">
                            <AlertCircle className="w-5 h-5 text-yellow-400" />
                            <span className="text-sm text-muted-foreground">Risk Level</span>
                          </div>
                          <p className="text-2xl font-bold text-yellow-400">
                            {portfolioHealth.riskLevel}
                          </p>
                        </div>

                        <div className="glass-card p-4 hover-glow">
                          <div className="flex items-center gap-3 mb-2">
                            <Activity className="w-5 h-5 text-cyan-400" />
                            <span className="text-sm text-muted-foreground">Health Score</span>
                          </div>
                          <p className="text-2xl font-bold text-cyan-400">
                            {portfolioHealth.score.toFixed(0)}/100
                          </p>
                        </div>
                      </motion.div>

                      {/* Key Actions */}
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="glass-card p-6"
                      >
                        <h4 className="text-lg font-bold mb-4 flex items-center gap-2">
                          <Target className="w-5 h-5 text-primary" />
                          Key Actions
                        </h4>
                        <ul className="space-y-3">
                          {keyActions.map((action, index) => (
                            <motion.li
                              key={index}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: 0.15 + index * 0.05 }}
                              className="flex items-start gap-3 text-sm"
                            >
                              <span className="text-primary font-bold mt-0.5">•</span>
                              <span className="text-muted-foreground">{action}</span>
                            </motion.li>
                          ))}
                        </ul>
                      </motion.div>

                      {/* Detailed Suggestions */}
                      <div className="space-y-4">
                        {rebalancingSuggestions.map((suggestion, index) => (
                          <motion.div
                            key={index}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.2 + index * 0.1 }}
                            whileHover={{ scale: 1.02, x: 5 }}
                            className="glass-card p-6 hover-glow border border-primary/20 cursor-pointer"
                          >
                            <div className="flex items-start gap-4">
                              <motion.div 
                                className="p-3 rounded-xl bg-gradient-to-br from-primary/20 to-secondary/20"
                                whileHover={{ rotate: 360 }}
                                transition={{ duration: 0.6 }}
                              >
                                {suggestion.type === "reduce" ? (
                                  <TrendingDown className="w-6 h-6 text-red-400" />
                                ) : suggestion.type === "increase" ? (
                                  <TrendingUp className="w-6 h-6 text-green-400" />
                                ) : (
                                  <Target className="w-6 h-6 text-primary" />
                                )}
                              </motion.div>
                              
                              <div className="flex-1">
                                <div className="flex items-center justify-between mb-3">
                                  <h4 className="text-lg font-bold capitalize gradient-text-cyan">
                                    {suggestion.type} {suggestion.token}
                                  </h4>
                                  <span className="text-lg font-bold text-primary">
                                    ${suggestion.amount.toLocaleString(undefined, { 
                                      minimumFractionDigits: 2, 
                                      maximumFractionDigits: 2 
                                    })}
                                  </span>
                                </div>
                                
                                <div className="flex items-center gap-6 mb-4 text-sm">
                                  <div className="flex items-center gap-2">
                                    <span className="text-muted-foreground">Current:</span>
                                    <span className="font-bold text-foreground">
                                      {suggestion.currentPercent.toFixed(1)}%
                                    </span>
                                  </div>
                                  <ArrowRight className="w-4 h-4 text-primary" />
                                  <div className="flex items-center gap-2">
                                    <span className="text-muted-foreground">Target:</span>
                                    <span className="font-bold text-primary">
                                      {suggestion.targetPercent.toFixed(1)}%
                                    </span>
                                  </div>
                                </div>
                                
                                <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                                  {suggestion.reason}
                                </p>
                                
                                <Button
                                  onClick={() => handleExecuteSuggestion(suggestion)}
                                  className="w-full gap-2 bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"
                                  disabled={!connected}
                                >
                                  <Wallet className="w-4 h-4" />
                                  {connected ? "Execute Rebalancing" : "Connect Wallet to Execute"}
                                </Button>
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>
      </motion.div>

      {/* Execution Confirmation Dialog */}
      <Dialog open={showExecutionDialog} onOpenChange={setShowExecutionDialog}>
        <DialogContent className="glass-card">
          <DialogHeader>
            <DialogTitle className="text-2xl gradient-text-purple">Confirm Rebalancing</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Review the trade details before executing
            </DialogDescription>
          </DialogHeader>
          
          {selectedSuggestion && (
            <div className="space-y-4 py-4">
              <div className="glass-card p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">Action</span>
                  <span className="font-bold capitalize">{selectedSuggestion.type} {selectedSuggestion.token}</span>
                </div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">Amount</span>
                  <span className="font-bold text-primary">
                    ${selectedSuggestion.amount.toLocaleString(undefined, { 
                      minimumFractionDigits: 2, 
                      maximumFractionDigits: 2 
                    })}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Target Allocation</span>
                  <span className="font-bold">{selectedSuggestion.targetPercent.toFixed(1)}%</span>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                <AlertCircle className="w-5 h-5 text-yellow-400 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-muted-foreground">
                  This will execute trades on your connected wallet. Make sure you have sufficient balance and approve the transaction.
                </p>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowExecutionDialog(false)}
              disabled={isExecuting}
            >
              Cancel
            </Button>
            <Button
              onClick={executeRebalancing}
              disabled={isExecuting}
              className="gap-2 bg-gradient-to-r from-primary to-secondary"
            >
              {isExecuting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Executing...
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  Confirm & Execute
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};