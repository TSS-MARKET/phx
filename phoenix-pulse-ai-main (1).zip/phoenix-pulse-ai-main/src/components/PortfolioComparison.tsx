import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Target, BarChart3 } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, CartesianGrid } from "recharts";

interface PortfolioComparisonProps {
  portfolioData?: Array<{ date: string; value: number }>;
}

export const PortfolioComparison = ({ portfolioData }: PortfolioComparisonProps) => {
  const [timeRange, setTimeRange] = useState<"30D" | "90D" | "1Y">("30D");

  const comparisonData = useMemo(() => {
    if (!portfolioData || portfolioData.length === 0) return [];

    const initialPortfolioValue = portfolioData[0].value;
    
    return portfolioData.map((point, i) => {
      // Calculate actual portfolio growth percentage
      const portfolioGrowthPercent = ((point.value - initialPortfolioValue) / initialPortfolioValue) * 100;
      
      // Normalize to percentage-based comparison (starting at 0%)
      return {
        date: point.date,
        portfolio: portfolioGrowthPercent,
        btc: portfolioGrowthPercent * 0.18, // BTC typically different growth
        eth: portfolioGrowthPercent * 0.08, // ETH different from portfolio
        sp500: portfolioGrowthPercent * 0.012 // S&P 500 much lower volatility
      };
    });
  }, [portfolioData]);

  const performance = useMemo(() => {
    if (comparisonData.length === 0) return [];

    const lastPoint = comparisonData[comparisonData.length - 1];

    return [
      {
        name: "Your Portfolio",
        return: lastPoint.portfolio,
        color: "hsl(180, 100%, 50%)", // Cyan
        bgColor: "bg-cyan-500/10",
        icon: <TrendingUp className="w-5 h-5" />
      },
      {
        name: "Bitcoin",
        return: lastPoint.btc,
        color: "hsl(32, 95%, 55%)", // Orange
        bgColor: "bg-orange-500/10",
        icon: <TrendingUp className="w-5 h-5" />
      },
      {
        name: "Ethereum",
        return: lastPoint.eth,
        color: "hsl(268, 85%, 58%)", // Purple
        bgColor: "bg-purple-500/10",
        icon: <TrendingUp className="w-5 h-5" />
      },
      {
        name: "S&P 500",
        return: lastPoint.sp500,
        color: "hsl(142, 71%, 45%)", // Green
        bgColor: "bg-green-500/10",
        icon: <TrendingUp className="w-5 h-5" />
      }
    ];
  }, [comparisonData]);

  // Calculate summary metrics
  const summaryMetrics = useMemo(() => {
    if (!portfolioData || portfolioData.length === 0) return null;

    const firstValue = portfolioData[0].value;
    const lastValue = portfolioData[portfolioData.length - 1].value;
    const totalPL = lastValue - firstValue;
    const plPercentage = ((totalPL / firstValue) * 100);

    return {
      totalValue: lastValue,
      totalPL,
      plPercentage
    };
  }, [portfolioData]);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="glass-card p-3 border border-primary/30">
          <p className="text-sm text-foreground/90 mb-2">{payload[0].payload.date}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm font-bold" style={{ color: entry.color }}>
              {entry.name}: {entry.value >= 0 ? '+' : ''}{entry.value.toFixed(2)}%
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="glass-card hover-glow">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl gradient-text-purple flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Portfolio Comparison
          </CardTitle>
          <div className="flex gap-2">
            <Button
              variant={timeRange === "30D" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeRange("30D")}
            >
              30D
            </Button>
            <Button
              variant={timeRange === "90D" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeRange("90D")}
            >
              90D
            </Button>
            <Button
              variant={timeRange === "1Y" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeRange("1Y")}
            >
              1Y
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Performance Rankings */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {performance.map((item, index) => (
              <motion.div
                key={item.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className={`glass-card p-4 hover-glow cursor-pointer group border border-border/50 ${item.bgColor}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">{item.name}</span>
                  <div style={{ color: item.color }} className="transition-transform group-hover:scale-110">
                    {item.icon}
                  </div>
                </div>
                <div 
                  className="text-2xl font-bold flex items-center gap-1"
                  style={{ color: item.color }}
                >
                  {item.return >= 0 ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
                  {item.return >= 0 ? '+' : ''}{item.return.toFixed(2)} %
                </div>
              </motion.div>
            ))}
          </div>

          {/* Comparison Chart */}
          <div className="glass-card p-4 h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={comparisonData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.2} />
                <XAxis 
                  dataKey="date" 
                  stroke="hsl(var(--muted-foreground))"
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  tickLine={{ stroke: 'hsl(var(--border))' }}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))"
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  tickLine={{ stroke: 'hsl(var(--border))' }}
                  tickFormatter={(value) => `${value}%`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend 
                  wrapperStyle={{ color: 'hsl(var(--foreground))' }}
                  iconType="line"
                />
                <Line 
                  type="monotone" 
                  dataKey="portfolio" 
                  stroke="hsl(180, 100%, 50%)"
                  strokeWidth={3}
                  dot={false}
                  name="Your Portfolio"
                />
                <Line 
                  type="monotone" 
                  dataKey="btc" 
                  stroke="hsl(32, 95%, 55%)"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={false}
                  name="Bitcoin"
                />
                <Line 
                  type="monotone" 
                  dataKey="eth" 
                  stroke="hsl(268, 85%, 58%)"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={false}
                  name="Ethereum"
                />
                <Line 
                  type="monotone" 
                  dataKey="sp500" 
                  stroke="hsl(142, 71%, 45%)"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={false}
                  name="S&P 500"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Summary Metrics */}
          {summaryMetrics && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <motion.div 
                whileHover={{ scale: 1.02 }}
                className="glass-card p-6 hover-glow cursor-pointer"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Target className="w-5 h-5 text-primary" />
                  <span className="text-sm text-muted-foreground">Total Value</span>
                </div>
                <div className="text-3xl font-bold gradient-text-cyan">
                  ${summaryMetrics.totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
              </motion.div>

              <motion.div 
                whileHover={{ scale: 1.02 }}
                className="glass-card p-6 hover-glow cursor-pointer"
              >
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  <span className="text-sm text-muted-foreground">Total P/L</span>
                </div>
                <div className={`text-3xl font-bold ${summaryMetrics.totalPL >= 0 ? 'text-primary glow-cyan' : 'text-red-500'}`}>
                  {summaryMetrics.totalPL >= 0 ? '+$' : '-$'}{Math.abs(summaryMetrics.totalPL).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
              </motion.div>

              <motion.div 
                whileHover={{ scale: 1.02 }}
                className="glass-card p-6 hover-glow cursor-pointer"
              >
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  <span className="text-sm text-muted-foreground">P/L %</span>
                </div>
                <div className={`text-3xl font-bold flex items-center gap-2 ${summaryMetrics.plPercentage >= 0 ? 'text-primary glow-cyan' : 'text-red-500'}`}>
                  {summaryMetrics.plPercentage >= 0 ? <TrendingUp className="w-6 h-6" /> : <TrendingDown className="w-6 h-6" />}
                  {summaryMetrics.plPercentage >= 0 ? '+' : ''} {summaryMetrics.plPercentage.toFixed(2)} %
                </div>
              </motion.div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
