import { useState, useEffect, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Wallet, Plus, TrendingUp, TrendingDown, DollarSign, PieChart, X, Search, Download, FileText, Share2 } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { useCryptoPrices } from "@/hooks/useCryptoPrices";
import { CoinSearchDialog } from "./CoinSearchDialog";
import { useCoinLogos } from "@/hooks/useCoinLogos";
import { LoadingSkeleton } from "@/components/ui/loading-skeleton";
import { AnimatedCounter } from "@/components/ui/animated-counter";
import { usePortfolioExport } from "@/hooks/usePortfolioExport";
import { usePortfolioShare, PnLCardData } from "@/hooks/usePortfolioShare";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PerformanceChart } from "@/components/ui/performance-chart";
import { PortfolioAnalytics } from "@/components/PortfolioAnalytics";
import { PortfolioComparison } from "@/components/PortfolioComparison";
import { AIPortfolioRebalancing } from "@/components/AIPortfolioRebalancing";
import { PnLCardGenerator } from "@/components/PnLCardGenerator";
import { PortfolioHistoryTimeline } from "@/components/PortfolioHistoryTimeline";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Twitter, Linkedin, Facebook, MessageCircle, Instagram, Send } from "lucide-react";

interface PortfolioItem {
  id: string;
  symbol: string;
  name: string;
  amount: number;
  buyPrice: number;
  currentPrice: number;
  icon?: string;
  coinId?: string;
}

export const PortfolioTracker = () => {
  // Load portfolio from localStorage on mount
  const [portfolio, setPortfolio] = useState<PortfolioItem[]>(() => {
    const saved = localStorage.getItem('portfolio');
    return saved ? JSON.parse(saved) : [];
  });
  const [showAddForm, setShowAddForm] = useState(false);
  const [showSearchDialog, setShowSearchDialog] = useState(false);
  const [newAsset, setNewAsset] = useState({
    symbol: "",
    name: "",
    amount: "",
    buyPrice: "",
    coinId: "",
  });
  const { toast } = useToast();
  const { exportToCSV, exportToPDF } = usePortfolioExport();
  const { 
    shareToTwitter, 
    shareToLinkedIn, 
    shareToFacebook,
    shareToWhatsApp,
    shareToInstagram,
    shareToTelegram,
    copyToClipboard 
  } = usePortfolioShare();
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  
  // Save portfolio to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('portfolio', JSON.stringify(portfolio));
  }, [portfolio]);
  
  // Fetch real-time prices for all portfolio assets
  const coinIds = portfolio.map(item => item.coinId || item.symbol.toLowerCase());
  const { data: priceData, isLoading: isPricesLoading } = useCryptoPrices(coinIds);
  const { data: logoData } = useCoinLogos(coinIds);
  
  // Update portfolio prices when new data arrives
  useEffect(() => {
    if (priceData && Object.keys(priceData).length > 0) {
      setPortfolio(prev => prev.map(item => {
        const coinKey = item.coinId || item.symbol.toLowerCase();
        const priceInfo = priceData[coinKey.toUpperCase()] || priceData[coinKey];
        if (priceInfo?.usd) {
          return { ...item, currentPrice: priceInfo.usd };
        }
        return item;
      }));
    }
  }, [priceData]);

  const calculateTotal = () => {
    return portfolio.reduce((total, item) => {
      return total + (item.amount * item.currentPrice);
    }, 0);
  };

  const calculateProfit = () => {
    return portfolio.reduce((profit, item) => {
      return profit + (item.amount * (item.currentPrice - item.buyPrice));
    }, 0);
  };

  const calculateProfitPercentage = () => {
    const totalInvested = portfolio.reduce((total, item) => {
      return total + (item.amount * item.buyPrice);
    }, 0);
    return totalInvested > 0 ? ((calculateProfit() / totalInvested) * 100) : 0;
  };

  // Generate PnL card data for portfolio
  const pnlCardData: PnLCardData | null = useMemo(() => {
    if (portfolio.length === 0) return null;
    
    const totalValue = calculateTotal();
    const totalInvested = portfolio.reduce((sum, item) => sum + (item.amount * item.buyPrice), 0);
    const totalProfit = calculateProfit();
    const profitPercentage = totalInvested > 0 ? (totalProfit / totalInvested) * 100 : 0;

    return {
      totalValue,
      totalInvested,
      totalProfit,
      profitPercentage,
    };
  }, [portfolio]);

  const handleCardCapture = (dataUrl: string) => {
    setGeneratedImage(dataUrl);
  };

  const downloadCard = () => {
    if (!generatedImage) return;
    const link = document.createElement("a");
    link.download = `phx-portfolio-pnl-${Date.now()}.png`;
    link.href = generatedImage;
    link.click();
    toast({
      title: "Downloaded!",
      description: "Portfolio P&L card saved successfully",
    });
  };

  const handleCoinSelect = (coin: any) => {
    setNewAsset({
      ...newAsset,
      symbol: coin.symbol,
      name: coin.name,
      coinId: coin.id,
    });
    setShowSearchDialog(false);
    setShowAddForm(true);
  };

  const addAsset = () => {
    if (!newAsset.symbol || !newAsset.amount || !newAsset.buyPrice) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    const asset: PortfolioItem = {
      id: Date.now().toString(),
      symbol: newAsset.symbol.toUpperCase(),
      name: newAsset.name || newAsset.symbol.toUpperCase(),
      amount: parseFloat(newAsset.amount),
      buyPrice: parseFloat(newAsset.buyPrice),
      currentPrice: parseFloat(newAsset.buyPrice),
      coinId: newAsset.coinId,
    };

    setPortfolio([...portfolio, asset]);
    setNewAsset({ symbol: "", name: "", amount: "", buyPrice: "", coinId: "" });
    setShowAddForm(false);
    
    toast({
      title: "Asset Added",
      description: `${asset.symbol} has been added to your portfolio`,
    });
  };

  const removeAsset = (id: string) => {
    setPortfolio(portfolio.filter((item) => item.id !== id));
    toast({
      title: "Asset Removed",
      description: "The asset has been removed from your portfolio",
    });
  };

  const totalValue = calculateTotal();
  const totalProfit = calculateProfit();
  const profitPercentage = calculateProfitPercentage();

  // Generate performance data for charts - Fixed to show correct profit/loss progression
  const portfolioPerformanceData = useMemo(() => {
    if (portfolio.length === 0) return [];
    
    const days = 30;
    const data = [];
    const currentTotal = totalValue;
    const totalInvested = portfolio.reduce((sum, item) => sum + (item.amount * item.buyPrice), 0);
    
    // Calculate growth from invested amount to current value
    const totalGrowth = currentTotal - totalInvested;
    
    for (let i = 0; i < days; i++) {
      const date = new Date();
      date.setDate(date.getDate() - (days - i - 1));
      
      // Progress from 0 to 1 over the period
      const progress = i / (days - 1);
      
      // Add some realistic volatility
      const volatilityFactor = Math.sin(i / 3) * 0.03 + Math.random() * 0.02 - 0.01;
      
      // Calculate value: start from invested, grow to current with volatility
      const baseValue = totalInvested + (totalGrowth * progress);
      const historicalValue = baseValue * (1 + volatilityFactor);
      
      data.push({
        date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        value: Math.max(0, Math.round(historicalValue))
      });
    }
    
    return data;
  }, [portfolio, totalValue]);

  return (
    <div className="space-y-6">
      {/* Summary Cards with Individual Hover Effects */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {!isPricesLoading ? (
          <>
            <motion.div whileHover={{ scale: 1.02 }} transition={{ duration: 0.2 }}>
              <Card className="glass-card p-6 hover-glow cursor-pointer">
                <div className="flex items-center gap-3 mb-2">
                  <DollarSign className="w-5 h-5 text-primary" />
                  <span className="text-sm text-muted-foreground">Total Value</span>
                </div>
                <div className="text-3xl font-bold gradient-text-cyan">
                  $<AnimatedCounter value={totalValue} decimals={2} />
                </div>
              </Card>
            </motion.div>

            <motion.div whileHover={{ scale: 1.02 }} transition={{ duration: 0.2 }}>
              <Card className="glass-card p-6 hover-glow cursor-pointer">
                <div className="flex items-center gap-3 mb-2">
                  {totalProfit >= 0 ? (
                    <TrendingUp className="w-5 h-5 text-primary" />
                  ) : (
                    <TrendingDown className="w-5 h-5 text-red-500" />
                  )}
                  <span className="text-sm text-muted-foreground">Total P/L</span>
                </div>
                <div className={`text-3xl font-bold ${totalProfit >= 0 ? 'text-primary glow-cyan' : 'text-red-500'}`}>
                  {totalProfit >= 0 ? '+$' : '-$'}<AnimatedCounter value={Math.abs(totalProfit)} decimals={2} />
                </div>
              </Card>
            </motion.div>

            <motion.div whileHover={{ scale: 1.02 }} transition={{ duration: 0.2 }}>
              <Card className="glass-card p-6 hover-glow cursor-pointer">
                <div className="flex items-center gap-3 mb-2">
                  <PieChart className="w-5 h-5 text-secondary" />
                  <span className="text-sm text-muted-foreground">P/L %</span>
                </div>
                <div className={`text-3xl font-bold flex items-center gap-2 ${profitPercentage >= 0 ? 'text-primary glow-cyan' : 'text-red-500'}`}>
                  {profitPercentage >= 0 ? <TrendingUp className="w-6 h-6" /> : <TrendingDown className="w-6 h-6" />}
                  {profitPercentage >= 0 ? '+' : ''}<AnimatedCounter value={profitPercentage} decimals={2} />%
                </div>
              </Card>
            </motion.div>
          </>
        ) : (
          <>
            <LoadingSkeleton className="h-32" />
            <LoadingSkeleton className="h-32" />
            <LoadingSkeleton className="h-32" />
          </>
        )}
      </div>

      {/* Portfolio Holdings with Performance Chart */}
      <Card className="glass-card p-6 mb-6 hover-glow border-primary/20">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
          <motion.h3 
            className="text-2xl font-bold gradient-text-cyan flex items-center gap-3"
            whileHover={{ scale: 1.02 }}
          >
            <div className="p-2 rounded-lg bg-gradient-to-br from-primary/20 to-secondary/20">
              <Wallet className="w-6 h-6 text-primary" />
            </div>
            Your Holdings
          </motion.h3>
          <div className="flex items-center gap-2 flex-wrap">
            {portfolio.length > 0 && (
              <>
                <Button
                  onClick={() => setShowShareDialog(true)}
                  variant="outline"
                  size="sm"
                  className="gap-2 hover-glow"
                >
                  <Share2 className="w-4 h-4" />
                  Share
                </Button>
                <Button
                  onClick={() => exportToCSV(portfolio)}
                  variant="outline"
                  size="sm"
                  className="gap-2 hover-glow"
                >
                  <Download className="w-4 h-4" />
                  CSV
                </Button>
                <Button
                  onClick={() => exportToPDF(portfolio)}
                  variant="outline"
                  size="sm"
                  className="gap-2 hover-glow"
                >
                  <FileText className="w-4 h-4" />
                  PDF
                </Button>
              </>
            )}
            <Button
              onClick={() => {
                setShowAddForm(true);
                setShowSearchDialog(true);
              }}
              className="gap-2 bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"
            >
              <Plus className="w-4 h-4" />
              Add Asset
            </Button>
          </div>
        </div>

        {/* Performance Chart - Above Holdings */}
        {portfolio.length > 0 && portfolioPerformanceData.length > 0 && (
          <motion.div 
            className="mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <PerformanceChart 
              data={portfolioPerformanceData}
            />
          </motion.div>
        )}

        {/* Portfolio History Timeline */}
        {portfolio.length > 0 && (
          <PortfolioHistoryTimeline
            currentValue={totalValue}
            currentInvested={portfolio.reduce((sum, item) => sum + (item.amount * item.buyPrice), 0)}
            profitPercentage={profitPercentage}
          />
        )}

        {/* Add Asset Form */}
        {showAddForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-6 p-4 rounded-lg bg-muted/30 border border-primary/20"
          >
            <div className="mb-4">
              <Button
                variant="outline"
                className="w-full gap-2"
                onClick={() => setShowSearchDialog(true)}
              >
                <Search className="w-4 h-4" />
                {newAsset.symbol ? `${newAsset.name} (${newAsset.symbol})` : "Search for a cryptocurrency"}
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                type="number"
                placeholder="Amount"
                value={newAsset.amount}
                onChange={(e) => setNewAsset({ ...newAsset, amount: e.target.value })}
              />
              <Input
                type="number"
                placeholder="Buy Price (USD)"
                value={newAsset.buyPrice}
                onChange={(e) => setNewAsset({ ...newAsset, buyPrice: e.target.value })}
              />
            </div>
            <div className="flex gap-2 mt-4">
              <Button onClick={addAsset} className="flex-1" disabled={!newAsset.symbol}>
                Add to Portfolio
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setShowAddForm(false);
                  setNewAsset({ symbol: "", name: "", amount: "", buyPrice: "", coinId: "" });
                }}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </motion.div>
        )}

        <CoinSearchDialog
          isOpen={showSearchDialog}
          onClose={() => setShowSearchDialog(false)}
          onSelect={handleCoinSelect}
        />

        {/* Portfolio List */}
        <div className="space-y-3">
          {portfolio.length === 0 ? (
            <motion.div 
              className="text-center py-12 text-muted-foreground"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <Wallet className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-semibold">No assets in your portfolio yet</p>
              <p className="text-sm">Click "Add Asset" to get started</p>
            </motion.div>
          ) : (
            portfolio.map((item, idx) => {
              const value = item.amount * item.currentPrice;
              const invested = item.amount * item.buyPrice;
              const profit = value - invested;
              const profitPercent = invested > 0 ? ((profit / invested) * 100) : 0;

              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  whileHover={{ scale: 1.01, x: 5 }}
                  className="p-5 rounded-xl bg-muted/30 hover:bg-muted/50 transition-all border border-primary/10 hover:border-primary/30"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 flex-1">
                      <motion.div
                        whileHover={{ rotate: 360 }}
                        transition={{ duration: 0.6 }}
                      >
                        {logoData?.[item.coinId || item.symbol] ? (
                          <img
                            src={logoData[item.coinId || item.symbol]}
                            alt={item.symbol}
                            className="w-12 h-12 rounded-full ring-2 ring-primary/20"
                          />
                        ) : (
                          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center ring-2 ring-primary/20">
                            <span className="font-bold text-sm">{item.symbol.slice(0, 2)}</span>
                          </div>
                        )}
                      </motion.div>
                      <div>
                        <div className="font-bold text-lg">{item.symbol}</div>
                        <div className="text-sm text-muted-foreground">
                          {item.amount.toLocaleString()} × ${item.buyPrice.toLocaleString()}
                        </div>
                      </div>
                    </div>

                    <div className="text-right mr-4">
                      <div className="font-bold text-lg mb-1">
                        $<AnimatedCounter value={value} decimals={2} />
                      </div>
                      <div className={`text-sm flex items-center gap-1 justify-end font-semibold ${profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {profit >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                        {profit >= 0 ? '+$' : '-$'}<AnimatedCounter value={Math.abs(profit)} decimals={2} />
                      </div>
                      <div className={`text-xs flex items-center gap-1 justify-end ${profit >= 0 ? 'text-green-400/80' : 'text-red-400/80'}`}>
                        ({profitPercent >= 0 ? '+' : ''}<AnimatedCounter value={profitPercent} decimals={2} />%)
                      </div>
                    </div>

                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeAsset(item.id)}
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                    >
                      <X className="w-5 h-5" />
                    </Button>
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      </Card>

      {/* AI Portfolio Rebalancing */}
      {portfolio.length > 0 && (
        <div className="mb-6">
          <AIPortfolioRebalancing 
            holdings={portfolio.map(item => ({
              symbol: item.symbol,
              token: item.symbol,
              coinId: item.coinId || item.symbol.toLowerCase(),
              amount: item.amount,
              balance: item.amount,
              value: item.amount * item.currentPrice,
              percentage: (item.amount * item.currentPrice / totalValue) * 100
            }))}
            totalValue={totalValue}
          />
        </div>
      )}

      {/* Portfolio Analytics */}
      {portfolio.length > 0 && portfolioPerformanceData.length > 0 && (
        <div className="mb-6">
          <PortfolioAnalytics
            holdings={portfolio.map(item => ({
              symbol: item.symbol,
              token: item.symbol,
              coinId: item.coinId || item.symbol.toLowerCase(),
              amount: item.amount,
              balance: item.amount,
              value: item.amount * item.currentPrice,
              percentage: (item.amount * item.currentPrice / totalValue) * 100
            }))}
            totalValue={totalValue}
            performanceData={portfolioPerformanceData}
          />
        </div>
      )}

      {/* Portfolio Comparison */}
      {portfolio.length > 0 && portfolioPerformanceData.length > 0 && (
        <PortfolioComparison 
          portfolioData={portfolioPerformanceData}
        />
      )}

      {/* Share Dialog with PnL Card Generator */}
      <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <DialogContent className="glass-card max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="gradient-text-purple text-2xl">Share Portfolio Performance</DialogTitle>
          </DialogHeader>
          
          <Tabs defaultValue="card" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="card">PnL Card</TabsTrigger>
              <TabsTrigger value="social">Social Share</TabsTrigger>
            </TabsList>

            <TabsContent value="card" className="space-y-4">
              {/* PnL Card Preview */}
              {pnlCardData && (
                <div className="flex justify-center my-6 overflow-x-auto">
                  <div className="scale-[0.6] origin-center">
                    <PnLCardGenerator
                      data={pnlCardData}
                      onCapture={handleCardCapture}
                    />
                  </div>
                </div>
              )}

              {/* Download Button */}
              <div className="flex gap-2">
                <Button
                  onClick={downloadCard}
                  disabled={!generatedImage}
                  className="flex-1 bg-gradient-to-r from-primary to-secondary"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Card
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="social" className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <Button
                  onClick={() => {
                    shareToTwitter({ totalValue, totalProfit, profitPercentage });
                    setShowShareDialog(false);
                  }}
                  className="gap-2 bg-[#1DA1F2] hover:bg-[#1DA1F2]/90 text-white"
                >
                  <Twitter className="w-4 h-4" />
                  Twitter
                </Button>
                <Button
                  onClick={() => {
                    shareToLinkedIn({ totalValue, totalProfit, profitPercentage });
                    setShowShareDialog(false);
                  }}
                  className="gap-2 bg-[#0077B5] hover:bg-[#0077B5]/90 text-white"
                >
                  <Linkedin className="w-4 h-4" />
                  LinkedIn
                </Button>
                <Button
                  onClick={() => {
                    shareToFacebook({ totalValue, totalProfit, profitPercentage });
                    setShowShareDialog(false);
                  }}
                  className="gap-2 bg-[#1877F2] hover:bg-[#1877F2]/90 text-white"
                >
                  <Facebook className="w-4 h-4" />
                  Facebook
                </Button>
                <Button
                  onClick={() => {
                    shareToWhatsApp({ totalValue, totalProfit, profitPercentage });
                    setShowShareDialog(false);
                  }}
                  className="gap-2 bg-[#25D366] hover:bg-[#25D366]/90 text-white"
                >
                  <MessageCircle className="w-4 h-4" />
                  WhatsApp
                </Button>
                <Button
                  onClick={() => {
                    shareToTelegram({ totalValue, totalProfit, profitPercentage });
                    setShowShareDialog(false);
                  }}
                  className="gap-2 bg-[#0088CC] hover:bg-[#0088CC]/90 text-white"
                >
                  <Send className="w-4 h-4" />
                  Telegram
                </Button>
                <Button
                  onClick={() => {
                    shareToInstagram();
                  }}
                  className="gap-2 bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#F77737] hover:opacity-90 text-white"
                >
                  <Instagram className="w-4 h-4" />
                  Instagram
                </Button>
                <Button
                  onClick={() => {
                    copyToClipboard({ totalValue, totalProfit, profitPercentage });
                  }}
                  className="gap-2 col-span-2"
                  variant="outline"
                >
                  <FileText className="w-4 h-4" />
                  Copy Summary
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
};
