import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Waves } from "lucide-react";
import { motion } from "framer-motion";

interface WhaleAlert {
  id: string;
  amount: number;
  coin: string;
  from: string;
  to: string;
  value: number;
  timestamp: string;
}

const mockWhaleAlerts: WhaleAlert[] = [
  {
    id: "1",
    amount: 1250,
    coin: "BTC",
    from: "Binance",
    to: "Unknown Wallet",
    value: 56500000,
    timestamp: "5 min ago",
  },
  {
    id: "2",
    amount: 45000,
    coin: "ETH",
    from: "Unknown Wallet",
    to: "Coinbase",
    value: 110250000,
    timestamp: "12 min ago",
  },
  {
    id: "3",
    amount: 500000,
    coin: "USDT",
    from: "Kraken",
    to: "Binance",
    value: 500000,
    timestamp: "18 min ago",
  },
  {
    id: "4",
    amount: 2500000,
    coin: "USDC",
    from: "Unknown Wallet",
    to: "Coinbase",
    value: 2500000,
    timestamp: "25 min ago",
  },
  {
    id: "5",
    amount: 850,
    coin: "BTC",
    from: "Gemini",
    to: "Unknown Wallet",
    value: 38420000,
    timestamp: "32 min ago",
  },
];

export const WhaleAlertsSection = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Waves className="w-8 h-8 text-secondary glow-purple" />
        <h2 className="text-3xl font-bold text-secondary glow-purple">Whale Alerts</h2>
        <Badge variant="secondary" className="ml-2 bg-secondary/20 border-secondary/40">Live</Badge>
      </div>

      <div className="space-y-3">
        {mockWhaleAlerts.map((alert, index) => (
          <motion.div
            key={alert.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.08 }}
          >
            <Card className="bg-gradient-to-br from-secondary/30 via-background to-purple-500/20 backdrop-blur-xl border-secondary/60 p-4 hover:border-secondary hover:shadow-[0_0_40px_rgba(168,85,247,0.4)] transition-all duration-300">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-4 flex-1">
                  <div className="w-10 h-10 rounded-full bg-secondary/30 flex items-center justify-center border border-secondary/40">
                    <Waves className="w-5 h-5 text-secondary" />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-lg text-secondary glow-purple">
                        {alert.amount.toLocaleString()} {alert.coin}
                      </span>
                      <span className="text-xs text-white/60">
                        (${(alert.value / 1000000).toFixed(2)}M)
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm text-white/70">
                      <span className="font-medium">{alert.from}</span>
                      <ArrowRight className="w-4 h-4 text-secondary" />
                      <span className="font-medium">{alert.to}</span>
                    </div>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="text-xs text-white/60">{alert.timestamp}</div>
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
