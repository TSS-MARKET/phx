import { memo } from "react";
import { motion } from "framer-motion";
import { TrendingDown, TrendingUp } from "lucide-react";
import { useCoinSparkline } from "@/hooks/useCoinSparkline";
import { Sparkline } from "@/components/ui/sparkline";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import { useCoinDetails } from "@/hooks/useCoinDetails";

interface MarketCoinRowProps {
  coinId: string;
  name: string;
  price: string;
  change: number;
  logo?: string;
  direction: "up" | "down";
  index: number;
}

const MarketCoinRowComponent = ({ coinId, name, price, change, logo, direction, index }: MarketCoinRowProps) => {
  const { data: sparklineData } = useCoinSparkline(coinId);
  const { data: coinDetails, isLoading } = useCoinDetails(coinId);
  const isUp = direction === "up";

  return (
    <HoverCard openDelay={200}>
      <HoverCardTrigger asChild>
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ delay: index * 0.1, duration: 0.4 }}
          whileHover={{ 
            scale: 1.03,
            y: -4,
            borderColor: isUp ? "rgba(79, 209, 197, 0.8)" : "rgba(239, 68, 68, 0.8)",
            boxShadow: isUp 
              ? "0 12px 40px rgba(79, 209, 197, 0.5)" 
              : "0 12px 40px rgba(239, 68, 68, 0.5)",
          }}
          className={`relative flex items-center justify-between p-3 rounded-lg transition-all cursor-pointer overflow-hidden ${
            isUp
              ? "bg-primary/5 border border-primary/20"
              : "bg-red-500/5 border border-red-500/20"
          }`}
        >
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/20 to-primary/0"
            initial={{ x: "-100%" }}
            whileHover={{ x: "100%" }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
          />
          
          <div className="flex items-center gap-3 relative z-10">
            {logo && (
              <motion.img 
                src={logo} 
                alt={name} 
                className="w-8 h-8 rounded-full" 
                whileHover={{ scale: 1.2, rotate: 5 }}
                transition={{ duration: 0.3 }}
              />
            )}
            <div>
              <div className="font-bold">{name}</div>
              <div className="text-sm text-foreground/60">{price}</div>
            </div>
          </div>

          {sparklineData && sparklineData.length > 0 && (
            <div className="mx-4 relative z-10">
              <Sparkline data={sparklineData.slice(-24)} height={40} width={80} />
            </div>
          )}

          <div
            className={`flex items-center gap-1 font-bold relative z-10 ${
              isUp ? "text-primary glow-cyan" : "text-red-500"
            }`}
          >
            {isUp ? (
              <TrendingUp className="w-4 h-4" />
            ) : (
              <TrendingDown className="w-4 h-4" />
            )}
            {isUp ? `+${change}%` : `${change}%`}
          </div>
        </motion.div>
      </HoverCardTrigger>
      <HoverCardContent className="w-80 bg-card/95 backdrop-blur-xl border-primary/30 p-4 z-[100]">
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            {logo && <img src={logo} alt={name} className="w-10 h-10 rounded-full" />}
            <div>
              <div className="font-bold text-lg">{name}</div>
              <div className="text-sm text-muted-foreground">Detailed Information</div>
            </div>
          </div>
          
          {isLoading ? (
            <div className="text-sm text-muted-foreground">Loading details...</div>
          ) : coinDetails ? (
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="space-y-1">
                <div className="text-muted-foreground">Market Cap</div>
                <div className="font-semibold">
                  ${(coinDetails.market_cap / 1e9).toFixed(2)}B
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-muted-foreground">24h Volume</div>
                <div className="font-semibold">
                  ${(coinDetails.total_volume / 1e9).toFixed(2)}B
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-muted-foreground">24h High</div>
                <div className="font-semibold text-primary">
                  ${coinDetails.high_24h?.toLocaleString()}
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-muted-foreground">24h Low</div>
                <div className="font-semibold text-red-500">
                  ${coinDetails.low_24h?.toLocaleString()}
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-muted-foreground">Circulating Supply</div>
                <div className="font-semibold">
                  {(coinDetails.circulating_supply / 1e6).toFixed(2)}M
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-muted-foreground">24h Change</div>
                <div className={`font-bold ${isUp ? "text-primary" : "text-red-500"}`}>
                  {isUp ? `+${change}%` : `${change}%`}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-sm text-muted-foreground">No details available</div>
          )}
        </div>
      </HoverCardContent>
    </HoverCard>
  );
};

export const MarketCoinRow = memo(MarketCoinRowComponent);
