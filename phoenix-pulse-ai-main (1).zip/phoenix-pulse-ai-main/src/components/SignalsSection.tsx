import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, BellOff, TrendingUp, TrendingDown, Check } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { useCoinPrice } from "@/hooks/useCoinPrice";

interface Signal {
  id: string;
  coin: string;
  coinId: string;
  type: "BUY" | "SELL";
  confidence: number;
  timestamp: string;
}

const signalsBase: Signal[] = [
  { id: "1", coin: "BTC", coinId: "bitcoin", type: "BUY", confidence: 87, timestamp: "2 hours ago" },
  { id: "2", coin: "ETH", coinId: "ethereum", type: "BUY", confidence: 82, timestamp: "4 hours ago" },
  { id: "3", coin: "SOL", coinId: "solana", type: "SELL", confidence: 75, timestamp: "6 hours ago" },
  { id: "4", coin: "LINK", coinId: "chainlink", type: "BUY", confidence: 90, timestamp: "8 hours ago" },
];

const SignalCard = ({ signal }: { signal: Signal }) => {
  const { data: price, isLoading } = useCoinPrice(signal.coinId);
  const [followedSignals, setFollowedSignals] = useState<Set<string>>(new Set());
  const { toast } = useToast();

  const toggleFollow = (signalId: string) => {
    const newFollowed = new Set(followedSignals);
    const isFollowing = newFollowed.has(signalId);
    
    if (isFollowing) {
      newFollowed.delete(signalId);
      toast({
        title: "Unfollowed Alert",
        description: "You will no longer receive notifications for this signal",
      });
    } else {
      newFollowed.add(signalId);
      toast({
        title: "Following Alert",
        description: "You will receive notifications when this signal updates",
      });
    }
    
    setFollowedSignals(newFollowed);
  };

  return (
    <Card className="glass-card p-6 hover:border-primary/40 transition-all">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
            signal.type === "BUY" ? "bg-primary/20" : "bg-destructive/20"
          }`}>
            {signal.type === "BUY" ? (
              <TrendingUp className="w-6 h-6 text-primary" />
            ) : (
              <TrendingDown className="w-6 h-6 text-destructive" />
            )}
          </div>
          <div>
            <div className="text-2xl font-bold glow-cyan">{signal.coin}</div>
            <div className="text-sm text-muted-foreground">{signal.timestamp}</div>
          </div>
        </div>
        
        <Button
          variant={followedSignals.has(signal.id) ? "default" : "outline"}
          size="sm"
          onClick={() => toggleFollow(signal.id)}
          className="gap-2"
        >
          {followedSignals.has(signal.id) ? (
            <>
              <Check className="w-4 h-4" />
              Following
            </>
          ) : (
            <>
              <Bell className="w-4 h-4" />
              Follow
            </>
          )}
        </Button>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">Signal Type</span>
          <Badge variant={signal.confidence >= 90 ? "strong-buy" : signal.confidence >= 80 ? "buy" : signal.type === "BUY" ? "hold" : "sell"}>
            {signal.confidence >= 90 ? "STRONG BUY" : signal.confidence >= 80 ? "BUY" : signal.type === "BUY" ? "HOLD" : "SELL"}
          </Badge>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">Entry Price</span>
          <span className="font-bold">
            {isLoading ? "Loading..." : `$${price?.toLocaleString()}`}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">Confidence</span>
          <div className="flex items-center gap-2">
            <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
              <div
                className={`h-full ${
                  signal.confidence >= 80 ? "bg-primary" : "bg-secondary"
                }`}
                style={{ width: `${signal.confidence}%` }}
              />
            </div>
            <span className="font-bold text-sm">{signal.confidence}%</span>
          </div>
        </div>
      </div>
    </Card>
  );
};

export const SignalsSection = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold glow-cyan">AI Trading Signals</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {signalsBase.map((signal, index) => (
          <motion.div
            key={signal.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <SignalCard signal={signal} />
          </motion.div>
        ))}
      </div>
    </div>
  );
};
