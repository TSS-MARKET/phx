import { Card } from "@/components/ui/card";
import { useCryptoPanic } from "@/hooks/useCryptoPanic";
import { Skeleton } from "@/components/ui/skeleton";
import { Newspaper, TrendingUp, TrendingDown } from "lucide-react";
import { motion } from "framer-motion";

export const NewsSection = () => {
  const { data: newsData, isLoading } = useCryptoPanic({});

  return (
    <Card className="glass-card p-6">
      <div className="flex items-center gap-2 mb-4">
        <Newspaper className="w-6 h-6 text-primary" />
        <h3 className="text-2xl font-bold glow-cyan">Market News & Sentiment</h3>
      </div>
      
      <div className="space-y-3">
        {isLoading ? (
          [...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-lg" />
          ))
        ) : newsData?.results ? (
          newsData.results.slice(0, 5).map((news: any, idx: number) => (
            <motion.a
              key={news.id}
              href={news.url}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="block p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-all hover-glow"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <h4 className="font-semibold mb-1 line-clamp-2">{news.title}</h4>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>{news.source?.title}</span>
                    <span>•</span>
                    <span>{new Date(news.created_at).toLocaleDateString()}</span>
                  </div>
                  {news.currencies && news.currencies.length > 0 && (
                    <div className="flex gap-1 mt-2">
                      {news.currencies.slice(0, 3).map((currency: any) => (
                        <span key={currency.code} className="px-2 py-0.5 bg-primary/20 text-primary text-xs rounded">
                          {currency.code}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                {news.votes && (
                  <div className="flex flex-col items-center gap-1 min-w-[60px]">
                    {news.votes.positive > news.votes.negative ? (
                      <>
                        <TrendingUp className="w-5 h-5 text-primary" />
                        <span className="text-xs text-primary font-medium">Bullish</span>
                      </>
                    ) : (
                      <>
                        <TrendingDown className="w-5 h-5 text-destructive" />
                        <span className="text-xs text-destructive font-medium">Bearish</span>
                      </>
                    )}
                  </div>
                )}
              </div>
            </motion.a>
          ))
        ) : (
          <p className="text-muted-foreground text-center py-8">No news available</p>
        )}
      </div>
    </Card>
  );
};
