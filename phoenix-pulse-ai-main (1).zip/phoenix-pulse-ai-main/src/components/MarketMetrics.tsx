import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { TrendingUp, TrendingDown, Activity, DollarSign } from "lucide-react";
import { useTopCoins, useCoinGecko } from "@/hooks/useCoinGecko";
import { LoadingSkeleton, ChartSkeleton } from "@/components/ui/loading-skeleton";
import { useMemo } from "react";
import { Tooltip as UITooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip";
import { MarketCoinRow } from "@/components/MarketCoinRow";
import { Tilt3DCard } from "@/components/Tilt3DCard";

export const MarketMetrics = () => {
   const { data: coinsData, isLoading } = useTopCoins();
   
   // Fetch more coins for genuine gainers/losers
   const { data: allCoinsData } = useCoinGecko("/coins/markets", {
     vs_currency: "usd",
     order: "market_cap_desc",
     per_page: "100",
     page: "1",
     sparkline: "false",
   });
 
   

  // Generate realistic 24h price trend data with price disparities
  const priceData = useMemo(() => {
    if (!coinsData?.[0]) return [];
    const btcPrice = coinsData[0].current_price;
    const change24h = coinsData[0].price_change_percentage_24h || 0;
    const startPrice = btcPrice / (1 + change24h / 100);
    
    // Create price range within ±$1000 for visibility
    const priceRange = 1000;
    const minDisplayPrice = btcPrice - priceRange;
    const maxDisplayPrice = btcPrice + priceRange;
    
    return Array.from({ length: 24 }, (_, i) => {
      const progress = i / 23;
      // Add realistic price fluctuations
      const basePrice = startPrice + (btcPrice - startPrice) * progress;
      const fluctuation = Math.sin(i * 0.8) * (priceRange * 0.3) + (Math.random() - 0.5) * (priceRange * 0.2);
      const price = Math.max(minDisplayPrice, Math.min(maxDisplayPrice, basePrice + fluctuation));
      
      return {
        time: `${i}:00`,
        price: parseFloat(price.toFixed(2)),
        volume: parseFloat(((coinsData[0].total_volume || 0) / 24 + Math.random() * (coinsData[0].total_volume || 0) * 0.1).toFixed(2)),
      };
    });
  }, [coinsData]);

  const memecoins = ['doge', 'shib', 'pepe', 'floki', 'bonk', 'wif', 'meme'];
  
   const topGainers = useMemo(() => {
     if (!allCoinsData) return [];
     return allCoinsData
       .filter((coin: any) => 
         coin.price_change_percentage_24h > 0 && 
         !memecoins.includes(coin.symbol.toLowerCase())
       )
       .sort((a: any, b: any) => b.price_change_percentage_24h - a.price_change_percentage_24h)
       .slice(0, 5)
       .map((coin: any) => ({
         id: coin.id,
         name: coin.symbol.toUpperCase(),
         change: parseFloat(coin.price_change_percentage_24h.toFixed(2)),
         price: `$${coin.current_price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
         logo: coin.image,
       }));
   }, [allCoinsData]);

   const topLosers = useMemo(() => {
     if (!allCoinsData) return [];
     return allCoinsData
       .filter((coin: any) => 
         coin.price_change_percentage_24h < 0 && 
         !memecoins.includes(coin.symbol.toLowerCase())
       )
       .sort((a: any, b: any) => a.price_change_percentage_24h - b.price_change_percentage_24h)
       .slice(0, 5)
       .map((coin: any) => ({
         id: coin.id,
         name: coin.symbol.toUpperCase(),
         change: parseFloat(coin.price_change_percentage_24h.toFixed(2)),
         price: `$${coin.current_price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
         logo: coin.image,
       }));
   }, [allCoinsData]);

  if (isLoading) {
    return (
      <div className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <ChartSkeleton />
            <ChartSkeleton />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <LoadingSkeleton variant="card" className="h-96" />
            <LoadingSkeleton variant="card" className="h-96" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
      className="py-20"
    >
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-black mb-4 glow-cyan">Live Market Metrics</h2>
          <p className="text-foreground/70 text-lg">Real-time crypto market insights and trends</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Price Chart */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            <Tilt3DCard maxTilt={5}>
              <Card className="glass-card p-6">
              <div className="flex items-center gap-2 mb-4">
                <Activity className="w-5 h-5 text-primary" />
                <h3 className="text-xl font-bold">BTC Price Trend (24h)</h3>
              </div>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={priceData} margin={{ left: 20, right: 10, top: 10, bottom: 10 }}>
                  <defs>
                    <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))" 
                    domain={[
                      (dataMin: number) => Math.floor(dataMin - 100),
                      (dataMax: number) => Math.ceil(dataMax + 100)
                    ]}
                    tickFormatter={(value) => `$${value.toLocaleString()}`}
                    width={80}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      background: "hsl(var(--background))", 
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px"
                    }}
                    formatter={(value: number) => [`$${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 'Price']}
                  />
                  <Area type="monotone" dataKey="price" stroke="hsl(var(--primary))" fill="url(#priceGradient)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </Card>
            </Tilt3DCard>
          </motion.div>

          {/* Volume Chart */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
          >
            <Tilt3DCard maxTilt={5}>
              <Card className="glass-card p-6">
              <div className="flex items-center gap-2 mb-4">
                <DollarSign className="w-5 h-5 text-secondary" />
                <h3 className="text-xl font-bold">Trading Volume (24h)</h3>
              </div>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={priceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))" 
                    tickFormatter={(value) => `${(value / 1000000000).toFixed(1)}B`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      background: "hsl(var(--background))", 
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px"
                    }}
                    formatter={(value: number) => [`$${(value / 1000000000).toFixed(2)}B`, 'Volume']}
                  />
                  <Bar dataKey="volume" fill="hsl(var(--neon-purple))" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>
            </Tilt3DCard>
          </motion.div>
        </div>

        {/* Top Gainers & Losers */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -100 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4, duration: 0.8, type: "spring", stiffness: 60 }}
          >
            <Tilt3DCard maxTilt={6}>
              <Card className="glass-card p-6">
              <div className="flex items-center gap-2 mb-6">
                <TrendingUp className="w-5 h-5 text-primary" />
                <h3 className="text-xl font-bold">Top Gainers (24h)</h3>
              </div>
              <div className="space-y-4">
                {topGainers.map((coin, index) => (
                  <MarketCoinRow
                    key={coin.id}
                    coinId={coin.id}
                    name={coin.name}
                    price={coin.price}
                    change={coin.change}
                    logo={coin.logo}
                    direction="up"
                    index={index}
                  />
                ))}
              </div>
            </Card>
            </Tilt3DCard>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 100 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5, duration: 0.8, type: "spring", stiffness: 60 }}
          >
            <Tilt3DCard maxTilt={6}>
              <Card className="glass-card p-6">
              <div className="flex items-center gap-2 mb-6">
                <TrendingDown className="w-5 h-5 text-red-500" />
                <h3 className="text-xl font-bold">Top Losers (24h)</h3>
              </div>
              <div className="space-y-4">
                {topLosers.map((coin, index) => (
                  <MarketCoinRow
                    key={coin.id}
                    coinId={coin.id}
                    name={coin.name}
                    price={coin.price}
                    change={coin.change}
                    logo={coin.logo}
                    direction="down"
                    index={index}
                  />
                ))}
              </div>
            </Card>
            </Tilt3DCard>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};
