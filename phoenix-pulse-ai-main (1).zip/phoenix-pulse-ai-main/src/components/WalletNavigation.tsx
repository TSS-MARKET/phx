import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, X, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { useWalletAuth } from '@/contexts/WalletAuthContext';
import { motion, AnimatePresence } from 'framer-motion';

export const WalletNavigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { isAdmin } = useWalletAuth();
  const navigate = useNavigate();

  const navItems = [
    { name: 'Home', path: '/' },
    { name: 'Dashboard', path: '/dashboard' },
    { name: 'DApp', path: '/dapp' },
    { name: 'Features', path: '/features' },
    { name: 'Token', path: '/token' },
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' },
    { name: 'Subscription', path: '/subscription' }
  ];

  if (isAdmin) {
    navItems.push({ name: 'Admin', path: '/admin' });
  }

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed top-0 left-0 right-0 z-50 bg-background/30 backdrop-blur-2xl border-b border-cyan-500/20 shadow-[0_8px_32px_rgba(6,182,212,0.1)]"
      style={{
        backdropFilter: 'blur(20px) saturate(180%)',
        WebkitBackdropFilter: 'blur(20px) saturate(180%)',
      }}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-3">
            <img 
              src="/phx-ai-logo.png" 
              alt="Phoenix AI" 
              className="w-12 h-12 rounded-lg object-cover shadow-lg shadow-cyan-500/50"
            />
            <span className="text-xl font-bold font-orbitron tracking-wider text-white glow-cyan">
              PHOENIX AI
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className="text-sm font-medium text-muted-foreground hover:text-cyan-400 transition-colors"
              >
                {item.name}
              </Link>
            ))}
            <WalletMultiButton className="!bg-gradient-to-r !from-cyan-400 !via-blue-500 !to-blue-700 !rounded-xl hover:!from-cyan-300 hover:!to-blue-600 !transition-all !duration-300" />
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-2">
            <WalletMultiButton className="!bg-gradient-to-r !from-cyan-400 !via-blue-500 !to-blue-700 !rounded-xl !text-xs" />
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(!isOpen)}
              className="text-cyan-400"
            >
              {isOpen ? <X /> : <Menu />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden border-t border-cyan-500/20"
            >
              <div className="py-4 space-y-2">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setIsOpen(false)}
                    className="block px-4 py-2 text-sm font-medium text-muted-foreground hover:text-cyan-400 hover:bg-cyan-500/10 rounded-lg transition-all"
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.nav>
  );
};
