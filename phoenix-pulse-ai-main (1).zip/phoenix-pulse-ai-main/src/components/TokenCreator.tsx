import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Coins, Crown } from "lucide-react";
import { useSubscription } from "@/hooks/useSubscription";
import { useState } from "react";
import { PaymentModal } from "./PaymentModal";
import { TokenCreatorComplete } from "./TokenCreatorComplete";

export const TokenCreator = () => {
  const { canAccessFeature } = useSubscription();
  const [showUpgrade, setShowUpgrade] = useState(false);
  const hasAccess = canAccessFeature('token_creator');

  if (!hasAccess) {
    return (
      <>
        <Card className="p-8 text-center border-2 border-yellow-500/30 bg-yellow-500/5">
          <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
          <h3 className="text-2xl font-bold mb-2">Token Creator - Elite Feature</h3>
          <p className="text-muted-foreground mb-6">Launch Solana tokens directly from Phoenix AI with AI scoring.</p>
          <Button onClick={() => setShowUpgrade(true)} className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold">
            Upgrade to Elite
          </Button>
        </Card>
        <PaymentModal isOpen={showUpgrade} onClose={() => setShowUpgrade(false)} tier="elite" />
      </>
    );
  }

  return <TokenCreatorComplete />;
};