import { Card } from "@/components/ui/card";
import { useMemecoins } from "@/hooks/useMemecoins";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Flame, TrendingUp, Copy, RefreshCw, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";

const CoinCard = ({ coin, idx, isTopTrending, isMostReliable, copyToClipboard }: any) => (
  <motion.div
    key={coin.id || idx}
    initial={{ opacity: 0, x: -20 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ delay: idx * 0.05 }}
    className="p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-all hover-glow relative overflow-hidden group"
  >
    {/* Premium glow effect */}
    <motion.div
      className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity"
      animate={{
        backgroundPosition: ["0% 0%", "100% 100%"],
      }}
      transition={{
        duration: 3,
        repeat: Infinity,
        ease: "linear"
      }}
    />
    
    <div className="flex flex-col gap-3 relative z-10">
      {/* Top row */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 flex-1">
          <motion.img 
            src={coin.icon} 
            alt={coin.name} 
            className="w-12 h-12 rounded-full border-2 border-primary/30"
            whileHover={{ scale: 1.1, rotate: 5 }}
            transition={{ duration: 0.3 }}
          />
          <div>
            <div className="flex items-center gap-2">
              <div className="font-bold text-lg">{coin.name}</div>
              {isTopTrending && (
                <motion.div
                  animate={{
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                  }}
                >
                  <Badge variant="default" className="gap-1 bg-orange-500/20 text-orange-500 border-orange-500/30">
                    <Flame className="w-3 h-3" />
                    Top Trending
                  </Badge>
                </motion.div>
              )}
              {isMostReliable && (
                <motion.div
                  animate={{
                    scale: [1, 1.05, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                  }}
                >
                  <Badge variant="default" className="gap-1 bg-neon-purple/20 text-neon-purple border-neon-purple/30">
                    <TrendingUp className="w-3 h-3" />
                    Most Reliable
                  </Badge>
                </motion.div>
              )}
            </div>
            <div className="text-sm text-muted-foreground flex items-center gap-2">
              {coin.symbol}
              <span className="text-xs px-2 py-0.5 bg-primary/20 rounded">
                {coin.chain}
              </span>
            </div>
            {coin.pairAddress && (
              <div className="flex items-center gap-1 mt-1">
                <span className="text-xs text-muted-foreground font-mono">
                  {coin.pairAddress.slice(0, 6)}...{coin.pairAddress.slice(-4)}
                </span>
                <button
                  onClick={() => copyToClipboard(coin.pairAddress)}
                  className="p-1 hover:bg-muted rounded transition-colors"
                  title="Copy contract address"
                >
                  <Copy className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>
        </div>
        
        <div className="text-right">
          <div className="text-sm font-medium text-orange-500">Hype Score</div>
          <motion.div 
            className="text-3xl font-bold glow-orange"
            animate={{
              textShadow: [
                "0 0 20px rgba(251, 146, 60, 0.5)",
                "0 0 40px rgba(251, 146, 60, 0.8)",
                "0 0 20px rgba(251, 146, 60, 0.5)",
              ]
            }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            {coin.hypeScore}
          </motion.div>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 text-sm">
        <div>
          <div className="text-muted-foreground text-xs">Price</div>
          <div className="font-bold">${Number(coin.price || 0).toFixed(8)}</div>
        </div>
        <div>
          <div className="text-muted-foreground text-xs">24h Change</div>
          <div className={`font-bold flex items-center gap-1 ${Number(coin.priceChange24h) > 0 ? 'text-primary' : 'text-destructive'}`}>
            <TrendingUp className={`w-3 h-3 ${Number(coin.priceChange24h) < 0 ? 'rotate-180' : ''}`} />
            {Number(coin.priceChange24h || 0).toFixed(2)}%
          </div>
        </div>
        <div>
          <div className="text-muted-foreground text-xs">Volume 24h</div>
          <div className="font-bold">
            ${Number(coin.volume24h || 0) < 1000000 
              ? `${(Number(coin.volume24h || 0) / 1000).toFixed(0)}K`
              : `${(Number(coin.volume24h || 0) / 1000000).toFixed(2)}M`}
          </div>
        </div>
        <div>
          <div className="text-muted-foreground text-xs">Liquidity</div>
          <div className="font-bold">
            ${Number(coin.liquidity || 0) > 999000000
              ? `${(Number(coin.liquidity || 0) / 1000000000).toFixed(2)}B`
              : Number(coin.liquidity || 0) > 999000
              ? `${(Number(coin.liquidity || 0) / 1000000).toFixed(2)}M`
              : `${(Number(coin.liquidity || 0) / 1000).toFixed(0)}K`}
          </div>
        </div>
        <div>
          <div className="text-muted-foreground text-xs">Market Cap</div>
          <div className="font-bold">
            ${Number(coin.marketCap || 0) > 999000000
              ? `${(Number(coin.marketCap || 0) / 1000000000).toFixed(2)}B`
              : Number(coin.marketCap || 0) > 999000
              ? `${(Number(coin.marketCap || 0) / 1000000).toFixed(2)}M`
              : `${(Number(coin.marketCap || 0) / 1000).toFixed(0)}K`}
          </div>
        </div>
        <div>
          <div className="text-muted-foreground text-xs">FDV</div>
          <div className="font-bold">
            ${Number(coin.fdv || 0) > 999000000
              ? `${(Number(coin.fdv || 0) / 1000000000).toFixed(2)}B`
              : Number(coin.fdv || 0) > 999000
              ? `${(Number(coin.fdv || 0) / 1000000).toFixed(2)}M`
              : `${(Number(coin.fdv || 0) / 1000).toFixed(0)}K`}
          </div>
        </div>
      </div>
      
      {/* Hype Score Bar */}
      <div className="w-full bg-muted rounded-full h-2">
        <motion.div
          className="h-2 rounded-full bg-gradient-to-r from-orange-500 via-red-500 to-pink-500"
          initial={{ width: 0 }}
          animate={{ width: `${coin.hypeScore}%` }}
          transition={{ duration: 1, delay: idx * 0.05 }}
        />
      </div>
    </div>
  </motion.div>
);

export const SocialBuzzSection = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const { data: memeData, isLoading, refetch } = useMemecoins({ search: searchQuery });
  const { toast } = useToast();
  const [lastRefresh, setLastRefresh] = useState(Date.now());

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Contract address copied to clipboard",
    });
  };

  // Auto-refresh every 60 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      refetch();
      setLastRefresh(Date.now());
    }, 60000);
    return () => clearInterval(interval);
  }, [refetch]);

  const handleManualRefresh = () => {
    refetch();
    setLastRefresh(Date.now());
    toast({
      title: "Refreshed!",
      description: "Fetching latest memecoin data...",
    });
  };

  // Filter out coins without logos
  const filteredData: any[] = (memeData?.data || []).filter((coin: any) => coin.icon);
  
  // Example memecoins to display when no search
  const exampleCoins = [
    { id: 1, name: "DogeCoin", symbol: "DOGE", icon: "https://coin-images.coingecko.com/coins/images/5/large/dogecoin.png", chain: "dogecoin", price: "0.15234", priceChange24h: "5.67", volume24h: "1234567890", liquidity: "9876543210", marketCap: "21234567890", fdv: "23456789012", hypeScore: 85, pairAddress: "0x1234...5678" },
    { id: 2, name: "Shiba Inu", symbol: "SHIB", icon: "https://coin-images.coingecko.com/coins/images/11939/large/shiba.png", chain: "ethereum", price: "0.00001234", priceChange24h: "-2.34", volume24h: "987654321", liquidity: "8765432109", marketCap: "9876543210", fdv: "10987654321", hypeScore: 78, pairAddress: "0xabcd...efgh" },
    { id: 3, name: "Pepe", symbol: "PEPE", icon: "https://coin-images.coingecko.com/coins/images/29850/large/pepe-token.jpeg", chain: "ethereum", price: "0.00000789", priceChange24h: "12.45", volume24h: "876543210", liquidity: "7654321098", marketCap: "8765432109", fdv: "9876543210", hypeScore: 92, pairAddress: "0x9876...1234" },
    { id: 4, name: "Floki", symbol: "FLOKI", icon: "https://coin-images.coingecko.com/coins/images/16746/large/PNG_image.png", chain: "bsc", price: "0.00003456", priceChange24h: "8.90", volume24h: "765432109", liquidity: "6543210987", marketCap: "7654321098", fdv: "8765432109", hypeScore: 71, pairAddress: "0x5678...9abc" },
    { id: 5, name: "BabyDoge", symbol: "BABYDOGE", icon: "https://coin-images.coingecko.com/coins/images/16125/large/babydoge.jpg", chain: "bsc", price: "0.00000000234", priceChange24h: "-5.67", volume24h: "654321098", liquidity: "5432109876", marketCap: "6543210987", fdv: "7654321098", hypeScore: 64, pairAddress: "0xdef0...4567" },
    { id: 6, name: "Bonk", symbol: "BONK", icon: "https://coin-images.coingecko.com/coins/images/28600/large/bonk.jpg", chain: "solana", price: "0.000012345", priceChange24h: "15.23", volume24h: "543210987", liquidity: "4321098765", marketCap: "5432109876", fdv: "6543210987", hypeScore: 88, pairAddress: "So11...Bonk" },
    { id: 7, name: "Degen", symbol: "DEGEN", icon: "https://coin-images.coingecko.com/coins/images/34515/large/degen.jpeg", chain: "base", price: "0.0123456", priceChange24h: "3.45", volume24h: "432109876", liquidity: "3210987654", marketCap: "4321098765", fdv: "5432109876", hypeScore: 76, pairAddress: "0xbase...degen" },
    { id: 8, name: "WIF", symbol: "WIF", icon: "https://coin-images.coingecko.com/coins/images/33566/large/dogwifhat.jpg", chain: "solana", price: "1.23456", priceChange24h: "7.89", volume24h: "321098765", liquidity: "2109876543", marketCap: "3210987654", fdv: "4321098765", hypeScore: 83, pairAddress: "So11...WIF" },
    { id: 9, name: "TURBO", symbol: "TURBO", icon: "https://coin-images.coingecko.com/coins/images/30278/large/turbo.png", chain: "ethereum", price: "0.00456789", priceChange24h: "-1.23", volume24h: "210987654", liquidity: "1098765432", marketCap: "2109876543", fdv: "3210987654", hypeScore: 69, pairAddress: "0xturbo...fast" },
    { id: 10, name: "MYRO", symbol: "MYRO", icon: "https://coin-images.coingecko.com/coins/images/33433/large/myro.jpg", chain: "solana", price: "0.0789012", priceChange24h: "4.56", volume24h: "109876543", liquidity: "987654321", marketCap: "1098765432", fdv: "2109876543", hypeScore: 72, pairAddress: "So11...MYRO" },
  ];

  const displayedCoins = searchQuery ? filteredData : exampleCoins;

  return (
    <Card className="glass-card p-6">
      <div className="flex items-center gap-2 mb-6">
        <Flame className="w-6 h-6 text-orange-500" />
        <h3 className="text-2xl font-bold glow-orange">Memecoin Hype Tracker</h3>
      </div>

      {/* Search Bar */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search by name, symbol, or contract address..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 bg-muted/30 border-primary/20"
        />
      </div>

      {/* Display coins */}
      <div className="space-y-3">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-orange-500" />
            <h4 className="text-lg font-bold">
              {searchQuery ? "Search Results" : "Popular Memecoins"}
            </h4>
          </div>
          <span className="text-xs text-muted-foreground">
            {searchQuery ? `${displayedCoins.length} results found` : `Last update: ${new Date(lastRefresh).toLocaleTimeString()}`}
          </span>
        </div>
        {isLoading ? (
          [...Array(10)].map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-lg" />
          ))
        ) : displayedCoins.length ? (
          displayedCoins.map((coin: any, idx: number) => (
            <CoinCard 
              key={coin.id || idx}
              coin={coin}
              idx={idx}
              isTopTrending={!searchQuery && idx === 0}
              isMostReliable={coin.mostReliable || false}
              copyToClipboard={copyToClipboard}
            />
          ))
        ) : (
          <p className="text-muted-foreground text-center py-8">
            {searchQuery ? `No results found for "${searchQuery}"` : "No memecoins available"}
          </p>
        )}
      </div>
    </Card>
  );
};