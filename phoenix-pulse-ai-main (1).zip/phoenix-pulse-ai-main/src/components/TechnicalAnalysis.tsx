import { Card } from "@/components/ui/card";
import { useTopCoins } from "@/hooks/useCoinGecko";
import { LoadingSkeleton } from "@/components/ui/loading-skeleton";
import { Input } from "@/components/ui/input";
import { TrendingUp, TrendingDown, Activity, Search } from "lucide-react";
import { motion } from "framer-motion";
import { useState, useMemo, useEffect } from "react";
import { CoinSearchDialog } from "./CoinSearchDialog";
import { useSingleCoinLogo } from "@/hooks/useCoinLogos";
import { useCoinMarketData } from "@/hooks/useCoinMarketData";

interface TechnicalIndicator {
  name: string;
  value: number;
  signal: "bullish" | "bearish" | "neutral";
  description: string;
}

const calculateRSI = (priceChange24h: number, priceChange7d: number): number => {
  // RSI based on price momentum - simplified calculation
  const momentum = (priceChange24h + priceChange7d / 7) / 2;
  const rsi = 50 + (momentum * 2); // Center at 50
  return Math.min(100, Math.max(0, rsi));
};

const calculateMACD = (priceChange24h: number, priceChange7d: number): number => {
  // MACD approximation: difference between fast and slow moving averages
  const fastMA = priceChange24h;
  const slowMA = priceChange7d / 7;
  return fastMA - slowMA;
};

const TechnicalAnalysis = () => {
  const { data: coinsData, isLoading } = useTopCoins();
  const [selectedCoin, setSelectedCoin] = useState<any>(null);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const { data: coinLogo } = useSingleCoinLogo(selectedCoin?.id);
  const { data: coinMarketData, isLoading: isLoadingMarketData } = useCoinMarketData(selectedCoin?.id);

  const getIndicators = (coin: any): TechnicalIndicator[] => {
    const rsi = calculateRSI(coin.price_change_percentage_24h || 0, coin.price_change_percentage_7d_in_currency || 0);
    const macd = calculateMACD(coin.price_change_percentage_24h || 0, coin.price_change_percentage_7d_in_currency || 0);
    const priceChange24h = coin.price_change_24h || 0;
    
    return [
      {
        name: "RSI (Relative Strength Index)",
        value: rsi,
        signal: rsi > 70 ? "bearish" : rsi < 30 ? "bullish" : "neutral",
        description: rsi > 70 ? "Overbought - potential sell signal" : rsi < 30 ? "Oversold - potential buy signal" : "Neutral momentum"
      },
      {
        name: "MACD (Moving Average Convergence Divergence)",
        value: macd,
        signal: macd > 0 ? "bullish" : macd < 0 ? "bearish" : "neutral",
        description: macd > 0 ? "Bullish momentum building" : "Bearish pressure present"
      },
      {
        name: "24h Price Change",
        value: Math.abs(priceChange24h),
        signal: priceChange24h > 0 ? "bullish" : "bearish",
        description: `${priceChange24h > 0 ? 'Positive' : 'Negative'} price movement`
      },
      {
        name: "24h Volume",
        value: coin.total_volume || 0,
        signal: (coin.total_volume / coin.market_cap) > 0.1 ? "bullish" : "neutral",
        description: (coin.total_volume / coin.market_cap) > 0.1 ? "High trading activity" : "Normal trading activity"
      },
      {
        name: "Support Level",
        value: coin.low_24h,
        signal: "neutral",
        description: `Strong support at $${coin.low_24h.toLocaleString()}`
      },
      {
        name: "Resistance Level",
        value: coin.high_24h,
        signal: "neutral",
        description: `Key resistance at $${coin.high_24h.toLocaleString()}`
      }
    ];
  };

  // Update selected coin with market data when it becomes available
  useEffect(() => {
    if (coinMarketData && selectedCoin?.id === coinMarketData.id) {
      setSelectedCoin(coinMarketData);
    }
  }, [coinMarketData]);

  const handleCoinSelect = (coin: any) => {
    setSelectedCoin({
      id: coin.id,
      symbol: coin.symbol,
      name: coin.name,
      current_price: 0,
      high_24h: 0,
      low_24h: 0,
      price_change_percentage_24h: 0,
      market_cap: 0,
      total_volume: 0,
    });
    setIsSearchOpen(false);
  };

  if (isLoading || isLoadingMarketData) {
    return (
      <div className="space-y-6">
        <LoadingSkeleton variant="card" className="h-32" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <LoadingSkeleton variant="card" />
          <LoadingSkeleton variant="card" />
          <LoadingSkeleton variant="card" />
          <LoadingSkeleton variant="card" />
          <LoadingSkeleton variant="card" />
          <LoadingSkeleton variant="card" />
        </div>
      </div>
    );
  }

  const displayCoin = selectedCoin || coinsData?.[0];
  const indicators = displayCoin ? getIndicators(displayCoin) : [];

  return (
    <div className="space-y-6">
      <CoinSearchDialog
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelect={handleCoinSelect}
      />

      {/* Asset Search & Selector */}
      <Card className="glass-card p-6">
        <h3 className="text-xl font-bold mb-4 glow-cyan">Select Asset for Analysis</h3>
        
        <div className="mb-4 relative cursor-pointer" onClick={() => setIsSearchOpen(true)}>
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search any cryptocurrency..."
            value={selectedCoin ? `${selectedCoin.name} (${selectedCoin.symbol.toUpperCase()})` : ""}
            readOnly
            className="pl-10 bg-muted/30 border-primary/20 focus:border-primary cursor-pointer"
          />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {coinsData?.slice(0, 10).map((coin: any) => (
            <motion.button
              key={coin.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedCoin(coin)}
              className={`p-3 rounded-lg transition-all ${
                selectedCoin?.id === coin.id || (!selectedCoin && coin.id === coinsData?.[0]?.id)
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted/30 hover:bg-muted/50"
              }`}
            >
              <div className="text-sm font-bold">{coin.symbol.toUpperCase()}</div>
              <div className="text-xs opacity-80">${coin.current_price.toLocaleString()}</div>
            </motion.button>
          ))}
        </div>
      </Card>

      {/* Technical Indicators */}
      <Card className="glass-card p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            {coinLogo && (
              <img src={coinLogo} alt={displayCoin?.name} className="w-10 h-10 rounded-full" />
            )}
            <h3 className="text-2xl font-bold glow-cyan">
              Technical Analysis - {displayCoin?.name} ({displayCoin?.symbol.toUpperCase()})
            </h3>
          </div>
          <div className="text-3xl font-black glow-cyan">
            ${displayCoin?.current_price.toLocaleString()}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {indicators.map((indicator, idx) => (
            <motion.div
              key={indicator.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-all hover-glow"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="text-sm font-medium text-muted-foreground">
                  {indicator.name}
                </div>
                {indicator.signal === "bullish" && (
                  <TrendingUp className="w-5 h-5 text-primary" />
                )}
                {indicator.signal === "bearish" && (
                  <TrendingDown className="w-5 h-5 text-destructive" />
                )}
                {indicator.signal === "neutral" && (
                  <Activity className="w-5 h-5 text-muted-foreground" />
                )}
              </div>
              <div className="text-2xl font-bold mb-2">
                {indicator.name === "24h Volume" 
                  ? `$${(indicator.value / 1e9).toFixed(2)}B`
                  : indicator.name === "24h Price Change"
                  ? `$${indicator.value.toFixed(2)}`
                  : typeof indicator.value === 'number' 
                  ? indicator.value.toFixed(2) 
                  : indicator.value}
              </div>
              <div className="text-xs text-muted-foreground">
                {indicator.description}
              </div>
              
              {/* Signal indicator bar */}
              <div className="mt-3 w-full bg-muted rounded-full h-1.5">
                <div
                  className={`h-1.5 rounded-full transition-all ${
                    indicator.signal === "bullish"
                      ? "bg-primary"
                      : indicator.signal === "bearish"
                      ? "bg-destructive"
                      : "bg-muted-foreground"
                  }`}
                  style={{ 
                    width: indicator.signal === "neutral" ? "50%" : 
                           indicator.signal === "bullish" ? "75%" : "25%" 
                  }}
                />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Overall Signal */}
        <div className="mt-6 p-4 rounded-lg bg-primary/10 border border-primary/30">
          <div className="flex items-center gap-3">
            <Activity className="w-6 h-6 text-primary" />
            <div>
              <div className="font-bold text-lg">Overall Signal</div>
              <div className="text-sm text-muted-foreground">
                {indicators.filter(i => i.signal === "bullish").length > indicators.filter(i => i.signal === "bearish").length
                  ? "🟢 Bullish trend detected - Strong buy signals across multiple indicators"
                  : indicators.filter(i => i.signal === "bearish").length > indicators.filter(i => i.signal === "bullish").length
                  ? "🔴 Bearish trend detected - Consider taking profits or waiting"
                  : "🟡 Neutral - Market consolidating, wait for clearer signals"}
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default TechnicalAnalysis;
