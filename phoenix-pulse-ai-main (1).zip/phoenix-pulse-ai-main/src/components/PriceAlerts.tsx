import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Bell, BellOff, Trash2, Plus } from "lucide-react";
import { usePriceAlerts } from "@/hooks/usePriceAlerts";
import { CoinSearchDialog } from "./CoinSearchDialog";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

export const PriceAlerts = () => {
  const { alerts, isLoading, createAlert, deleteAlert } = usePriceAlerts();
  const [showAddForm, setShowAddForm] = useState(false);
  const [showSearchDialog, setShowSearchDialog] = useState(false);
  const [newAlert, setNewAlert] = useState({
    token_symbol: "",
    coin_id: "",
    alert_type: "above" as "above" | "below",
    target_price: "",
    current_price: 0,
  });
  const { toast } = useToast();

  // Request notification permission
  const requestNotificationPermission = async () => {
    if ("Notification" in window && Notification.permission === "default") {
      const permission = await Notification.requestPermission();
      if (permission === "granted") {
        toast({
          title: "Notifications Enabled",
          description: "You'll receive alerts when prices hit your targets",
        });
      }
    }
  };

  const handleCoinSelect = (coin: any) => {
    setNewAlert({
      ...newAlert,
      token_symbol: coin.symbol.toUpperCase(),
      coin_id: coin.id,
      current_price: coin.current_price || 0,
    });
    setShowSearchDialog(false);
    setShowAddForm(true);
  };

  const handleCreateAlert = () => {
    if (!newAlert.token_symbol || !newAlert.target_price) {
      toast({
        title: "Missing Information",
        description: "Please select a coin and enter a target price",
        variant: "destructive",
      });
      return;
    }

    createAlert({
      token_symbol: newAlert.token_symbol,
      coin_id: newAlert.coin_id,
      alert_type: newAlert.alert_type,
      target_price: parseFloat(newAlert.target_price),
      current_price: newAlert.current_price,
    });

    setNewAlert({
      token_symbol: "",
      coin_id: "",
      alert_type: "above",
      target_price: "",
      current_price: 0,
    });
    setShowAddForm(false);
    requestNotificationPermission();
  };

  return (
    <>
      <Card className="p-6 bg-secondary/50 backdrop-blur border-border/50">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Bell className="w-6 h-6 text-primary" />
            <h3 className="text-xl font-bold text-foreground">Price Alerts</h3>
          </div>
          <Button
            onClick={() => setShowSearchDialog(true)}
            className="bg-primary hover:bg-primary/90"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Alert
          </Button>
        </div>

        <AnimatePresence>
          {showAddForm && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-6 p-4 bg-background/50 rounded-lg border border-border"
            >
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-muted-foreground mb-2 block">
                    Selected Coin
                  </label>
                  <p className="text-foreground font-semibold">
                    {newAlert.token_symbol || "None"}
                  </p>
                </div>

                <div>
                  <label className="text-sm text-muted-foreground mb-2 block">
                    Alert Type
                  </label>
                  <div className="flex gap-2">
                    <Button
                      variant={newAlert.alert_type === "above" ? "default" : "outline"}
                      onClick={() => setNewAlert({ ...newAlert, alert_type: "above" })}
                      className="flex-1"
                    >
                      Above
                    </Button>
                    <Button
                      variant={newAlert.alert_type === "below" ? "default" : "outline"}
                      onClick={() => setNewAlert({ ...newAlert, alert_type: "below" })}
                      className="flex-1"
                    >
                      Below
                    </Button>
                  </div>
                </div>

                <div>
                  <label className="text-sm text-muted-foreground mb-2 block">
                    Target Price ($)
                  </label>
                  <Input
                    type="number"
                    value={newAlert.target_price}
                    onChange={(e) =>
                      setNewAlert({ ...newAlert, target_price: e.target.value })
                    }
                    placeholder="Enter target price"
                    className="bg-background"
                  />
                </div>

                <div className="flex gap-2">
                  <Button onClick={handleCreateAlert} className="flex-1 bg-primary">
                    Create Alert
                  </Button>
                  <Button
                    onClick={() => setShowAddForm(false)}
                    variant="outline"
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="space-y-3">
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">
              Loading alerts...
            </div>
          ) : alerts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No price alerts yet. Create one to get notified!
            </div>
          ) : (
            alerts.map((alert) => (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="p-4 bg-background/50 rounded-lg border border-border hover:border-primary/50 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                      <Bell className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">
                        {alert.token_symbol}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Alert when price goes{" "}
                        <span className="text-primary">{alert.alert_type}</span> $
                        {alert.target_price.toFixed(2)}
                      </p>
                    </div>
                  </div>
                  <Button
                    onClick={() => deleteAlert(alert.id)}
                    variant="ghost"
                    size="sm"
                    className="text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </Card>

      <CoinSearchDialog
        isOpen={showSearchDialog}
        onClose={() => setShowSearchDialog(false)}
        onSelect={handleCoinSelect}
      />
    </>
  );
};
