import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useWalletCopyTrading } from '@/hooks/useWalletCopyTrading';
import { Copy, Play, Pause, Trash2, Plus, Users, TrendingUp, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const WalletCopyTrading = () => {
  const {
    copiedWallets,
    isMonitoring,
    addWalletToCopy,
    removeWalletFromCopy,
    startMonitoring,
    stopMonitoring
  } = useWalletCopyTrading();

  const [walletInput, setWalletInput] = useState('');

  const handleAddWallet = () => {
    if (walletInput.trim()) {
      addWalletToCopy(walletInput.trim());
      setWalletInput('');
    }
  };

  // Mock top traders data
  const topTraders = [
    {
      address: '7xKXtg2...',
      name: 'Whale Alpha',
      winRate: 87,
      followers: 1200,
      profit24h: '+$45,000'
    },
    {
      address: '9mFvZp3...',
      name: 'Degen Master',
      winRate: 82,
      followers: 890,
      profit24h: '+$32,000'
    },
    {
      address: '5qRtYn8...',
      name: 'Smart Money',
      winRate: 79,
      followers: 650,
      profit24h: '+$28,000'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <Card className="bg-gradient-to-br from-primary/20 to-card/80 backdrop-blur-xl border-primary/50 shadow-[0_0_40px_rgba(79,209,197,0.3)]">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Copy className="w-6 h-6 text-primary" />
              <CardTitle className="text-primary font-orbitron glow-cyan">Copy Trading</CardTitle>
            </div>
            <Badge variant={isMonitoring ? "default" : "secondary"} className="gap-2 bg-primary/20 border-primary/40">
              {isMonitoring ? (
                <>
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  Active
                </>
              ) : (
                'Paused'
              )}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-white/80">
            Automatically replicate trades from successful traders in real-time
          </p>

          {/* Add Wallet Input */}
          <div className="flex gap-2">
            <Input
              placeholder="Enter Solana wallet address..."
              value={walletInput}
              onChange={(e) => setWalletInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAddWallet()}
              className="bg-background/50 border-primary/30"
            />
            <Button 
              onClick={handleAddWallet}
              className="bg-primary/20 hover:bg-primary/30 border border-primary/40"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add
            </Button>
          </div>

          {/* Control Buttons */}
          <div className="flex gap-2">
            {isMonitoring ? (
              <Button
                onClick={stopMonitoring}
                variant="destructive"
                className="flex-1"
              >
                <Pause className="w-4 h-4 mr-2" />
                Stop Monitoring
              </Button>
            ) : (
              <Button
                onClick={startMonitoring}
                className="flex-1 bg-primary/20 hover:bg-primary/30 border border-primary/40"
                disabled={copiedWallets.length === 0}
              >
                <Play className="w-4 h-4 mr-2" />
                Start Monitoring
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Copied Wallets List */}
      {copiedWallets.length > 0 && (
        <Card className="bg-card/50 backdrop-blur-xl border-primary/30">
          <CardHeader>
            <CardTitle className="text-lg font-orbitron">Monitored Wallets ({copiedWallets.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <AnimatePresence>
              <div className="space-y-2">
                {copiedWallets.map((wallet, index) => (
                  <motion.div
                    key={wallet}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ delay: index * 0.05 }}
                    className="flex items-center justify-between p-3 bg-background/50 rounded-lg border border-primary/20"
                  >
                    <div className="flex items-center gap-3">
                      <Copy className="w-4 h-4 text-primary" />
                      <span className="font-mono text-sm">{wallet.slice(0, 8)}...{wallet.slice(-8)}</span>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => removeWalletFromCopy(wallet)}
                      className="hover:bg-destructive/20 hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </motion.div>
                ))}
              </div>
            </AnimatePresence>
          </CardContent>
        </Card>
      )}

      {/* Top Traders */}
      <Card className="bg-card/50 backdrop-blur-xl border-primary/30">
        <CardHeader>
          <CardTitle className="text-lg font-orbitron flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            Top Performing Traders
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {topTraders.map((trader, index) => (
              <motion.div
                key={trader.address}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="p-4 bg-gradient-to-br from-primary/20 via-background to-secondary/10 rounded-lg border border-primary/30 hover:border-primary/60 hover:shadow-[0_0_30px_rgba(6,182,212,0.3)] transition-all duration-300"
                whileHover={{ scale: 1.02, y: -2 }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold">{trader.name}</span>
                      <Badge variant="secondary" className="text-xs">
                        <Users className="w-3 h-3 mr-1" />
                        {trader.followers}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground font-mono">{trader.address}</p>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => addWalletToCopy(trader.address)}
                    className="bg-gradient-to-r from-primary via-primary/90 to-secondary hover:from-primary/90 hover:via-primary hover:to-secondary/90 border border-primary shadow-[0_0_20px_rgba(6,182,212,0.4)] hover:shadow-[0_0_30px_rgba(6,182,212,0.6)] transition-all duration-300"
                    disabled={copiedWallets.includes(trader.address)}
                  >
                    {copiedWallets.includes(trader.address) ? 'Following' : 'Follow'}
                  </Button>
                </div>
                <div className="flex items-center gap-4 text-xs">
                  <div>
                    <span className="text-muted-foreground">Win Rate:</span>
                    <span className="ml-2 text-primary font-semibold">{trader.winRate}%</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">24h Profit:</span>
                    <span className="ml-2 text-primary font-semibold">{trader.profit24h}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Info Banner */}
      <Card className="bg-yellow-500/10 border-yellow-500/30">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-yellow-500 mt-0.5 flex-shrink-0" />
            <div className="space-y-1">
              <p className="text-sm font-semibold">Risk Disclaimer</p>
              <p className="text-xs text-muted-foreground">
                Copy trading involves significant risk. Past performance does not guarantee future results.
                Always do your own research and only invest what you can afford to lose.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
