import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bot, TrendingUp, TrendingDown, Target, Activity, Crown, DollarSign } from "lucide-react";
import { useSubscription } from "@/hooks/useSubscription";
import { useTradingBot } from "@/hooks/useTradingBot";
import { PaymentModal } from "./PaymentModal";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@solana/wallet-adapter-react";
import { motion } from "framer-motion";

const POPULAR_TOKENS = {
  SOL: "So11111111111111111111111111111111111111112",
  USDC: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
  USDT: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
};

export const TradingBotComplete = () => {
  const { canAccessFeature } = useSubscription();
  const { getTradeSignal, recordTrade, tradeHistory, analytics, isLoadingHistory } = useTradingBot();
  const { toast } = useToast();
  const wallet = useWallet();
  
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [mode, setMode] = useState<'signal' | 'auto'>('signal');
  const [fromToken, setFromToken] = useState(POPULAR_TOKENS.SOL);
  const [toToken, setToToken] = useState(POPULAR_TOKENS.USDC);
  const [amount, setAmount] = useState("1");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentSignal, setCurrentSignal] = useState<any>(null);

  const hasAccess = canAccessFeature('trading_bot');

  if (!hasAccess) {
    return (
      <>
        <Card className="p-8 text-center border-2 border-yellow-500/30 bg-yellow-500/5 backdrop-blur">
          <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-foreground mb-2">
            AI Trading Bot - Elite Feature
          </h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Unlock AI-powered trading signals with confidence scoring and automated execution via Jupiter Aggregator.
          </p>
          <Button 
            onClick={() => setShowUpgrade(true)}
            className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-300 hover:to-orange-400 text-white font-bold"
          >
            Upgrade to Elite
          </Button>
        </Card>
        <PaymentModal 
          isOpen={showUpgrade}
          onClose={() => setShowUpgrade(false)}
          tier="elite"
        />
      </>
    );
  }

  const handleAnalyzeTrade = async () => {
    if (!wallet.connected) {
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet to analyze trades.",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    try {
      const amountLamports = parseFloat(amount) * 1000000000; // Convert to lamports
      const signal = await getTradeSignal(fromToken, toToken, amountLamports);
      setCurrentSignal(signal);
      
      toast({
        title: "Analysis Complete",
        description: `AI Confidence: ${signal.aiConfidence}% - ${signal.recommendation.toUpperCase()}`,
      });
    } catch (error: any) {
      toast({
        title: "Analysis Failed",
        description: error.message || "Failed to analyze trade",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleExecuteTrade = async () => {
    if (!wallet.connected || !wallet.signTransaction) {
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet to execute trades.",
        variant: "destructive",
      });
      return;
    }

    if (!currentSignal) {
      toast({
        title: "No Signal",
        description: "Please analyze the trade first.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Trade Execution",
      description: "Jupiter swap integration coming soon! This will execute real trades on Solana.",
    });

    // Record the trade intent
    recordTrade({
      trade_type: 'buy',
      mode: mode,
      from_token: fromToken,
      to_token: toToken,
      amount_in: parseFloat(amount),
      ai_confidence: currentSignal.aiConfidence,
      status: 'pending',
    });
  };

  const getSignalColor = (recommendation: string) => {
    switch (recommendation) {
      case 'strong_buy': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'buy': return 'bg-neon-purple/20 text-neon-purple border-neon-purple/30';
      case 'hold': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'avoid': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 mb-4">
          <Bot className="w-5 h-5 text-cyan-400" />
          <span className="text-sm font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
            PHOENIX TRADING BOT
          </span>
        </div>
        <h2 className="text-3xl font-bold text-foreground mb-2">
          AI-Powered Trading Signals
        </h2>
        <p className="text-muted-foreground">
          Jupiter Aggregator • Real-time Analysis • Elite AI
        </p>
      </div>

      {/* Trading Analytics */}
      {analytics && (
        <div className="grid md:grid-cols-4 gap-4 mb-6">
          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            transition={{ duration: 0.2 }}
          >
            <Card className="p-4 bg-primary/5 border-primary/20 hover:border-primary/50 hover:shadow-lg hover:shadow-primary/20 transition-all duration-300 relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="relative z-10">
                <div className="text-xs text-muted-foreground mb-1">Total Trades</div>
                <div className="text-2xl font-bold text-foreground">{analytics.total_trades}</div>
              </div>
            </Card>
          </motion.div>
          
          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            transition={{ duration: 0.2 }}
          >
            <Card className="p-4 bg-green-500/5 border-green-500/20 hover:border-green-500/50 hover:shadow-lg hover:shadow-green-500/20 transition-all duration-300 relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="relative z-10">
                <div className="text-xs text-muted-foreground mb-1">Win Rate</div>
                <div className="text-2xl font-bold text-green-400">
                  {analytics.total_trades > 0 
                    ? Math.round((analytics.winning_trades / analytics.total_trades) * 100)
                    : 0}%
                </div>
              </div>
            </Card>
          </motion.div>
          
          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            transition={{ duration: 0.2 }}
          >
            <Card className="p-4 bg-neon-purple/5 border-neon-purple/20 hover:border-neon-purple/50 hover:shadow-lg hover:shadow-neon-purple/20 transition-all duration-300 relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-neon-purple/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="relative z-10">
                <div className="text-xs text-muted-foreground mb-1">Avg ROI</div>
                <div className="text-2xl font-bold text-neon-purple">
                  {analytics.average_roi?.toFixed(2)}%
                </div>
              </div>
            </Card>
          </motion.div>
          
          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            transition={{ duration: 0.2 }}
          >
            <Card className="p-4 bg-cyan-500/5 border-cyan-500/20 hover:border-cyan-500/50 hover:shadow-lg hover:shadow-cyan-500/20 transition-all duration-300 relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="relative z-10">
                <div className="text-xs text-muted-foreground mb-1">Total P/L</div>
                <div className={`text-2xl font-bold ${analytics.total_profit_loss >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {analytics.total_profit_loss >= 0 ? '+' : ''}{analytics.total_profit_loss?.toFixed(4)} SOL
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
      )}

      <Tabs value={mode} onValueChange={(v) => setMode(v as 'signal' | 'auto')} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6 bg-background/40 backdrop-blur border border-primary/20">
          <TabsTrigger value="signal">Signal Mode</TabsTrigger>
          <TabsTrigger value="auto">Auto Mode</TabsTrigger>
        </TabsList>

        <TabsContent value="signal" className="space-y-6">
          <Card className="p-6 border-2 border-primary/30 bg-background/40 backdrop-blur">
            <h3 className="text-xl font-bold text-foreground mb-4 flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              Get AI Trade Signal
            </h3>

            <div className="space-y-4 mb-6">
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">From Token</label>
                <select
                  value={fromToken}
                  onChange={(e) => setFromToken(e.target.value)}
                  className="w-full p-3 rounded-lg bg-background border border-primary/20 text-foreground"
                >
                  <option value={POPULAR_TOKENS.SOL}>SOL (Solana)</option>
                  <option value={POPULAR_TOKENS.USDC}>USDC</option>
                  <option value={POPULAR_TOKENS.USDT}>USDT</option>
                </select>
              </div>

              <div>
                <label className="text-sm text-muted-foreground mb-2 block">To Token</label>
                <select
                  value={toToken}
                  onChange={(e) => setToToken(e.target.value)}
                  className="w-full p-3 rounded-lg bg-background border border-primary/20 text-foreground"
                >
                  <option value={POPULAR_TOKENS.USDC}>USDC</option>
                  <option value={POPULAR_TOKENS.USDT}>USDT</option>
                  <option value={POPULAR_TOKENS.SOL}>SOL (Solana)</option>
                </select>
              </div>

              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Amount</label>
                <Input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="1.0"
                  className="bg-background border-primary/20"
                />
              </div>
            </div>

            <Button
              onClick={handleAnalyzeTrade}
              disabled={isAnalyzing || !wallet.connected}
              className="w-full bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-white font-bold py-6"
            >
              {isAnalyzing ? "Analyzing..." : "Analyze Trade"}
            </Button>
          </Card>

          {currentSignal && (
            <Card className="p-6 border-2 border-primary/30 bg-background/40 backdrop-blur">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-foreground">AI Signal</h3>
                <Badge className={`${getSignalColor(currentSignal.recommendation)} border font-bold px-4 py-2 text-base`}>
                  {currentSignal.recommendation.toUpperCase().replace('_', ' ')}
                </Badge>
              </div>

              <div className="grid md:grid-cols-2 gap-4 mb-6">
                <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
                  <div className="text-xs text-muted-foreground mb-1">AI Confidence</div>
                  <div className="text-3xl font-bold bg-gradient-to-r from-primary to-blue-500 bg-clip-text text-transparent">
                    {currentSignal.aiConfidence}%
                  </div>
                </div>
                <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
                  <div className="text-xs text-muted-foreground mb-1">Risk Level</div>
                  <div className={`text-2xl font-bold ${
                    currentSignal.riskLevel === 'low' ? 'text-green-400' :
                    currentSignal.riskLevel === 'medium' ? 'text-yellow-400' : 'text-red-400'
                  }`}>
                    {currentSignal.riskLevel.toUpperCase()}
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4 mb-6">
                <div className="p-3 rounded-lg bg-neon-purple/10 border border-neon-purple/30">
                  <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                    <DollarSign className="w-3 h-3" />
                    Entry Price
                  </div>
                  <div className="text-sm font-bold text-neon-purple">
                    ${currentSignal.entryPrice?.toFixed(4)}
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/30">
                  <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    Target
                  </div>
                  <div className="text-sm font-bold text-green-400">
                    ${currentSignal.targetPrice?.toFixed(4)}
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30">
                  <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                    <TrendingDown className="w-3 h-3" />
                    Stop Loss
                  </div>
                  <div className="text-sm font-bold text-red-400">
                    ${currentSignal.stopLoss?.toFixed(4)}
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-lg bg-primary/5 border border-primary/20 mb-4">
                <p className="text-sm text-muted-foreground">{currentSignal.reasoning}</p>
              </div>

              {mode === 'signal' && currentSignal.recommendation !== 'avoid' && (
                <Button
                  onClick={handleExecuteTrade}
                  disabled={!wallet.connected}
                  className="w-full bg-gradient-to-r from-green-400 to-emerald-500 hover:from-green-300 hover:to-emerald-400 text-white font-bold py-6"
                >
                  Execute Trade (Coming Soon)
                </Button>
              )}
            </Card>
          )}
        </TabsContent>

        <TabsContent value="auto">
          <Card className="p-8 text-center border-2 border-primary/30 bg-background/40 backdrop-blur">
            <Bot className="w-16 h-16 text-primary mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-foreground mb-2">
              Auto Mode Coming Soon
            </h3>
            <p className="text-muted-foreground">
              Automated trade execution with AI will be available shortly. This will automatically execute trades based on Phoenix AI signals.
            </p>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Trade History */}
      {tradeHistory && tradeHistory.length > 0 && (
        <Card className="p-6 border-2 border-primary/30 bg-background/40 backdrop-blur">
          <h3 className="text-xl font-bold text-foreground mb-4">Trade History</h3>
          <div className="space-y-3">
            {tradeHistory.slice(0, 10).map((trade) => (
              <div key={trade.id} className="p-4 rounded-lg bg-primary/5 border border-primary/20 flex items-center justify-between">
                <div>
                  <div className="font-bold text-foreground">{trade.trade_type.toUpperCase()}</div>
                  <div className="text-sm text-muted-foreground">
                    {trade.amount_in} • {new Date(trade.executed_at).toLocaleString()}
                  </div>
                </div>
                <Badge className={`${trade.status === 'completed' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                  {trade.status}
                </Badge>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};