import { useSwipeable } from "react-swipeable";
import { motion, AnimatePresence } from "framer-motion";
import { ReactNode, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface SwipeNavigationProps {
  sections: Array<{ id: string; title: string; content: ReactNode }>;
}

export const SwipeNavigation = ({ sections }: SwipeNavigationProps) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  const handlers = useSwipeable({
    onSwipedLeft: () => {
      if (currentIndex < sections.length - 1) {
        setDirection(1);
        setCurrentIndex(prev => prev + 1);
      }
    },
    onSwipedRight: () => {
      if (currentIndex > 0) {
        setDirection(-1);
        setCurrentIndex(prev => prev - 1);
      }
    },
    trackMouse: true,
    preventScrollOnSwipe: true,
  });

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.9,
    }),
    center: {
      x: 0,
      opacity: 1,
      scale: 1,
    },
    exit: (direction: number) => ({
      x: direction < 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.9,
    }),
  };

  return (
    <div className="relative w-full overflow-hidden" {...handlers}>
      {/* Progress Indicators */}
      <div className="flex justify-center gap-2 mb-6">
        {sections.map((_, idx) => (
          <motion.button
            key={idx}
            onClick={() => {
              setDirection(idx > currentIndex ? 1 : -1);
              setCurrentIndex(idx);
            }}
            className={`h-2 rounded-full transition-all ${
              idx === currentIndex ? "w-8 bg-primary" : "w-2 bg-muted"
            }`}
            whileHover={{ scale: 1.2 }}
            whileTap={{ scale: 0.9 }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative min-h-[400px]">
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={currentIndex}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 },
              scale: { duration: 0.2 },
            }}
            className="absolute inset-0"
          >
            <div className="space-y-4">
              <h3 className="text-2xl font-bold text-center glow-cyan">
                {sections[currentIndex].title}
              </h3>
              {sections[currentIndex].content}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation Arrows (Desktop) */}
      <div className="hidden md:flex justify-between absolute top-1/2 -translate-y-1/2 w-full px-4 pointer-events-none">
        {currentIndex > 0 && (
          <motion.button
            whileHover={{ scale: 1.1, x: -5 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => {
              setDirection(-1);
              setCurrentIndex(prev => prev - 1);
            }}
            className="pointer-events-auto glass-card p-3 rounded-full hover:bg-primary/20 transition-colors"
          >
            <ChevronLeft className="w-6 h-6 text-primary" />
          </motion.button>
        )}
        <div />
        {currentIndex < sections.length - 1 && (
          <motion.button
            whileHover={{ scale: 1.1, x: 5 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => {
              setDirection(1);
              setCurrentIndex(prev => prev + 1);
            }}
            className="pointer-events-auto glass-card p-3 rounded-full hover:bg-primary/20 transition-colors"
          >
            <ChevronRight className="w-6 h-6 text-primary" />
          </motion.button>
        )}
      </div>

      {/* Swipe Hint */}
      <div className="text-center mt-4 md:hidden">
        <p className="text-xs text-muted-foreground">
          Swipe left or right to navigate
        </p>
      </div>
    </div>
  );
};
