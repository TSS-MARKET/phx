import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Check, Crown, Zap, Rocket } from "lucide-react";
import { useSubscription } from "@/hooks/useSubscription";
import { useState } from "react";
import { PaymentModal } from "./PaymentModal";

const TIER_DETAILS = {
  free: {
    name: "Free Plan",
    icon: Zap,
    color: "text-gray-400",
    bgColor: "bg-gray-500/10",
    borderColor: "border-gray-500/30",
    price: "$0",
    features: [
      "1 coin analysis per day",
      "Basic market data",
      "Technical indicators",
      "Community support",
    ],
  },
  pro: {
    name: "Pro Plan",
    icon: Rocket,
    color: "text-cyan-400",
    bgColor: "bg-cyan-500/10",
    borderColor: "border-cyan-500/30",
    price: "$9.99/month",
    features: [
      "Unlimited coin analysis",
      "Advanced sentiment tracker",
      "Portfolio AI insights",
      "Priority support",
      "Early access to features",
    ],
  },
  elite: {
    name: "Elite Plan",
    icon: Crown,
    color: "text-yellow-400",
    bgColor: "bg-yellow-500/10",
    borderColor: "border-yellow-500/30",
    price: "$49.99/month",
    features: [
      "All Pro features",
      "Phoenix Daily 3 (AI picks)",
      "MemeCoin Hype Tracker",
      "AI Trading Bot (Signal + Auto)",
      "Token Creator & Liquidity Launcher",
      "Telegram/Discord alerts",
      "24/7 VIP support",
      "Phoenix Approved Project badge",
    ],
  },
};

export const SubscriptionDashboard = () => {
  const { subscription, isLoading } = useSubscription();
  const [showPayment, setShowPayment] = useState(false);
  const [selectedTier, setSelectedTier] = useState<'pro' | 'elite'>('pro');

  if (isLoading) {
    return (
      <div className="space-y-6 animate-fade-in">
        <Card className="p-6 bg-background/40 backdrop-blur border-primary/20">
          <div className="h-32 bg-primary/5 animate-pulse rounded" />
        </Card>
      </div>
    );
  }

  const currentTier = subscription?.tier || 'free';
  const currentDetails = TIER_DETAILS[currentTier];
  const Icon = currentDetails.icon;

  const handleUpgradeClick = (tier: 'pro' | 'elite') => {
    setSelectedTier(tier);
    setShowPayment(true);
  };

  return (
    <>
      <div className="space-y-8 animate-fade-in">
        {/* Current Subscription Card */}
        <Card className={`p-6 border-2 ${currentDetails.borderColor} ${currentDetails.bgColor} backdrop-blur relative overflow-hidden`}>
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent pointer-events-none" />
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`p-3 rounded-xl ${currentDetails.bgColor} ${currentDetails.borderColor} border`}>
                  <Icon className={`w-6 h-6 ${currentDetails.color}`} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-foreground">{currentDetails.name}</h3>
                  <p className="text-sm text-muted-foreground">
                    {subscription?.status === 'active' ? 'Active' : 'Inactive'}
                  </p>
                </div>
              </div>
              <Badge variant="outline" className={`${currentDetails.color} border-current`}>
                Current Plan
              </Badge>
            </div>

            {subscription?.subscription_end && (
              <p className="text-sm text-muted-foreground mb-4">
                {subscription.status === 'cancelled' 
                  ? `Cancels on ${new Date(subscription.subscription_end).toLocaleDateString()}`
                  : `Renews on ${new Date(subscription.subscription_end).toLocaleDateString()}`
                }
              </p>
            )}

            {currentTier === 'free' && (
              <div className="mt-4">
                <p className="text-sm text-muted-foreground mb-2">
                  Daily Analysis: {subscription?.daily_analysis_count || 0} / 1 used
                </p>
                <div className="h-2 bg-background/50 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-primary to-blue-500 transition-all duration-300"
                    style={{ width: `${(subscription?.daily_analysis_count || 0) * 100}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        </Card>

        {/* Upgrade Options */}
        {currentTier !== 'elite' && (
          <div className="grid md:grid-cols-2 gap-6">
            {(currentTier === 'free' ? ['pro', 'elite'] : ['elite']).map((tier) => {
              const details = TIER_DETAILS[tier as 'pro' | 'elite'];
              const TierIcon = details.icon;
              
              return (
                <Card key={tier} className={`p-6 border-2 ${details.borderColor} hover:${details.bgColor} transition-all duration-300 hover:scale-105`}>
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`p-3 rounded-xl ${details.bgColor} ${details.borderColor} border`}>
                      <TierIcon className={`w-6 h-6 ${details.color}`} />
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-foreground">{details.name}</h4>
                      <p className="text-2xl font-bold bg-gradient-to-r from-primary to-blue-500 bg-clip-text text-transparent">
                        {details.price}
                      </p>
                    </div>
                  </div>

                  <ul className="space-y-2 mb-6">
                    {details.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm">
                        <Check className={`w-4 h-4 mt-0.5 flex-shrink-0 ${details.color}`} />
                        <span className="text-muted-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button 
                    onClick={() => handleUpgradeClick(tier as 'pro' | 'elite')}
                    className={`w-full bg-gradient-to-r ${
                      tier === 'elite' 
                        ? 'from-yellow-400 to-orange-500 hover:from-yellow-300 hover:to-orange-400' 
                        : 'from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400'
                    } text-white font-bold shadow-lg hover:shadow-xl transition-all duration-300`}
                  >
                    Upgrade to {details.name}
                  </Button>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      <PaymentModal 
        isOpen={showPayment}
        onClose={() => setShowPayment(false)}
        tier={selectedTier}
      />
    </>
  );
};