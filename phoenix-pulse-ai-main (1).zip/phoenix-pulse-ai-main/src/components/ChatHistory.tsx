import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card } from "@/components/ui/card";
import { History, X, Trash2, MessageSquare, Wallet } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { WalletConnect, getWalletAddress } from "./WalletConnect";
import {
  Conversation,
  getAllConversations,
  deleteConversation,
  clearAllConversations,
} from "@/utils/chatStorage";

interface ChatHistoryProps {
  isOpen: boolean;
  onClose: () => void;
  onLoadConversation: (conversationId: string) => void;
}

export const ChatHistory = ({ isOpen, onClose, onLoadConversation }: ChatHistoryProps) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      loadHistory();
    }
  }, [isOpen]);

  const loadHistory = () => {
    setIsLoading(true);
    try {
      const walletAddress = getWalletAddress();
      if (!walletAddress) {
        setConversations([]);
        setIsLoading(false);
        return;
      }

      const userConversations = getAllConversations(walletAddress);
      setConversations(userConversations);
    } catch (error) {
      console.error("Error loading history:", error);
      toast({
        title: "Error",
        description: "Failed to load chat history",
        variant: "destructive",
      });
      setConversations([]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearHistory = () => {
    try {
      const walletAddress = getWalletAddress();
      if (!walletAddress) return;

      clearAllConversations(walletAddress);
      setConversations([]);
      toast({
        title: "History Cleared",
        description: "All chat conversations have been deleted",
      });
    } catch (error) {
      console.error("Error clearing history:", error);
      toast({
        title: "Error",
        description: "Failed to clear chat history",
        variant: "destructive",
      });
    }
  };

  const handleDeleteConversation = (conversationId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      deleteConversation(conversationId);
      setConversations(conversations.filter(conv => conv.id !== conversationId));
      toast({
        title: "Conversation Deleted",
        description: "The conversation has been removed",
      });
    } catch (error) {
      console.error("Error deleting conversation:", error);
      toast({
        title: "Error",
        description: "Failed to delete conversation",
        variant: "destructive",
      });
    }
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffInHours < 48) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  const walletAddress = getWalletAddress();

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.95 }}
          className="fixed bottom-24 right-[28rem] w-96 h-[600px] z-50 glass-card rounded-xl border border-primary/30 flex flex-col shadow-2xl"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-primary/20">
            <div className="flex items-center gap-2">
              <History className="w-6 h-6 text-primary" />
              <h3 className="font-bold glow-cyan">Chat History</h3>
            </div>
            <div className="flex gap-2">
              {walletAddress && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={clearHistory}
                  className="hover:bg-destructive/10 hover:text-destructive"
                  title="Clear all history"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="hover:bg-primary/10"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Wallet Connection */}
          {!walletAddress && (
            <div className="p-4 bg-primary/10 border-b border-primary/20">
              <div className="flex items-center gap-2 mb-3">
                <Wallet className="w-5 h-5 text-primary" />
                <p className="text-sm font-semibold">Connect Wallet Required</p>
              </div>
              <p className="text-sm text-foreground/80 mb-3">
                Connect your wallet to view your personal chat history
              </p>
              <WalletConnect />
            </div>
          )}

          {/* History List */}
          <ScrollArea className="flex-1 p-4">
            {isLoading ? (
              <div className="flex items-center justify-center h-full">
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                  <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                  <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              </div>
            ) : !walletAddress ? (
              <div className="flex flex-col items-center justify-center h-full gap-4">
                <Wallet className="w-16 h-16 text-muted-foreground/50" />
                <p className="text-sm text-muted-foreground text-center">
                  Connect your wallet to access your chat history
                </p>
              </div>
            ) : conversations.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full gap-4">
                <MessageSquare className="w-16 h-16 text-muted-foreground/50" />
                <p className="text-sm text-muted-foreground text-center">
                  No conversations yet.<br />Start a new conversation to see it here.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {conversations.map((conversation, index) => (
                  <motion.div
                    key={conversation.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    onClick={() => onLoadConversation(conversation.id)}
                    className="cursor-pointer"
                  >
                    <Card className="p-4 bg-primary/5 hover:bg-primary/10 border-primary/20 hover:border-primary/40 transition-all group">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-sm mb-1 line-clamp-1 glow-cyan">
                            {conversation.title}
                          </h4>
                          <p className="text-xs text-muted-foreground mb-2">
                            {conversation.messages.length} messages
                          </p>
                          {conversation.messages.length > 0 && (
                            <p className="text-xs text-foreground/60 line-clamp-2">
                              {conversation.messages[conversation.messages.length - 1].content}
                            </p>
                          )}
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <span className="text-xs text-muted-foreground whitespace-nowrap">
                            {formatDate(conversation.updatedAt)}
                          </span>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => handleDeleteConversation(conversation.id, e)}
                            className="h-6 w-6 opacity-0 group-hover:opacity-100 hover:bg-destructive/10 hover:text-destructive"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </div>
            )}
          </ScrollArea>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
