import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Award, Crown, CheckCircle, XCircle, Wallet } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export type HoldingTier = "basic" | "premium" | "elite" | "none";

interface HoldingsVerificationProps {
  onConnect?: (tier: HoldingTier) => void;
}

const tierData = {
  basic: {
    name: "Basic",
    amount: 500,
    icon: Shield,
    color: "from-gray-500 to-gray-600",
    badgeColor: "bg-gray-600",
    textColor: "text-gray-300",
    features: ["Basic AI Analysis", "Daily Trading Signals", "Portfolio Tracking"],
  },
  premium: {
    name: "Premium",
    amount: 2500,
    icon: Award,
    color: "from-cyan-500 to-blue-600",
    badgeColor: "bg-gradient-to-r from-cyan-500 to-blue-600",
    textColor: "text-cyan-400",
    features: ["All Basic Features", "Advanced AI Analytics", "Real-time Signals", "Memecoin Tracker"],
  },
  elite: {
    name: "Elite",
    amount: 12500,
    icon: Crown,
    color: "from-amber-500 to-orange-600",
    badgeColor: "bg-gradient-to-r from-amber-500 to-orange-600",
    textColor: "text-amber-400",
    features: ["All Premium Features", "VIP AI Models", "Priority Execution", "Exclusive Insights", "24/7 VIP Support"],
  },
};

export const HoldingsVerification = ({ onConnect }: HoldingsVerificationProps) => {
  const [isConnected, setIsConnected] = useState(false);
  const [currentHoldings, setCurrentHoldings] = useState(0);
  const [currentTier, setCurrentTier] = useState<HoldingTier>("none");
  const { toast } = useToast();

  const getTierFromHoldings = (holdings: number): HoldingTier => {
    if (holdings >= 12500) return "elite";
    if (holdings >= 2500) return "premium";
    if (holdings >= 500) return "basic";
    return "none";
  };

  const handleConnect = async () => {
    try {
      // For now, use demo wallet address
      // In production, integrate with actual Solana wallet adapter
      const demoWalletAddress = 'DemoWallet' + Math.random().toString(36).substring(7);
      
      // Call verification edge function
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/verify-phx-holdings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`
        },
        body: JSON.stringify({ walletAddress: demoWalletAddress })
      });

      if (!response.ok) {
        throw new Error('Verification failed');
      }

      const data = await response.json();
      
      setCurrentHoldings(data.balance);
      setCurrentTier(data.tier as HoldingTier);
      setIsConnected(true);
      
      toast({
        title: data.demo ? "Wallet Connected (Demo)" : "Wallet Connected",
        description: `Found ${data.balance.toLocaleString()} PHX tokens - ${data.tier === "none" ? "No tier" : tierData[data.tier as keyof typeof tierData].name} tier${data.demo ? ' (Demo Mode)' : ''}`,
      });

      onConnect?.(data.tier as HoldingTier);
    } catch (error) {
      console.error('Connection error:', error);
      toast({
        title: "Connection Failed",
        description: "Failed to verify PHX holdings. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleDisconnect = () => {
    setIsConnected(false);
    setCurrentHoldings(0);
    setCurrentTier("none");
    onConnect?.("none");
    
    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected",
    });
  };

  return (
    <div className="space-y-8">
      {/* Connection Status */}
      <Card className="glass-card p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Wallet className="w-6 h-6 text-primary" />
            <h3 className="text-2xl font-bold">Wallet Connection</h3>
          </div>
          {isConnected && (
            <div className="flex items-center gap-2 text-neon-purple">
              <CheckCircle className="w-5 h-5" />
              <span className="font-bold">Connected</span>
            </div>
          )}
        </div>

        {!isConnected ? (
          <div className="space-y-4">
            <p className="text-foreground/70">
              Connect your wallet to verify your $PHX holdings and unlock premium features
            </p>
            <Button
              onClick={handleConnect}
              className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 font-bold text-lg py-6"
            >
              Connect Wallet (Demo)
            </Button>
            <p className="text-sm text-muted-foreground text-center">
              Token CA: TBA (Not yet launched - Demo Mode)
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-card border border-border">
              <div className="text-sm text-muted-foreground mb-1">Your Holdings</div>
              <div className="text-3xl font-bold glow-cyan">{currentHoldings.toLocaleString()} PHX</div>
              {currentTier !== "none" && (
                <div className="mt-2">
                  <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-bold ${tierData[currentTier].badgeColor}`}>
                    {(() => {
                      const TierIcon = tierData[currentTier].icon;
                      return <TierIcon className="w-4 h-4" />;
                    })()}
                    {tierData[currentTier].name} Tier
                  </span>
                </div>
              )}
            </div>
            <Button
              onClick={handleDisconnect}
              variant="outline"
              className="w-full font-bold"
            >
              Disconnect Wallet
            </Button>
          </div>
        )}
      </Card>

      {/* Tier Benefits */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {(Object.keys(tierData) as Array<keyof typeof tierData>).map((tier) => {
          const data = tierData[tier];
          const TierIcon = data.icon;
          const isActive = currentTier === tier;
          const hasAccess = currentTier !== "none" && 
            (tier === "basic" && (currentTier === "basic" || currentTier === "premium" || currentTier === "elite")) ||
            (tier === "premium" && (currentTier === "premium" || currentTier === "elite")) ||
            (tier === "elite" && currentTier === "elite");

          return (
            <motion.div
              key={tier}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * (tier === "basic" ? 0 : tier === "premium" ? 1 : 2) }}
              whileHover={{ scale: 1.02, y: -4 }}
            >
              <Card className={`glass-card p-6 relative overflow-hidden ${isActive ? "border-2" : ""}`}
                style={isActive ? { borderColor: `hsl(var(--${tier === "basic" ? "muted" : tier === "premium" ? "primary" : "accent"}))` } : {}}
              >
                {isActive && (
                  <div className="absolute top-2 right-2">
                    <CheckCircle className="w-6 h-6 text-neon-purple" />
                  </div>
                )}
                
                <div className="flex items-center justify-center mb-4">
                  <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${data.color} flex items-center justify-center`}>
                    <TierIcon className="w-8 h-8 text-white" />
                  </div>
                </div>

                <h3 className={`text-2xl font-bold text-center mb-2 ${data.textColor}`}>
                  {data.name}
                </h3>

                <div className="text-center mb-6">
                  <div className="text-3xl font-bold mb-1">
                    {data.amount.toLocaleString()} PHX
                  </div>
                  <div className="text-sm text-muted-foreground">Minimum Holdings</div>
                </div>

                <div className="space-y-3 mb-6">
                  {data.features.map((feature, index) => (
                    <div key={index} className="flex items-start gap-2">
                      {hasAccess ? (
                        <CheckCircle className="w-5 h-5 text-neon-purple flex-shrink-0 mt-0.5" />
                      ) : (
                        <XCircle className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                      )}
                      <span className={`text-sm ${hasAccess ? "" : "text-muted-foreground"}`}>
                        {feature}
                      </span>
                    </div>
                  ))}
                </div>

                {!isActive && (
                  <Button
                    className={`w-full bg-gradient-to-r ${data.color} hover:opacity-90 font-bold`}
                    disabled={!isConnected || hasAccess}
                  >
                    {isConnected ? (hasAccess ? "Unlocked" : "Upgrade") : "Connect Wallet"}
                  </Button>
                )}
              </Card>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
