import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Wallet } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export const WalletConnect = () => {
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const savedWallet = localStorage.getItem("phoenix_wallet_address");
    if (savedWallet) setWalletAddress(savedWallet);
  }, []);

  const connectWallet = async () => {
    try {
      const { solana } = window as any;

      if (!solana) {
        toast({
          title: "Wallet Not Found",
          description: "Please install Phantom or another Solana wallet",
          variant: "destructive",
        });
        return;
      }

      const response = await solana.connect();
      const address = response.publicKey.toString();
      setWalletAddress(address);
      localStorage.setItem("phoenix_wallet_address", address);

      toast({
        title: "Wallet Connected",
        description: `Connected: ${address.slice(0, 4)}...${address.slice(-4)}`,
      });
    } catch (error) {
      console.error("Error connecting wallet:", error);
      toast({
        title: "Connection Failed",
        description: "Failed to connect wallet. Please try again.",
        variant: "destructive",
      });
    }
  };

  const disconnectWallet = () => {
    setWalletAddress(null);
    localStorage.removeItem("phoenix_wallet_address");
    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected",
    });
  };

  return (
    <div>
      {walletAddress ? (
        <Button
          variant="outline"
          onClick={disconnectWallet}
          className="flex items-center gap-2 rounded-xl border border-cyan-500 text-cyan-400 hover:bg-cyan-500/10 transition-all duration-300"
        >
          <Wallet className="w-4 h-4 text-cyan-400" />
          <span className="text-sm font-medium">
            {walletAddress.slice(0, 4)}...{walletAddress.slice(-4)}
          </span>
        </Button>
      ) : (
        <Button
          onClick={connectWallet}
          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 via-blue-500 to-blue-700 text-white hover:from-cyan-300 hover:to-blue-600 transition-all duration-300 shadow-[0_0_12px_rgba(0,255,255,0.5)]"
        >
          <Wallet className="w-4 h-4" />
          <span className="text-sm font-medium">Connect Wallet</span>
        </Button>
      )}
    </div>
  );
};

export const getWalletAddress = (): string | null => {
  return localStorage.getItem("phoenix_wallet_address");
};
