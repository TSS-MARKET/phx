import { motion } from "framer-motion";
import { Mic, MicOff } from "lucide-react";
import { cn } from "@/lib/utils";

interface VoiceWaveformProps {
  isActive: boolean;
  audioLevel?: number;
}

export const VoiceWaveform = ({ isActive, audioLevel = 0 }: VoiceWaveformProps) => {
  const bars = 12;
  const baseHeight = 4;
  
  return (
    <div className="flex flex-col items-center gap-4">
      {/* Microphone Icon */}
      <motion.div
        animate={{
          scale: isActive ? [1, 1.1, 1] : 1,
        }}
        transition={{
          duration: 0.8,
          repeat: isActive ? Infinity : 0,
        }}
        className={cn(
          "relative p-6 rounded-full border-2",
          "bg-gradient-to-br transition-all duration-300",
          isActive
            ? "from-electric-teal/30 to-neon-aqua/30 border-electric-teal shadow-[0_0_30px_rgba(0,255,255,0.5)]"
            : "from-cyber-purple/20 to-electric-teal/20 border-cyber-purple/50"
        )}
      >
        {isActive ? (
          <Mic className="w-8 h-8 text-electric-teal" />
        ) : (
          <MicOff className="w-8 h-8 text-muted-foreground" />
        )}

        {/* Pulse rings when active */}
        {isActive && (
          <>
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-electric-teal"
              initial={{ scale: 1, opacity: 0.5 }}
              animate={{ scale: 1.5, opacity: 0 }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-neon-aqua"
              initial={{ scale: 1, opacity: 0.5 }}
              animate={{ scale: 2, opacity: 0 }}
              transition={{ duration: 1.5, repeat: Infinity, delay: 0.3 }}
            />
          </>
        )}
      </motion.div>

      {/* Waveform Bars */}
      <div className="flex items-center justify-center gap-1 h-20">
        {Array.from({ length: bars }).map((_, index) => {
          const delay = index * 0.05;
          const normalizedLevel = Math.min(audioLevel / 100, 1);
          const heightMultiplier = isActive ? 1 + normalizedLevel * 3 : 0.5;
          
          return (
            <motion.div
              key={index}
              className={cn(
                "w-1 rounded-full",
                isActive
                  ? "bg-gradient-to-t from-electric-teal to-neon-aqua"
                  : "bg-muted"
              )}
              animate={{
                height: isActive
                  ? [
                      baseHeight * heightMultiplier,
                      baseHeight * heightMultiplier * (1 + Math.random()),
                      baseHeight * heightMultiplier,
                    ]
                  : baseHeight,
              }}
              transition={{
                duration: 0.5,
                repeat: isActive ? Infinity : 0,
                delay,
                ease: "easeInOut",
              }}
              style={{
                boxShadow: isActive
                  ? "0 0 10px rgba(0, 255, 255, 0.5)"
                  : "none",
              }}
            />
          );
        })}
      </div>

      {/* Status Text */}
      <p className={cn(
        "text-sm font-orbitron transition-colors",
        isActive ? "text-electric-teal glow-teal" : "text-muted-foreground"
      )}>
        {isActive ? "Listening..." : "Voice Command Inactive"}
      </p>
    </div>
  );
};
