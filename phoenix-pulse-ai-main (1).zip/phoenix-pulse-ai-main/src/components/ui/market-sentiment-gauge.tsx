import { useMemo } from "react";
import { Card } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Minus, Activity } from "lucide-react";
import { motion } from "framer-motion";
import { useLunarCrush } from "@/hooks/useLunarCrush";

interface SentimentGaugeProps {
  className?: string;
}

export const MarketSentimentGauge = ({ className = "" }: SentimentGaugeProps) => {
  const { data: socialData, isLoading } = useLunarCrush({ symbol: "BTC" });

  // Calculate real sentiment score from social data
  const sentimentScore = useMemo(() => {
    if (!socialData) return 50; // Neutral default

    const factors = [];
    
    // Social volume impact (normalized to 0-100)
    if (socialData.social_volume) {
      const normalizedVolume = Math.min((socialData.social_volume / 50000) * 100, 100);
      factors.push(normalizedVolume);
    }
    
    // Galaxy score (already 0-100)
    if (socialData.galaxy_score) {
      factors.push(socialData.galaxy_score);
    }
    
    // Alt rank (inverse - lower rank = higher sentiment)
    if (socialData.alt_rank) {
      const normalizedRank = Math.max(0, 100 - (socialData.alt_rank * 2));
      factors.push(normalizedRank);
    }
    
    // Social dominance
    if (socialData.social_dominance) {
      const normalizedDominance = Math.min(socialData.social_dominance * 2, 100);
      factors.push(normalizedDominance);
    }

    if (factors.length === 0) return 50;
    
    const average = factors.reduce((sum, val) => sum + val, 0) / factors.length;
    return Math.round(Math.min(Math.max(average, 0), 100));
  }, [socialData]);

  const sentimentLevel = useMemo(() => {
    if (sentimentScore >= 75) return { label: "Extreme Greed", color: "text-green-400", icon: TrendingUp };
    if (sentimentScore >= 60) return { label: "Greed", color: "text-primary", icon: TrendingUp };
    if (sentimentScore >= 45) return { label: "Neutral", color: "text-white/80", icon: Minus };
    if (sentimentScore >= 30) return { label: "Fear", color: "text-orange-500", icon: TrendingDown };
    return { label: "Extreme Fear", color: "text-red-500", icon: TrendingDown };
  }, [sentimentScore]);

  const Icon = sentimentLevel.icon;

  // Calculate needle rotation (-90 to 90 degrees)
  const needleRotation = (sentimentScore / 100) * 180 - 90;

  return (
    <Card className={`glass-card p-6 animated-bg-vibrant ${className}`}>
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-2xl font-bold gradient-text-vibrant">Market Sentiment</h3>
        <Activity className="w-6 h-6 text-primary" />
      </div>

      {/* Gauge Display */}
      <div className="relative flex items-center justify-center mb-8">
        <div className="relative w-64 h-32">
          {/* Gauge Background */}
          <svg viewBox="0 0 200 100" className="w-full h-full">
            {/* Gradient definitions */}
            <defs>
              <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="hsl(0, 70%, 50%)" />
                <stop offset="25%" stopColor="hsl(30, 100%, 50%)" />
                <stop offset="50%" stopColor="hsl(60, 100%, 50%)" />
                <stop offset="75%" stopColor="hsl(90, 100%, 50%)" />
                <stop offset="100%" stopColor="hsl(120, 100%, 40%)" />
              </linearGradient>
            </defs>
            
            {/* Background arc */}
            <path
              d="M 20 90 A 80 80 0 0 1 180 90"
              fill="none"
              stroke="rgba(255, 255, 255, 0.1)"
              strokeWidth="20"
              strokeLinecap="round"
            />
            
            {/* Colored arc */}
            <path
              d="M 20 90 A 80 80 0 0 1 180 90"
              fill="none"
              stroke="url(#gaugeGradient)"
              strokeWidth="20"
              strokeLinecap="round"
            />
            
            {/* Needle */}
            <motion.g
              initial={{ rotate: -90 }}
              animate={{ rotate: needleRotation }}
              transition={{ duration: 1, ease: "easeOut" }}
              style={{ transformOrigin: "100px 90px" }}
            >
              <line
                x1="100"
                y1="90"
                x2="100"
                y2="30"
                stroke="hsl(268, 85%, 58%)"
                strokeWidth="3"
                strokeLinecap="round"
              />
              <circle
                cx="100"
                cy="90"
                r="6"
                fill="hsl(268, 85%, 58%)"
              />
            </motion.g>
          </svg>
        </div>
      </div>

      {/* Sentiment Details */}
      <div className="text-center mb-6">
        <div className="flex items-center justify-center gap-3 mb-2">
          <Icon className={`w-8 h-8 ${sentimentLevel.color}`} />
          <div className={`text-3xl font-bold ${sentimentLevel.color}`}>
            {sentimentLevel.label}
          </div>
        </div>
        <div className="text-sm text-white/60">
          Sentiment Score: <span className="text-white font-bold">{sentimentScore}/100</span>
        </div>
      </div>

      {/* Detailed Indicators */}
      <div className="grid grid-cols-3 gap-4">
        <motion.div 
          className="p-4 rounded-lg bg-gradient-to-br from-primary/5 to-transparent border border-primary/20 cursor-pointer relative overflow-hidden"
          whileHover={{ 
            scale: 1.05,
            y: -4,
            borderColor: "rgba(79, 209, 197, 0.8)",
            boxShadow: "0 8px 30px rgba(79, 209, 197, 0.4)",
          }}
          transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
        >
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/20 to-primary/0"
            initial={{ x: "-100%" }}
            whileHover={{ x: "100%" }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
          />
          <div className="relative z-10">
            <div className="text-xs text-white/60 mb-1">Social Volume</div>
            <div className="text-lg font-bold text-primary glow-cyan">
              {isLoading ? "..." : socialData?.social_volume ? `${(socialData.social_volume / 1000).toFixed(1)}K` : "50K"}
            </div>
          </div>
        </motion.div>
        
        <motion.div 
          className="p-4 rounded-lg bg-muted/30 border border-neon-purple/20 cursor-pointer relative overflow-hidden"
          whileHover={{ 
            scale: 1.05,
            y: -4,
            borderColor: "rgba(168, 85, 247, 0.8)",
            boxShadow: "0 8px 30px rgba(168, 85, 247, 0.4)",
          }}
          transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
        >
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-purple-500/0 via-purple-500/20 to-purple-500/0"
            initial={{ x: "-100%" }}
            whileHover={{ x: "100%" }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
          />
          <div className="relative z-10">
            <div className="text-xs text-white/60 mb-1">Bull/Bear</div>
            <div className={`text-lg font-bold ${sentimentScore >= 50 ? 'text-green-400' : 'text-red-400'}`}>
              {sentimentScore >= 50 ? "🐂 Bull" : "🐻 Bear"}
            </div>
          </div>
        </motion.div>
        
        <motion.div 
          className="p-4 rounded-lg bg-muted/30 border border-neon-orange/20 cursor-pointer relative overflow-hidden"
          whileHover={{ 
            scale: 1.05,
            y: -4,
            borderColor: "rgba(251, 146, 60, 0.8)",
            boxShadow: "0 8px 30px rgba(251, 146, 60, 0.4)",
          }}
          transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
        >
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-orange-500/0 via-orange-500/20 to-orange-500/0"
            initial={{ x: "-100%" }}
            whileHover={{ x: "100%" }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
          />
          <div className="relative z-10">
            <div className="text-xs text-white/60 mb-1">Trend</div>
            <div className="text-lg font-bold text-neon-orange">
              {sentimentScore >= 60 ? "↗️ Up" : sentimentScore >= 40 ? "→ Flat" : "↘️ Down"}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Description */}
      <div className="mt-6 p-4 rounded-lg bg-primary/10 border border-primary/30">
        <p className="text-sm text-white/80">
          <span className="font-bold text-primary">Market Analysis:</span>{" "}
          {sentimentScore >= 75 && "Markets showing extreme bullish sentiment. Consider taking profits."}
          {sentimentScore >= 60 && sentimentScore < 75 && "Strong bullish momentum with positive social indicators."}
          {sentimentScore >= 45 && sentimentScore < 60 && "Neutral market conditions with balanced sentiment."}
          {sentimentScore >= 30 && sentimentScore < 45 && "Bearish sentiment detected. Caution advised."}
          {sentimentScore < 30 && "Extreme fear in markets. Potential buying opportunity for long-term holders."}
        </p>
      </div>
    </Card>
  );
};
