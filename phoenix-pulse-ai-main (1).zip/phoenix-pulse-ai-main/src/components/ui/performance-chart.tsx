import { useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";
import { TrendingUp, TrendingDown } from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface PerformanceChartProps {
  data?: Array<{ date: string; value: number; benchmark?: number }>;
  title?: string;
  className?: string;
}

export const PerformanceChart = ({ 
  data, 
  title = "Portfolio Performance",
  className = "" 
}: PerformanceChartProps) => {
  const [dateRange, setDateRange] = useState<"7D" | "30D" | "90D" | "1Y">("30D");

  // Generate or filter data based on selected date range
  const chartData = useMemo(() => {
    // Map date range to number of days
    const daysMap = { "7D": 7, "30D": 30, "90D": 90, "1Y": 365 };
    const days = daysMap[dateRange];
    
    if (data && data.length > 0) {
      // If data is provided, filter or interpolate to match selected range
      if (data.length >= days) {
        // Take last N days
        return data.slice(-days);
      } else {
        // If less data than needed, return all available
        return data;
      }
    }
    
    // Generate sample data if none provided
    const baseValue = 10000;
    const result = [];
    
    for (let i = 0; i < days; i++) {
      const date = new Date();
      date.setDate(date.getDate() - (days - i));
      
      // Adjust trend based on time period
      const trendMultiplier = dateRange === "1Y" ? 15 : dateRange === "90D" ? 30 : 50;
      const trend = i * trendMultiplier;
      const volatility = Math.sin(i / 3) * 500 + Math.random() * 400;
      const portfolioValue = baseValue + trend + volatility;
      
      // Simulate benchmark (market average) with less volatility
      const benchmarkValue = baseValue + (i * (trendMultiplier * 0.8)) + (Math.sin(i / 4) * 300);
      
      // Format date based on range
      const dateFormat: Intl.DateTimeFormatOptions = dateRange === "1Y" 
        ? { month: 'short', day: 'numeric' }
        : dateRange === "90D"
        ? { month: 'short', day: 'numeric' }
        : { month: 'short', day: 'numeric' };
      
      result.push({
        date: date.toLocaleDateString('en-US', dateFormat),
        value: Math.round(portfolioValue),
        benchmark: Math.round(benchmarkValue)
      });
    }
    
    return result;
  }, [data, dateRange]);

  const stats = useMemo(() => {
    if (!chartData || chartData.length === 0) return null;
    
    const firstValue = chartData[0].value;
    const lastValue = chartData[chartData.length - 1].value;
    const change = lastValue - firstValue;
    const changePercent = (change / firstValue) * 100;
    
    const firstBenchmark = chartData[0].benchmark || firstValue;
    const lastBenchmark = chartData[chartData.length - 1].benchmark || lastValue;
    const benchmarkChange = lastBenchmark - firstBenchmark;
    const benchmarkPercent = (benchmarkChange / firstBenchmark) * 100;
    
    return {
      change,
      changePercent,
      benchmarkPercent,
      outperformance: changePercent - benchmarkPercent
    };
  }, [chartData]);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const portfolioValue = payload[0].value;
      const benchmarkValue = payload[1]?.value || portfolioValue;
      const diff = portfolioValue - benchmarkValue;
      const diffPercent = ((diff / benchmarkValue) * 100).toFixed(2);
      
      return (
        <div className="glass-card p-3 border border-primary/30">
          <p className="text-sm text-white/90 mb-2">{payload[0].payload.date}</p>
          <p className="text-sm font-bold text-primary">
            Portfolio: ${portfolioValue.toLocaleString()}
          </p>
          {payload[1] && (
            <>
              <p className="text-sm font-bold text-white/60">
                Market: ${benchmarkValue.toLocaleString()}
              </p>
              <p className={`text-xs mt-1 ${diff >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {diff >= 0 ? '+' : ''}{diffPercent}% vs market
              </p>
            </>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <Card className={`glass-card hover-glow p-4 ${className} performance-chart-container`}>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-3 gap-3">
        <h3 className="text-base font-bold gradient-text-purple">{title}</h3>
        
        <div className="flex items-center gap-4">
          <Tabs 
            value={dateRange} 
            onValueChange={(value) => setDateRange(value as "7D" | "30D" | "90D" | "1Y")}
            className="w-auto"
          >
            <TabsList className="h-8">
              <TabsTrigger value="7D" className="text-xs px-3">7D</TabsTrigger>
              <TabsTrigger value="30D" className="text-xs px-3">30D</TabsTrigger>
              <TabsTrigger value="90D" className="text-xs px-3">90D</TabsTrigger>
              <TabsTrigger value="1Y" className="text-xs px-3">1Y</TabsTrigger>
            </TabsList>
          </Tabs>

          {stats && (
            <div className="text-right">
              <div className={`text-lg font-bold flex items-center gap-1 ${stats.change >= 0 ? 'text-primary' : 'text-destructive'}`}>
                {stats.change >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                {stats.change >= 0 ? '+$' : '-$'}{Math.abs(stats.change).toFixed(2)}
              </div>
              <div className={`text-xs ${stats.changePercent >= 0 ? 'text-primary/80' : 'text-destructive/80'}`}>
                ({stats.changePercent >= 0 ? '+' : ''}{stats.changePercent.toFixed(2)}%)
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="h-[250px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData}>
            <defs>
              <linearGradient id="portfolioGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(268, 85%, 58%)" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="hsl(268, 85%, 58%)" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="benchmarkGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(194, 100%, 60%)" stopOpacity={0.2}/>
                <stop offset="95%" stopColor="hsl(194, 100%, 60%)" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <XAxis 
              dataKey="date" 
              stroke="rgba(255, 255, 255, 0.4)"
              style={{ fontSize: '11px' }}
              tick={{ fill: 'rgba(255, 255, 255, 0.6)' }}
            />
            <YAxis 
              stroke="rgba(255, 255, 255, 0.4)"
              style={{ fontSize: '11px' }}
              tick={{ fill: 'rgba(255, 255, 255, 0.6)' }}
              tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
            />
            <Tooltip content={<CustomTooltip />} />
            <ReferenceLine 
              y={chartData[0]?.value} 
              stroke="rgba(255, 255, 255, 0.2)" 
              strokeDasharray="3 3"
              label={{ value: 'Start', fill: 'rgba(255, 255, 255, 0.5)', fontSize: 10 }}
            />
            <Line
              type="monotone"
              dataKey="benchmark"
              stroke="hsl(194, 100%, 60%)"
              strokeWidth={2}
              dot={false}
              fill="url(#benchmarkGradient)"
              name="Market Benchmark"
            />
            <Line
              type="monotone"
              dataKey="value"
              stroke="hsl(268, 85%, 58%)"
              strokeWidth={3}
              dot={false}
              fill="url(#portfolioGradient)"
              name="Your Portfolio"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="flex items-center justify-center gap-6 mt-3 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-neon-purple"></div>
          <span className="text-white/80">Your Portfolio</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-primary"></div>
          <span className="text-white/80">Market Benchmark</span>
        </div>
      </div>
    </Card>
  );
};
