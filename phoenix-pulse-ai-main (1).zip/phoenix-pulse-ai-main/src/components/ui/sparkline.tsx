import { Line, LineChart, ResponsiveContainer } from 'recharts';
import { motion } from 'framer-motion';

interface SparklineProps {
  data: number[];
  color?: string;
  height?: number;
  width?: number;
  showGlow?: boolean;
}

export const Sparkline = ({
  data,
  color = 'hsl(var(--neon-purple))',
  height = 40,
  width = 80,
  showGlow = true
}: SparklineProps) => {
  const chartData = data.map((value, index) => ({
    value,
    index
  }));

  const isPositive = data[data.length - 1] >= data[0];
  const strokeColor = isPositive ? 'hsl(142, 76%, 36%)' : 'hsl(0, 84%, 60%)';

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      style={{
        filter: showGlow ? `drop-shadow(0 0 4px ${strokeColor})` : 'none'
      }}
    >
      <LineChart width={width} height={height} data={chartData}>
        <Line
          type="monotone"
          dataKey="value"
          stroke={strokeColor}
          strokeWidth={1.5}
          dot={false}
          animationDuration={300}
          animationEasing="ease-out"
        />
      </LineChart>
    </motion.div>
  );
};
