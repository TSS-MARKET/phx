import { motion, AnimatePresence } from "framer-motion";
import { X, TrendingUp, TrendingDown, Bot, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

export interface NotificationToast {
  id: string;
  type: "trade" | "price" | "bot" | "alert";
  title: string;
  message: string;
  timestamp: number;
}

interface NotificationSystemProps {
  notifications: NotificationToast[];
  onDismiss: (id: string) => void;
}

const getNotificationIcon = (type: NotificationToast["type"]) => {
  switch (type) {
    case "trade":
      return <TrendingUp className="w-5 h-5" />;
    case "price":
      return <TrendingDown className="w-5 h-5" />;
    case "bot":
      return <Bot className="w-5 h-5" />;
    case "alert":
      return <AlertCircle className="w-5 h-5" />;
  }
};

const getNotificationColor = (type: NotificationToast["type"]) => {
  switch (type) {
    case "trade":
      return "from-electric-teal/20 to-neon-aqua/20 border-electric-teal/50";
    case "price":
      return "from-cyber-purple/20 to-electric-teal/20 border-cyber-purple/50";
    case "bot":
      return "from-neon-aqua/20 to-electric-teal/20 border-neon-aqua/50";
    case "alert":
      return "from-orange-500/20 to-red-500/20 border-orange-500/50";
  }
};

export const NotificationSystem = ({ notifications, onDismiss }: NotificationSystemProps) => {
  return (
    <div className="fixed top-20 right-6 z-50 space-y-3 max-w-md">
      <AnimatePresence>
        {notifications.map((notification, index) => (
          <motion.div
            key={notification.id}
            initial={{ x: 400, opacity: 0, scale: 0.8 }}
            animate={{ x: 0, opacity: 1, scale: 1 }}
            exit={{ x: 400, opacity: 0, scale: 0.8 }}
            transition={{
              type: "spring",
              stiffness: 300,
              damping: 25,
              delay: index * 0.1
            }}
            className={cn(
              "glass-card p-4 border-2 rounded-xl backdrop-blur-xl",
              "shadow-[0_0_30px_rgba(0,255,255,0.3)]",
              "bg-gradient-to-br",
              getNotificationColor(notification.type)
            )}
          >
            <div className="flex items-start gap-3">
              <div className={cn(
                "p-2 rounded-lg bg-gradient-to-br",
                notification.type === "trade" && "from-electric-teal to-neon-aqua",
                notification.type === "price" && "from-cyber-purple to-electric-teal",
                notification.type === "bot" && "from-neon-aqua to-electric-teal",
                notification.type === "alert" && "from-orange-500 to-red-500"
              )}>
                {getNotificationIcon(notification.type)}
              </div>
              
              <div className="flex-1 min-w-0">
                <h4 className="font-orbitron font-bold text-sm text-electric-teal mb-1">
                  {notification.title}
                </h4>
                <p className="text-xs text-foreground/80 leading-relaxed">
                  {notification.message}
                </p>
                <span className="text-[10px] text-muted-foreground mt-1 block">
                  {new Date(notification.timestamp).toLocaleTimeString()}
                </span>
              </div>

              <button
                onClick={() => onDismiss(notification.id)}
                className="p-1 hover:bg-background/50 rounded transition-colors flex-shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};
