import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface LoadingSkeletonProps {
  className?: string;
  variant?: 'card' | 'text' | 'circle' | 'chart';
}

export const LoadingSkeleton = ({ className, variant = 'card' }: LoadingSkeletonProps) => {
  const baseClasses = "relative overflow-hidden rounded-lg";
  
  const variantClasses = {
    card: "h-32 w-full",
    text: "h-4 w-3/4",
    circle: "h-12 w-12 rounded-full",
    chart: "h-48 w-full"
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, rotateX: 10 }}
      animate={{ opacity: 1, y: 0, rotateX: 0 }}
      transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
      className={cn(baseClasses, variantClasses[variant], className)}
      style={{ perspective: "1000px", transformStyle: "preserve-3d" }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-muted via-primary/10 to-muted animate-shimmer" />
      <motion.div
        className="absolute inset-0"
        animate={{
          boxShadow: [
            '0 0 20px rgba(79, 209, 197, 0.2)',
            '0 0 40px rgba(79, 209, 197, 0.4)',
            '0 0 20px rgba(79, 209, 197, 0.2)'
          ]
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
    </motion.div>
  );
};

export const ChartSkeleton = () => (
  <motion.div 
    className="space-y-4 p-4"
    layout
    initial={{ opacity: 0, scale: 0.95 }}
    animate={{ opacity: 1, scale: 1 }}
    transition={{ duration: 0.4 }}
  >
    <LoadingSkeleton variant="text" className="w-1/4" />
    <LoadingSkeleton variant="chart" />
    <div className="flex gap-4">
      <LoadingSkeleton variant="text" className="w-20" />
      <LoadingSkeleton variant="text" className="w-20" />
      <LoadingSkeleton variant="text" className="w-20" />
    </div>
  </motion.div>
);

export const CardSkeleton = () => (
  <motion.div 
    className="space-y-4 p-4"
    layout
    initial={{ opacity: 0, scale: 0.95 }}
    animate={{ opacity: 1, scale: 1 }}
    transition={{ duration: 0.4 }}
  >
    <div className="flex items-center gap-4">
      <LoadingSkeleton variant="circle" />
      <div className="flex-1 space-y-2">
        <LoadingSkeleton variant="text" className="w-1/2" />
        <LoadingSkeleton variant="text" className="w-3/4" />
      </div>
    </div>
    <LoadingSkeleton variant="card" />
  </motion.div>
);