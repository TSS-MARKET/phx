import { motion } from "framer-motion";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface HeatmapCell {
  token: string;
  performance: number; // -100 to 100
  volume: string;
  price: string;
}

interface PerformanceHeatmapProps {
  data: HeatmapCell[];
}

const getHeatmapColor = (performance: number) => {
  if (performance > 20) return "from-neon-aqua/40 to-neon-aqua/60 border-neon-aqua";
  if (performance > 10) return "from-electric-teal/40 to-electric-teal/60 border-electric-teal";
  if (performance > 0) return "from-electric-teal/20 to-electric-teal/40 border-electric-teal/50";
  if (performance > -10) return "from-cyber-purple/20 to-cyber-purple/40 border-cyber-purple/50";
  if (performance > -20) return "from-red-500/40 to-red-500/60 border-red-500";
  return "from-red-600/40 to-red-600/60 border-red-600";
};

const getPerformanceLabel = (performance: number) => {
  if (performance > 20) return "🔥 Hot";
  if (performance > 10) return "📈 Strong";
  if (performance > 0) return "✅ Up";
  if (performance > -10) return "📉 Down";
  if (performance > -20) return "❄️ Cool";
  return "💀 Cold";
};

export const PerformanceHeatmap = ({ data }: PerformanceHeatmapProps) => {
  const [hoveredCell, setHoveredCell] = useState<string | null>(null);

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
      {data.map((cell, index) => (
        <motion.div
          key={cell.token}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: index * 0.05 }}
          onMouseEnter={() => setHoveredCell(cell.token)}
          onMouseLeave={() => setHoveredCell(null)}
          className={cn(
            "relative p-4 rounded-xl border-2 glass-card cursor-pointer",
            "bg-gradient-to-br transition-all duration-300",
            getHeatmapColor(cell.performance),
            hoveredCell === cell.token && "scale-105 shadow-[0_0_30px_rgba(0,255,255,0.4)]"
          )}
        >
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-orbitron font-bold text-sm text-electric-teal">
                {cell.token}
              </span>
              <span className="text-xs text-muted-foreground">
                {getPerformanceLabel(cell.performance)}
              </span>
            </div>

            <div className="flex items-baseline gap-1">
              <span className={cn(
                "text-2xl font-bold font-orbitron",
                cell.performance > 0 ? "text-neon-aqua" : "text-red-500"
              )}>
                {cell.performance > 0 ? "+" : ""}{cell.performance.toFixed(1)}%
              </span>
            </div>

            <div className="space-y-1 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Price:</span>
                <span className="text-foreground font-semibold">{cell.price}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Volume:</span>
                <span className="text-foreground font-semibold">{cell.volume}</span>
              </div>
            </div>
          </div>

          {/* Animated border glow on hover */}
          {hoveredCell === cell.token && (
            <motion.div
              className="absolute inset-0 rounded-xl border-2 border-electric-teal"
              initial={{ opacity: 0 }}
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          )}
        </motion.div>
      ))}
    </div>
  );
};
