import { Area, AreaChart, ResponsiveContainer, Tooltip } from 'recharts';
import { motion } from 'framer-motion';

interface PremiumChartProps {
  data: Array<{ value: number; label?: string }>;
  color?: string;
  gradientFrom?: string;
  gradientTo?: string;
  height?: number;
  showGlow?: boolean;
}

export const PremiumChart = ({
  data,
  color = 'hsl(268, 85%, 58%)',
  gradientFrom = 'rgba(168, 85, 247, 0.4)',
  gradientTo = 'rgba(168, 85, 247, 0.01)',
  height = 100,
  showGlow = true
}: PremiumChartProps) => {
  const chartData = data.map((item, i) => ({
    value: item.value,
    index: i,
    label: item.label
  }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="relative"
      style={{
        filter: showGlow ? `drop-shadow(0 0 8px ${color})` : 'none'
      }}
    >
      <ResponsiveContainer width="100%" height={height}>
        <AreaChart data={chartData}>
          <defs>
            <linearGradient id={`gradient-${color}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={gradientFrom} stopOpacity={0.8}/>
              <stop offset="95%" stopColor={gradientTo} stopOpacity={0.1}/>
            </linearGradient>
            <filter id={`glow-${color}`}>
              <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                return (
                  <div className="bg-card/95 backdrop-blur-xl border border-primary/30 p-2 rounded-lg shadow-xl">
                    <p className="text-xs text-primary font-bold">
                      ${payload[0].value}
                    </p>
                  </div>
                );
              }
              return null;
            }}
          />
          <Area
            type="monotone"
            dataKey="value"
            stroke={color}
            strokeWidth={2}
            fill={`url(#gradient-${color})`}
            filter={showGlow ? `url(#glow-${color})` : undefined}
            animationDuration={1500}
            animationEasing="ease-in-out"
          />
        </AreaChart>
      </ResponsiveContainer>
    </motion.div>
  );
};