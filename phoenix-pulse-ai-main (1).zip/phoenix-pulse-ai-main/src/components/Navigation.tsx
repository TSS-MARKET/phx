import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X, LogOut } from "lucide-react";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { User } from "@supabase/supabase-js";
import { useToast } from "@/hooks/use-toast";
import phoenixLogo from "@/assets/phx-ai-logo.png";

interface NavigationProps {
  user: User | null;
}

const Navigation = ({ user }: NavigationProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();

  const navItems = [
    { name: "Home", path: "/" },
    { name: "Dashboard", path: "/dashboard" },
    { name: "DApp", path: "/dapp" },
    { name: "Features", path: "/features" },
    { name: "Token", path: "/token" },
    { name: "Holdings", path: "/holdings" },
    { name: "About", path: "/about" },
    { name: "Contact", path: "/contact" },
  ];

  const handleSignOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      
      toast({
        title: "Signed out",
        description: "You have been successfully signed out.",
      });
      navigate("/");
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="fixed top-0 w-full z-50 bg-background/30 backdrop-blur-2xl border-b border-primary/20 shadow-[0_8px_32px_rgba(6,182,212,0.1)]"
      style={{
        backdropFilter: 'blur(20px) saturate(180%)',
        WebkitBackdropFilter: 'blur(20px) saturate(180%)',
      }}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center gap-3 group">
            <motion.div
              className="flex items-center gap-3"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.2 }}
            >
              <div className="relative">
                <img 
                  src={phoenixLogo} 
                  alt="Phoenix AI" 
                  className="w-12 h-12 rounded-full border-2 border-primary shadow-[0_0_20px_rgba(6,182,212,0.6)] relative z-10 object-cover"
                />
                <motion.div 
                  className="absolute inset-0 bg-primary/30 rounded-full blur-xl"
                  animate={{
                    scale: [1, 1.2, 1],
                    opacity: [0.3, 0.6, 0.3],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />
              </div>
              <span className="text-2xl font-black glow-cyan font-orbitron">
                PHOENIX AI
              </span>
            </motion.div>
          </Link>

          <div className="hidden md:flex items-center gap-6">
            {navItems.map((item, idx) => (
              <motion.div
                key={item.path}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
              >
                <Link
                  to={item.path}
                  className={`text-sm font-bold transition-all hover:text-primary relative group ${
                    location.pathname === item.path ? "text-primary" : "text-foreground/70"
                  }`}
                >
                  {item.name}
                  <span className={`absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-secondary transition-all duration-300 group-hover:w-full ${
                    location.pathname === item.path ? "w-full" : ""
                  }`}></span>
                </Link>
              </motion.div>
            ))}
            
            {user && (
              <Button
                variant="ghost"
                onClick={handleSignOut}
                className="text-foreground/80 hover:text-foreground"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </Button>
            )}
            
            <div className="wallet-adapter-button-trigger [&>button]:!bg-gradient-to-r [&>button]:!from-cyan-500 [&>button]:!via-blue-500 [&>button]:!to-purple-500 [&>button]:!animate-gradient-shift [&>button]:!bg-[length:200%_200%] [&>button]:!text-white [&>button]:!font-bold [&>button]:!border-0 [&>button]:!shadow-[0_0_20px_rgba(6,182,212,0.5)] [&>button]:hover:!shadow-[0_0_30px_rgba(6,182,212,0.8)] [&>button]:hover:!scale-105 [&>button]:!transition-all [&>button]:!h-9 [&>button]:!rounded-xl [&>button]:!px-3 [&>button]:!text-xs">
              <WalletMultiButton>Connect Wallet</WalletMultiButton>
            </div>
          </div>

          <button className="md:hidden text-foreground" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isOpen && (
          <div className="md:hidden py-4 space-y-4">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setIsOpen(false)}
                className={`block text-sm font-bold transition-all hover:text-primary ${
                  location.pathname === item.path ? "text-primary glow-cyan" : "text-foreground/70"
                }`}
              >
                {item.name}
              </Link>
            ))}
            
            {user && (
              <Button
                variant="ghost"
                onClick={() => {
                  handleSignOut();
                  setIsOpen(false);
                }}
                className="w-full justify-start text-foreground/80 hover:text-foreground"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </Button>
            )}
            
            <div className="[&>button]:!bg-gradient-to-r [&>button]:!from-cyan-500 [&>button]:!via-blue-500 [&>button]:!to-purple-500 [&>button]:!animate-gradient-shift [&>button]:!bg-[length:200%_200%] [&>button]:!text-white [&>button]:!font-bold [&>button]:!border-0 [&>button]:!shadow-[0_0_20px_rgba(6,182,212,0.5)] [&>button]:!transition-all [&>button]:!w-full [&>button]:!h-9 [&>button]:!rounded-xl [&>button]:!text-xs">
              <WalletMultiButton>Connect Wallet</WalletMultiButton>
            </div>
          </div>
        )}
      </div>
    </motion.nav>
  );
};

export default Navigation;
