import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Star, Trash2, Plus, TrendingUp, TrendingDown } from "lucide-react";
import { useWatchlist } from "@/hooks/useWatchlist";
import { CoinSearchDialog } from "./CoinSearchDialog";
import { useCryptoPrices } from "@/hooks/useCryptoPrices";
import { useCoinLogos } from "@/hooks/useCoinLogos";
import { motion, AnimatePresence } from "framer-motion";
import { AnimatedCounter } from "@/components/ui/animated-counter";

export const Watchlist = () => {
  const { watchlist, addToWatchlist, removeFromWatchlist } = useWatchlist();
  const [showSearchDialog, setShowSearchDialog] = useState(false);
  const [sortBy, setSortBy] = useState<"name" | "price" | "change">("name");

  const coinIds = watchlist.map((item) => item.coinId);
  const { data: priceData, isLoading } = useCryptoPrices(coinIds);
  const { data: logoData } = useCoinLogos(coinIds);

  const handleCoinSelect = (coin: any) => {
    addToWatchlist({
      symbol: coin.symbol.toUpperCase(),
      name: coin.name,
      coinId: coin.id,
    });
    setShowSearchDialog(false);
  };

  const sortedWatchlist = [...watchlist].sort((a, b) => {
    if (sortBy === "name") {
      return a.name.localeCompare(b.name);
    } else if (sortBy === "price") {
      const priceA = priceData?.[a.coinId]?.usd || 0;
      const priceB = priceData?.[b.coinId]?.usd || 0;
      return priceB - priceA;
    }
    return 0;
  });

  return (
    <>
      <Card className="p-6 bg-secondary/50 backdrop-blur border-border/50">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Star className="w-6 h-6 text-primary fill-primary" />
            <h3 className="text-xl font-bold text-foreground">Watchlist</h3>
          </div>
          <div className="flex gap-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-3 py-2 bg-background border border-border rounded-lg text-sm text-foreground"
            >
              <option value="name">Sort by Name</option>
              <option value="price">Sort by Price</option>
            </select>
            <Button
              onClick={() => setShowSearchDialog(true)}
              className="bg-primary hover:bg-primary/90"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Coin
            </Button>
          </div>
        </div>

        <div className="space-y-3">
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">
              Loading watchlist...
            </div>
          ) : watchlist.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              Your watchlist is empty. Add some coins to track!
            </div>
          ) : (
            <AnimatePresence>
              {sortedWatchlist.map((item) => {
                const price = priceData?.[item.coinId]?.usd || 0;
                const logo = logoData?.[item.coinId];
                const change24h = 0; // We can add this later if needed

                return (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -100 }}
                    whileHover={{ 
                      scale: 1.02,
                      y: -2,
                      boxShadow: "0 8px 30px rgba(var(--primary-rgb), 0.3)",
                    }}
                    className="p-4 bg-background/50 rounded-lg border border-border hover:border-primary/50 transition-all"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        {logo && (
                          <img
                            src={logo}
                            alt={item.symbol}
                            className="w-10 h-10 rounded-full"
                          />
                        )}
                        <div>
                          <p className="font-bold text-foreground">{item.symbol}</p>
                          <p className="text-sm text-muted-foreground">{item.name}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <p className="font-semibold text-foreground">
                            $<AnimatedCounter value={price} decimals={price < 1 ? 6 : 2} />
                          </p>
                          {change24h !== 0 && (
                            <div
                              className={`flex items-center gap-1 text-sm ${
                                change24h >= 0 ? "text-success" : "text-destructive"
                              }`}
                            >
                              {change24h >= 0 ? (
                                <TrendingUp className="w-4 h-4" />
                              ) : (
                                <TrendingDown className="w-4 h-4" />
                              )}
                              <span>{Math.abs(change24h).toFixed(2)}%</span>
                            </div>
                          )}
                        </div>

                        <Button
                          onClick={() => removeFromWatchlist(item.id)}
                          variant="ghost"
                          size="sm"
                          className="text-destructive hover:text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          )}
        </div>
      </Card>

      <CoinSearchDialog
        isOpen={showSearchDialog}
        onClose={() => setShowSearchDialog(false)}
        onSelect={handleCoinSelect}
      />
    </>
  );
};
