import { ReactNode } from "react";
import { use3DTilt } from "@/hooks/use3DTilt";
import { motion, AnimatePresence } from "framer-motion";

interface Tilt3DCardProps {
  children: ReactNode;
  className?: string;
  maxTilt?: number;
  scale?: number;
}

export const Tilt3DCard = ({ 
  children, 
  className = "", 
  maxTilt = 10,
  scale = 1.03,
}: Tilt3DCardProps) => {
  const { ref, isHovered } = use3DTilt({ 
    maxTilt, 
    scale,
    speed: 500,
    perspective: 1200,
  });

  return (
    <div
      ref={ref}
      className={`relative ${className}`}
      style={{
        transformStyle: "preserve-3d",
      }}
    >
      <AnimatePresence>
        {isHovered && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 rounded-xl pointer-events-none"
            style={{
              background: 'radial-gradient(circle at var(--mouse-x, 50%) var(--mouse-y, 50%), rgba(6,182,212,0.15), transparent 60%)',
              filter: 'blur(20px)',
            }}
          />
        )}
      </AnimatePresence>
      {children}
    </div>
  );
};
