import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CreditCard, Wallet } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  tier: 'pro' | 'elite';
}

const TIER_PRICES = {
  pro: { usd: 9.99, sol: 0.05 },
  elite: { usd: 49.99, sol: 0.25 },
};

export const PaymentModal = ({ isOpen, onClose, tier }: PaymentModalProps) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleStripePayment = async () => {
    setIsProcessing(true);
    
    try {
      // TODO: Implement Stripe checkout
      // For now, show demo message
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: "Payment System",
        description: "Stripe integration coming soon! This is a demo.",
      });
      
      onClose();
    } catch (error) {
      toast({
        title: "Payment Failed",
        description: "Failed to process payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSolanaPayment = async () => {
    setIsProcessing(true);
    
    try {
      // TODO: Implement Solana Pay
      // For now, show demo message
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: "Payment System",
        description: "Solana Pay integration coming soon! This is a demo.",
      });
      
      onClose();
    } catch (error) {
      toast({
        title: "Payment Failed",
        description: "Failed to process payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md bg-background/95 backdrop-blur border-primary/30">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-foreground">
            Upgrade to {tier === 'pro' ? 'Pro' : 'Elite'}
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="stripe" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="stripe" className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              Card
            </TabsTrigger>
            <TabsTrigger value="solana" className="flex items-center gap-2">
              <Wallet className="w-4 h-4" />
              Solana
            </TabsTrigger>
          </TabsList>

          <TabsContent value="stripe" className="space-y-4">
            <div className="p-6 rounded-xl bg-primary/5 border border-primary/20 text-center">
              <div className="text-4xl font-bold bg-gradient-to-r from-primary to-blue-500 bg-clip-text text-transparent mb-2">
                ${TIER_PRICES[tier].usd}
              </div>
              <p className="text-sm text-muted-foreground">per month</p>
            </div>

            <Button 
              onClick={handleStripePayment}
              disabled={isProcessing}
              className="w-full bg-gradient-to-r from-primary to-blue-500 hover:from-primary/90 hover:to-blue-500/90 text-white font-bold py-6"
            >
              {isProcessing ? "Processing..." : "Pay with Card"}
            </Button>

            <p className="text-xs text-center text-muted-foreground">
              Secure payment powered by Stripe
            </p>
          </TabsContent>

          <TabsContent value="solana" className="space-y-4">
            <div className="p-6 rounded-xl bg-primary/5 border border-primary/20 text-center">
              <div className="text-4xl font-bold bg-gradient-to-r from-primary to-blue-500 bg-clip-text text-transparent mb-2">
                {TIER_PRICES[tier].sol} SOL
              </div>
              <p className="text-sm text-muted-foreground">per month</p>
            </div>

            <Button 
              onClick={handleSolanaPayment}
              disabled={isProcessing}
              className="w-full bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-white font-bold py-6"
            >
              {isProcessing ? "Processing..." : "Pay with Solana"}
            </Button>

            <p className="text-xs text-center text-muted-foreground">
              Connect your Phantom or Solflare wallet
            </p>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};