import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bot, Crown } from "lucide-react";
import { useSubscription } from "@/hooks/useSubscription";
import { useState } from "react";
import { PaymentModal } from "./PaymentModal";
import { TradingBotComplete } from "./TradingBotComplete";

export const TradingBot = () => {
  const { canAccessFeature } = useSubscription();
  const [showUpgrade, setShowUpgrade] = useState(false);
  const hasAccess = canAccessFeature('trading_bot');

  if (!hasAccess) {
    return (
      <>
        <Card className="p-8 text-center border-2 border-yellow-500/30 bg-yellow-500/5">
          <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
          <h3 className="text-2xl font-bold mb-2">AI Trading Bot - Elite Feature</h3>
          <p className="text-muted-foreground mb-6">Unlock AI-powered trading signals and automated execution.</p>
          <Button onClick={() => setShowUpgrade(true)} className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold">
            Upgrade to Elite
          </Button>
        </Card>
        <PaymentModal isOpen={showUpgrade} onClose={() => setShowUpgrade(false)} tier="elite" />
      </>
    );
  }

  return <TradingBotComplete />;
};