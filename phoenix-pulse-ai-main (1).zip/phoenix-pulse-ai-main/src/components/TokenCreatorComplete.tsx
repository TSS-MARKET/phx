import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Coins, Crown, Sparkles, Droplets, CheckCircle } from "lucide-react";
import { useSubscription } from "@/hooks/useSubscription";
import { PaymentModal } from "./PaymentModal";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@solana/wallet-adapter-react";
import { supabase } from "@/integrations/supabase/client";

export const TokenCreatorComplete = () => {
  const { canAccessFeature } = useSubscription();
  const { toast } = useToast();
  const wallet = useWallet();
  
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [step, setStep] = useState<'form' | 'deploying' | 'success'>('form');
  const [deployedToken, setDeployedToken] = useState<any>(null);
  
  // Form state
  const [tokenName, setTokenName] = useState("");
  const [tokenSymbol, setTokenSymbol] = useState("");
  const [tokenSupply, setTokenSupply] = useState("");
  const [tokenDecimals, setTokenDecimals] = useState("9");
  const [tokenDescription, setTokenDescription] = useState("");
  const [aiScore, setAiScore] = useState(0);

  const hasAccess = canAccessFeature('token_creator');

  if (!hasAccess) {
    return (
      <>
        <Card className="p-8 text-center border-2 border-yellow-500/30 bg-yellow-500/5 backdrop-blur">
          <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-foreground mb-2">
            Token Creator - Elite Feature
          </h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Launch Solana tokens directly from Phoenix AI with AI launch scoring and liquidity tools.
          </p>
          <Button 
            onClick={() => setShowUpgrade(true)}
            className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-300 hover:to-orange-400 text-white font-bold"
          >
            Upgrade to Elite
          </Button>
        </Card>
        <PaymentModal 
          isOpen={showUpgrade}
          onClose={() => setShowUpgrade(false)}
          tier="elite"
        />
      </>
    );
  }

  const calculateAIScore = () => {
    let score = 50; // Base score
    
    // Name quality (max 15 points)
    if (tokenName.length >= 3 && tokenName.length <= 20) score += 10;
    if (/^[A-Za-z0-9\s]+$/.test(tokenName)) score += 5;
    
    // Symbol quality (max 10 points)
    if (tokenSymbol.length >= 3 && tokenSymbol.length <= 5) score += 10;
    
    // Supply strategy (max 15 points)
    const supply = parseInt(tokenSupply);
    if (supply >= 1000000 && supply <= 1000000000) score += 15;
    else if (supply >= 100000) score += 10;
    
    // Description (max 10 points)
    if (tokenDescription.length >= 50) score += 10;
    else if (tokenDescription.length >= 20) score += 5;
    
    setAiScore(Math.min(100, score));
  };

  const handleDeployToken = async () => {
    if (!wallet.connected || !wallet.publicKey) {
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet to deploy tokens.",
        variant: "destructive",
      });
      return;
    }

    if (!tokenName || !tokenSymbol || !tokenSupply) {
      toast({
        title: "Missing Fields",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    calculateAIScore();
    setStep('deploying');

    // Simulate deployment (replace with actual Solana token deployment)
    setTimeout(async () => {
      const mockTokenAddress = `${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`;
      
      const tokenData = {
        user_id: (await supabase.auth.getUser()).data.user?.id,
        token_name: tokenName,
        token_symbol: tokenSymbol,
        token_supply: parseInt(tokenSupply),
        token_decimals: parseInt(tokenDecimals),
        token_address: mockTokenAddress,
        ai_launch_score: aiScore,
        phoenix_approved: aiScore >= 80,
      };

      // Save to database
      const { error } = await supabase
        .from('user_tokens')
        .insert(tokenData);

      if (error) {
        toast({
          title: "Database Error",
          description: "Failed to save token data.",
          variant: "destructive",
        });
        setStep('form');
        return;
      }

      setDeployedToken(tokenData);
      setStep('success');
      
      toast({
        title: "Token Deployment",
        description: "Demo deployment complete! Real Solana deployment coming soon.",
      });
    }, 3000);
  };

  const handleAddLiquidity = () => {
    toast({
      title: "Liquidity Launcher",
      description: "Raydium/Jupiter liquidity integration coming soon!",
    });
  };

  if (step === 'deploying') {
    return (
      <Card className="p-12 text-center border-2 border-primary/30 bg-background/40 backdrop-blur">
        <Sparkles className="w-16 h-16 text-primary mx-auto mb-4 animate-pulse" />
        <h3 className="text-2xl font-bold text-foreground mb-2">Deploying Your Token...</h3>
        <p className="text-muted-foreground">
          Phoenix AI is analyzing and deploying your token to Solana blockchain.
        </p>
      </Card>
    );
  }

  if (step === 'success' && deployedToken) {
    return (
      <div className="space-y-6 animate-fade-in">
        <Card className={`p-6 border-2 ${deployedToken.phoenix_approved ? 'border-yellow-500/30 bg-yellow-500/5' : 'border-primary/30 bg-background/40'} backdrop-blur`}>
          <div className="text-center mb-6">
            <CheckCircle className={`w-16 h-16 ${deployedToken.phoenix_approved ? 'text-yellow-400' : 'text-green-400'} mx-auto mb-4`} />
            <h3 className="text-2xl font-bold text-foreground mb-2">
              Token Deployed Successfully!
            </h3>
            {deployedToken.phoenix_approved && (
              <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-0 px-4 py-2">
                🔥 PHOENIX APPROVED PROJECT
              </Badge>
            )}
          </div>

          <div className="space-y-4 mb-6">
            <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
              <div className="text-xs text-muted-foreground mb-1">Token Name</div>
              <div className="text-lg font-bold text-foreground">{deployedToken.token_name}</div>
            </div>
            <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
              <div className="text-xs text-muted-foreground mb-1">Symbol</div>
              <div className="text-lg font-bold text-foreground">{deployedToken.token_symbol}</div>
            </div>
            <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
              <div className="text-xs text-muted-foreground mb-1">Contract Address</div>
              <div className="text-sm font-mono text-foreground break-all">{deployedToken.token_address}</div>
            </div>
            <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
              <div className="text-xs text-muted-foreground mb-1">AI Launch Score</div>
              <div className="text-3xl font-bold bg-gradient-to-r from-primary to-blue-500 bg-clip-text text-transparent">
                {deployedToken.ai_launch_score}/100
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <Button
              onClick={handleAddLiquidity}
              className="bg-gradient-to-r from-blue-400 to-cyan-500 hover:from-blue-300 hover:to-cyan-400 text-white font-bold"
            >
              <Droplets className="w-4 h-4 mr-2" />
              Add Liquidity
            </Button>
            <Button
              onClick={() => {
                setStep('form');
                setTokenName("");
                setTokenSymbol("");
                setTokenSupply("");
                setTokenDescription("");
              }}
              variant="outline"
              className="border-primary/30"
            >
              Create Another Token
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 mb-4">
          <Coins className="w-5 h-5 text-purple-400" />
          <span className="text-sm font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            TOKEN CREATOR
          </span>
        </div>
        <h2 className="text-3xl font-bold text-foreground mb-2">
          Launch Your Solana Token
        </h2>
        <p className="text-muted-foreground">
          AI-powered token deployment with launch scoring
        </p>
      </div>

      <Card className="p-6 border-2 border-primary/30 bg-background/40 backdrop-blur">
        <div className="space-y-6">
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">
              Token Name *
            </label>
            <Input
              value={tokenName}
              onChange={(e) => setTokenName(e.target.value)}
              placeholder="My Awesome Token"
              className="bg-background border-primary/20"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">
              Token Symbol *
            </label>
            <Input
              value={tokenSymbol}
              onChange={(e) => setTokenSymbol(e.target.value.toUpperCase())}
              placeholder="MAT"
              maxLength={5}
              className="bg-background border-primary/20"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">
                Total Supply *
              </label>
              <Input
                type="number"
                value={tokenSupply}
                onChange={(e) => setTokenSupply(e.target.value)}
                placeholder="1000000"
                className="bg-background border-primary/20"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">
                Decimals
              </label>
              <Input
                type="number"
                value={tokenDecimals}
                onChange={(e) => setTokenDecimals(e.target.value)}
                placeholder="9"
                min="0"
                max="9"
                className="bg-background border-primary/20"
              />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">
              Description
            </label>
            <Textarea
              value={tokenDescription}
              onChange={(e) => setTokenDescription(e.target.value)}
              placeholder="Describe your token's purpose and vision..."
              className="bg-background border-primary/20 min-h-[100px]"
            />
          </div>

          <Button
            onClick={calculateAIScore}
            variant="outline"
            className="w-full border-primary/30"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Calculate AI Launch Score
          </Button>

          {aiScore > 0 && (
            <div className="p-6 rounded-xl bg-primary/5 border border-primary/20 text-center">
              <div className="text-sm text-muted-foreground mb-2">AI Launch Score</div>
              <div className="text-5xl font-bold bg-gradient-to-r from-primary to-blue-500 bg-clip-text text-transparent mb-2">
                {aiScore}/100
              </div>
              {aiScore >= 80 && (
                <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-0">
                  Phoenix Approved Potential
                </Badge>
              )}
            </div>
          )}

          <Button
            onClick={handleDeployToken}
            disabled={!wallet.connected}
            className="w-full bg-gradient-to-r from-purple-400 to-pink-500 hover:from-purple-300 hover:to-pink-400 text-white font-bold py-6"
          >
            <Coins className="w-5 h-5 mr-2" />
            Deploy Token to Solana
          </Button>

          <p className="text-xs text-center text-muted-foreground">
            Note: This is a demo deployment. Real Solana token creation with Web3.js coming soon!
          </p>
        </div>
      </Card>
    </div>
  );
};