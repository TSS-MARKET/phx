import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Flame, TrendingUp, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface MemecoinData {
  chainId: string;
  dexId: string;
  url: string;
  pairAddress: string;
  baseToken: {
    name: string;
    symbol: string;
    address: string;
  };
  priceUsd: string;
  priceChange: {
    h24: number;
  };
  volume: {
    h24: number;
  };
  liquidity: {
    usd: number;
  };
  fdv: number;
  info?: {
    imageUrl: string;
  };
}

// Fetch trending from Dexscreener
const fetchTrendingMemecoins = async (chain?: string): Promise<MemecoinData[]> => {
  try {
    const url = chain && chain !== 'all'
      ? `https://api.dexscreener.com/latest/dex/trending?chain=${chain}`
      : 'https://api.dexscreener.com/latest/dex/trending';
    
    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to fetch trending data');
    
    const data = await response.json();
    const pairs = data.pairs || [];
    
    // Sort by 24h volume (trending score)
    return pairs.sort((a: MemecoinData, b: MemecoinData) => 
      (b.volume?.h24 || 0) - (a.volume?.h24 || 0)
    ).slice(0, 10);
  } catch (error) {
    console.error('Error fetching trending memecoins:', error);
    return [];
  }
};

const CoinCard = ({ coin, idx }: { coin: MemecoinData; idx: number }) => {
  const [imgError, setImgError] = useState(false);
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: idx * 0.03, duration: 0.4 }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
      className="p-4 rounded-xl bg-gradient-to-br from-card/40 to-card/20 backdrop-blur-xl border border-primary/10 hover:border-primary/30 transition-all relative overflow-hidden group"
    >
      {/* Premium glow effect */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
      />
      
      <div className="flex items-center justify-between gap-4 relative z-10">
        <div className="flex items-center gap-3 flex-1 min-w-0">
          {!imgError && coin.info?.imageUrl ? (
            <motion.img 
              src={coin.info.imageUrl} 
              alt={coin.baseToken.name}
              onError={() => setImgError(true)}
              className="w-12 h-12 rounded-full border-2 border-primary/30 flex-shrink-0"
              whileHover={{ scale: 1.1, rotate: 5 }}
              transition={{ duration: 0.3 }}
            />
          ) : (
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center text-xl font-bold flex-shrink-0">
              {coin.baseToken.symbol.charAt(0)}
            </div>
          )}
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <div className="font-bold text-base truncate">{coin.baseToken.name}</div>
              {idx === 0 && (
                <motion.div
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Badge variant="default" className="gap-1 bg-orange-500/20 text-orange-500 border-orange-500/30 flex-shrink-0">
                    <Flame className="w-3 h-3" />
                    #1
                  </Badge>
                </motion.div>
              )}
            </div>
            <div className="text-xs text-muted-foreground flex items-center gap-2">
              <span className="truncate">{coin.baseToken.symbol}</span>
              <span className="px-2 py-0.5 bg-primary/20 rounded uppercase text-[10px] flex-shrink-0">
                {coin.chainId}
              </span>
            </div>
          </div>
        </div>
        
        <div className="text-right flex-shrink-0">
          <div className="text-sm font-semibold">
            ${Number(coin.priceUsd).toFixed(Number(coin.priceUsd) < 0.01 ? 8 : 4)}
          </div>
          <div className={`text-xs flex items-center justify-end gap-1 ${
            coin.priceChange?.h24 > 0 ? 'text-primary glow-cyan' : 'text-red-500'
          }`}>
            <TrendingUp className={`w-3 h-3 ${coin.priceChange?.h24 < 0 ? 'rotate-180' : ''}`} />
            {coin.priceChange?.h24 > 0 ? '+' : ''}{coin.priceChange?.h24?.toFixed(2)}%
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-border/30 text-xs relative z-10">
        <div>
          <div className="text-muted-foreground">Volume 24h</div>
          <div className="font-semibold">
            ${coin.volume?.h24 >= 1000000000 
              ? `${(Number(coin.volume.h24) / 1000000000).toFixed(2)}B`
              : coin.volume?.h24 >= 1000000 
              ? `${(Number(coin.volume.h24) / 1000000).toFixed(2)}M`
              : `${(Number(coin.volume.h24) / 1000).toFixed(0)}K`}
          </div>
        </div>
        <div>
          <div className="text-muted-foreground">Liquidity</div>
          <div className="font-semibold">
            ${coin.liquidity?.usd > 1000000
              ? `${(coin.liquidity.usd / 1000000).toFixed(2)}M`
              : `${(coin.liquidity.usd / 1000).toFixed(0)}K`}
          </div>
        </div>
        <div>
          <div className="text-muted-foreground">FDV</div>
          <div className="font-semibold">
            ${coin.fdv > 1000000
              ? `${(coin.fdv / 1000000).toFixed(2)}M`
              : `${(coin.fdv / 1000).toFixed(0)}K`}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export const MemecoinTrending = () => {
  const [selectedChain, setSelectedChain] = useState<string>("all");
  const { toast } = useToast();
  const [lastRefresh, setLastRefresh] = useState(Date.now());

  const { data: trendingData, isLoading, refetch } = useQuery({
    queryKey: ['memecoin-trending', selectedChain],
    queryFn: () => fetchTrendingMemecoins(selectedChain),
    staleTime: 30000,
    refetchInterval: 60000,
  });

  // Auto-refresh every 60 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setLastRefresh(Date.now());
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const handleManualRefresh = () => {
    refetch();
    setLastRefresh(Date.now());
    toast({
      title: "Refreshed!",
      description: "Fetching latest trending data...",
    });
  };

  const displayedCoins = trendingData?.filter(coin => coin.volume?.h24 > 5000) || [];
  const chains = ["all", "solana", "bsc", "ethereum", "base", "arbitrum"];

  const getChainDisplayName = (chain: string) => {
    if (chain === 'all') return 'All Chains – Top 10 Memecoins (24h Trending)';
    const names: Record<string, string> = {
      'solana': 'Solana Trending',
      'bsc': 'BSC Trending', 
      'ethereum': 'Ethereum Trending',
      'base': 'Base Trending',
      'arbitrum': 'Arbitrum Trending'
    };
    return names[chain] || `${chain.charAt(0).toUpperCase() + chain.slice(1)} Trending`;
  };

  return (
    <Card className="glass-card p-6 border border-primary/20">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Flame className="w-6 h-6 text-orange-500" />
          </motion.div>
          <h3 className="text-2xl font-bold glow-orange">Memecoin 24hr Trending</h3>
        </div>
        <motion.button
          whileHover={{ scale: 1.1, rotate: 180 }}
          whileTap={{ scale: 0.9 }}
          onClick={handleManualRefresh}
          className="p-2 rounded-lg bg-primary/20 hover:bg-primary/30 transition-colors"
          title="Refresh data"
        >
          <RefreshCw className="w-5 h-5 text-primary" />
        </motion.button>
      </div>
      
      <p className="text-sm text-muted-foreground mb-6">
        Real-time trending memecoins from Dexscreener • Refreshes every 60 seconds
      </p>

      <Tabs value={selectedChain} onValueChange={setSelectedChain} className="w-full">
        <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6 mb-6 bg-muted/30">
          {chains.map((chain) => (
            <TabsTrigger
              key={chain}
              value={chain}
              className="capitalize data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
            >
              {chain === 'all' ? 'All Chains' : chain}
            </TabsTrigger>
          ))}
        </TabsList>

        {chains.map((chain) => (
          <TabsContent key={chain} value={chain} className="space-y-3">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-orange-500" />
                <h4 className="text-lg font-bold">
                  {getChainDisplayName(chain)}
                </h4>
              </div>
              <span className="text-xs text-muted-foreground">
                Updated: {new Date(lastRefresh).toLocaleTimeString()}
              </span>
            </div>

            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[...Array(10)].map((_, i) => (
                  <Skeleton key={i} className="h-32 rounded-xl" />
                ))}
              </div>
            ) : displayedCoins.length ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {displayedCoins.map((coin, idx) => (
                  <CoinCard key={coin.pairAddress} coin={coin} idx={idx} />
                ))}
              </div>
            ) : (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-12 text-muted-foreground"
              >
                <p>No trending data available</p>
              </motion.div>
            )}
          </TabsContent>
        ))}
      </Tabs>
    </Card>
  );
};
