import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const platforms = [
  { name: "MEXC", logo: "https://s2.coinmarketcap.com/static/img/exchanges/64x64/544.png" },
  { name: "Bybit", logo: "https://s2.coinmarketcap.com/static/img/exchanges/64x64/521.png" },
  { name: "Gate.io", logo: "https://s2.coinmarketcap.com/static/img/exchanges/64x64/302.png" },
  { name: "OKX", logo: "https://s2.coinmarketcap.com/static/img/exchanges/64x64/294.png" },
  { name: "Raydium", logo: "https://s2.coinmarketcap.com/static/img/exchanges/64x64/631.png" },
  { name: "Jupiter", logo: "https://s2.coinmarketcap.com/static/img/exchanges/64x64/1311.png" },
  { name: "Uniswap", logo: "https://s2.coinmarketcap.com/static/img/exchanges/64x64/283.png" },
  { name: "PancakeSwap", logo: "https://s2.coinmarketcap.com/static/img/exchanges/64x64/468.png" },
];

export const PlatformAvailability = () => {
  const { toast } = useToast();
  const contractAddress = "0x742d35Cc6634C0532925a3b844Bc454e4438f44e"; // Placeholder CA

  const copyToClipboard = () => {
    navigator.clipboard.writeText(contractAddress);
    toast({
      title: "Copied!",
      description: "Contract address copied to clipboard",
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: 0.2 }}
      className="mb-16"
    >
      <Card className="glass-card p-8 max-w-6xl mx-auto overflow-hidden">
        {/* Contract Address with Animation - Moved to top */}
        <div className="flex flex-col items-center gap-3 mb-8">
          <div className="text-sm text-muted-foreground">Contract Address</div>
          <motion.div 
            className="flex items-center gap-2 bg-muted/30 rounded-lg p-4 border border-primary/20"
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.2 }}
          >
            <motion.code 
              className="font-mono text-sm md:text-base text-primary font-bold"
              animate={{
                textShadow: [
                  "0 0 10px rgba(251, 146, 60, 0.3)",
                  "0 0 20px rgba(251, 146, 60, 0.6)",
                  "0 0 10px rgba(251, 146, 60, 0.3)",
                ]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              {contractAddress}
            </motion.code>
            <motion.button
              onClick={copyToClipboard}
              className="p-2 hover:bg-muted rounded transition-colors"
              whileHover={{ scale: 1.1, rotate: 5 }}
              whileTap={{ scale: 0.9 }}
            >
              <Copy className="w-4 h-4 text-primary" />
            </motion.button>
          </motion.div>
        </div>

        <div className="text-center mb-8">
          <motion.h2 
            className="text-3xl font-bold glow-cyan"
            animate={{
              textShadow: [
                "0 0 20px rgba(34, 211, 238, 0.5)",
                "0 0 40px rgba(34, 211, 238, 0.8)",
                "0 0 20px rgba(34, 211, 238, 0.5)",
              ]
            }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            Available On Multiple Platforms
          </motion.h2>
        </div>

        {/* Auto-scrolling Platform Logos */}
        <div className="relative overflow-hidden">
          <motion.div
            className="flex gap-8 items-center"
            animate={{
              x: [0, -1920],
            }}
            transition={{
              duration: 30,
              repeat: Infinity,
              ease: "linear",
            }}
          >
            {/* Duplicate the platforms array for seamless loop */}
            {[...platforms, ...platforms, ...platforms].map((platform, idx) => (
              <motion.div
                key={`${platform.name}-${idx}`}
                className="flex flex-col items-center gap-3 min-w-[150px]"
                whileHover={{ scale: 1.1 }}
                transition={{ duration: 0.3 }}
              >
                <div className="relative">
                  <motion.div
                    className="absolute inset-0 bg-primary/20 rounded-full blur-xl"
                    animate={{
                      opacity: [0.3, 0.6, 0.3],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: idx * 0.2,
                    }}
                  />
                  <img
                    src={platform.logo}
                    alt={platform.name}
                    className="w-16 h-16 rounded-full relative z-10 border-2 border-primary/30"
                  />
                </div>
                <div className="text-center">
                  <div className="font-bold text-sm">{platform.name}</div>
                  <Badge 
                    variant="outline" 
                    className="mt-1 text-xs bg-accent/20 text-accent border-accent/30"
                  >
                    Coming Soon
                  </Badge>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>

        <p className="text-center text-muted-foreground mt-6 text-sm">
          $PHX will be available on major centralized and decentralized exchanges soon
        </p>
      </Card>
    </motion.div>
  );
};
