import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useWalletAuth } from '@/contexts/WalletAuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Coins, Zap, CheckCircle, Lock } from 'lucide-react';
import { motion } from 'framer-motion';

export const TokenCreatorWallet = () => {
  const { walletAddress } = useWalletAuth();
  const { toast } = useToast();
  const [tokenName, setTokenName] = useState('');
  const [tokenSymbol, setTokenSymbol] = useState('');
  const [tokenSupply, setTokenSupply] = useState('');
  const [tokenDescription, setTokenDescription] = useState('');
  const [aiScore, setAiScore] = useState<number | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  const calculateAIScore = () => {
    let score = 50;
    
    if (tokenName.length > 5) score += 10;
    if (tokenSymbol.length >= 3 && tokenSymbol.length <= 5) score += 10;
    if (tokenDescription.length > 100) score += 15;
    if (parseInt(tokenSupply) > 1000000) score += 10;
    
    score = Math.min(100, score + Math.floor(Math.random() * 15));
    setAiScore(score);
  };

  const handleDeploy = async () => {
    if (!walletAddress || !tokenName || !tokenSymbol || !tokenSupply) {
      toast({
        title: 'Missing Information',
        description: 'Please fill in all required fields',
        variant: 'destructive'
      });
      return;
    }

    setIsCreating(true);
    try {
      // This is a demo deployment - real Solana deployment coming soon
      const demoAddress = `${walletAddress.slice(0, 8)}...${Math.random().toString(36).slice(2, 10)}`;
      
      const { data, error } = await supabase
        .from('user_tokens')
        .insert({
          user_id: walletAddress,
          token_name: tokenName,
          token_symbol: tokenSymbol,
          token_address: demoAddress,
          token_supply: parseInt(tokenSupply),
          ai_launch_score: aiScore,
          phoenix_approved: (aiScore || 0) >= 80
        })
        .select()
        .single();

      if (error) throw error;

      toast({
        title: 'Token Created! 🎉',
        description: `${tokenName} (${tokenSymbol}) deployed successfully${(aiScore || 0) >= 80 ? ' with Phoenix Approved badge!' : ''}`,
      });

      // Reset form
      setTokenName('');
      setTokenSymbol('');
      setTokenSupply('');
      setTokenDescription('');
      setAiScore(null);
    } catch (error: any) {
      toast({
        title: 'Deployment Failed',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border-yellow-500/30">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center">
            <Coins className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold">AI Token Creator</h3>
            <p className="text-sm text-muted-foreground">Deploy Solana tokens with AI scoring</p>
          </div>
        </div>

        <div className="grid gap-4 mb-6">
          <div>
            <Label>Token Name *</Label>
            <Input
              value={tokenName}
              onChange={(e) => setTokenName(e.target.value)}
              placeholder="Phoenix Token"
              className="bg-background/50"
            />
          </div>

          <div>
            <Label>Token Symbol *</Label>
            <Input
              value={tokenSymbol}
              onChange={(e) => setTokenSymbol(e.target.value.toUpperCase())}
              placeholder="PHX"
              maxLength={5}
              className="bg-background/50"
            />
          </div>

          <div>
            <Label>Total Supply *</Label>
            <Input
              type="number"
              value={tokenSupply}
              onChange={(e) => setTokenSupply(e.target.value)}
              placeholder="1000000000"
              className="bg-background/50"
            />
          </div>

          <div>
            <Label>Description</Label>
            <Textarea
              value={tokenDescription}
              onChange={(e) => setTokenDescription(e.target.value)}
              placeholder="Describe your token's purpose and utility..."
              className="bg-background/50 min-h-[100px]"
            />
          </div>
        </div>

        <div className="flex gap-3">
          <Button
            onClick={calculateAIScore}
            variant="outline"
            className="flex-1 border-cyan-500 text-cyan-400 hover:bg-cyan-500/10"
          >
            <Zap className="w-4 h-4 mr-2" />
            Calculate AI Score
          </Button>
          <Button
            onClick={handleDeploy}
            disabled={isCreating || !aiScore}
            className="flex-1 bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold hover:from-yellow-300 hover:to-orange-600"
          >
            {isCreating ? 'Deploying...' : 'Deploy Token'}
          </Button>
        </div>

        {aiScore !== null && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mt-6 p-6 bg-background/50 rounded-xl border border-yellow-500/30"
          >
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-bold">AI Launch Score</h4>
              <div className="flex items-center gap-2">
                <span className="text-3xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                  {aiScore}
                </span>
                <span className="text-muted-foreground">/100</span>
              </div>
            </div>

            <div className="space-y-3 text-sm">
              {aiScore >= 80 && (
                <div className="flex items-center gap-2 text-yellow-400">
                  <CheckCircle className="w-5 h-5" />
                  <span className="font-bold">Phoenix Approved Badge Earned! 🎉</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-muted-foreground">Name Quality:</span>
                <Badge variant="outline" className={tokenName.length > 5 ? 'border-green-500 text-green-500' : 'border-yellow-500 text-yellow-500'}>
                  {tokenName.length > 5 ? 'Good' : 'Fair'}
                </Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Symbol Format:</span>
                <Badge variant="outline" className={tokenSymbol.length >= 3 ? 'border-green-500 text-green-500' : 'border-yellow-500 text-yellow-500'}>
                  {tokenSymbol.length >= 3 ? 'Valid' : 'Short'}
                </Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Description:</span>
                <Badge variant="outline" className={tokenDescription.length > 100 ? 'border-green-500 text-green-500' : 'border-yellow-500 text-yellow-500'}>
                  {tokenDescription.length > 100 ? 'Detailed' : 'Basic'}
                </Badge>
              </div>
            </div>

            {aiScore >= 80 && (
              <div className="mt-4 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                <p className="text-xs text-yellow-400">
                  ✨ This token meets Phoenix AI's quality standards and will receive the Phoenix Approved badge!
                </p>
              </div>
            )}
          </motion.div>
        )}
      </Card>

      <Card className="p-6 bg-muted/30">
        <h4 className="font-bold mb-3">📋 Deployment Notes</h4>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li>• This is a demo deployment for testing purposes</li>
          <li>• Real Solana deployment with Web3.js coming soon</li>
          <li>• Phoenix Approved badge awarded for scores 80+</li>
          <li>• Liquidity launcher integration pending</li>
        </ul>
      </Card>
    </div>
  );
};
