import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Mic, MicOff, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useVoiceCommand } from "@/hooks/useVoiceCommand";
import { VoiceWaveform } from "@/components/ui/voice-waveform";
import { useToast } from "@/hooks/use-toast";

export const VoiceTrading = () => {
  const { toast } = useToast();
  const [messages, setMessages] = useState<Array<{ role: string; content: string }>>([]);
  const { isListening, transcript, audioLevel, startListening, stopListening, resetTranscript, isSupported } = useVoiceCommand();

  const handleStartListening = async () => {
    resetTranscript();
    startListening();
  };

  const handleStopListening = () => {
    stopListening();
    if (transcript) {
      processCommand(transcript);
    }
  };

  const processCommand = (command: string) => {
    setMessages(prev => [...prev, { role: "user", content: command }]);
    
    // Simulate AI response
    setTimeout(() => {
      const response = `Processing: "${command}"`;
      setMessages(prev => [...prev, { role: "assistant", content: response }]);
      toast({
        title: "Command Received",
        description: command,
      });
    }, 500);
    
    resetTranscript();
  };

  if (!isSupported) {
    return (
      <Card className="glass-card p-6">
        <p className="text-muted-foreground text-center">
          Voice commands not supported in your browser
        </p>
      </Card>
    );
  }

  return (
    <Card className="glass-card p-6 border border-primary/20 relative overflow-hidden">
      {/* Animated background */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5"
        animate={{ opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 3, repeat: Infinity }}
      />

      <div className="relative z-10">
        <div className="flex items-center gap-2 mb-6">
          <Mic className="w-6 h-6 text-primary" />
          <h3 className="text-2xl font-bold">Voice Trading</h3>
        </div>

        {/* Voice Waveform */}
        <div className="mb-6">
          <VoiceWaveform isActive={isListening} audioLevel={audioLevel} />
        </div>

        {/* Transcript Display */}
        <AnimatePresence>
          {transcript && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mb-4 p-4 rounded-lg bg-primary/10 border border-primary/30"
            >
              <p className="text-sm text-primary">{transcript}</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Control Buttons */}
        <div className="flex gap-4 mb-6">
          <Button
            onClick={isListening ? handleStopListening : handleStartListening}
            className={`flex-1 ${isListening ? 'bg-destructive hover:bg-destructive/90' : 'bg-primary hover:bg-primary/90'}`}
          >
            {isListening ? (
              <>
                <MicOff className="w-4 h-4 mr-2" />
                Stop Listening
              </>
            ) : (
              <>
                <Mic className="w-4 h-4 mr-2" />
                Start Voice Command
              </>
            )}
          </Button>
          
          {transcript && !isListening && (
            <Button onClick={() => processCommand(transcript)} variant="secondary">
              <Send className="w-4 h-4 mr-2" />
              Send
            </Button>
          )}
        </div>

        {/* Messages */}
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {messages.map((msg, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: msg.role === "user" ? 20 : -20 }}
              animate={{ opacity: 1, x: 0 }}
              className={`p-3 rounded-lg ${
                msg.role === "user"
                  ? "bg-primary/20 border-primary/30 ml-12"
                  : "bg-secondary/20 border-secondary/30 mr-12"
              } border`}
            >
              <p className="text-sm">{msg.content}</p>
            </motion.div>
          ))}
        </div>

        {/* Voice Commands Help */}
        <div className="mt-6 p-4 rounded-lg bg-muted/20 border border-border/50">
          <p className="text-xs text-muted-foreground mb-2 font-semibold">Try commands like:</p>
          <ul className="text-xs text-muted-foreground space-y-1">
            <li>• "Buy 0.5 Bitcoin"</li>
            <li>• "Show me Ethereum price"</li>
            <li>• "Set alert for Solana at $100"</li>
          </ul>
        </div>
      </div>
    </Card>
  );
};
