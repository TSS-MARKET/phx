import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown, Target, AlertTriangle, Crown } from "lucide-react";
import { usePhoenixDaily3 } from "@/hooks/usePhoenixDaily3";
import { useSubscription } from "@/hooks/useSubscription";
import { useState } from "react";
import { PaymentModal } from "./PaymentModal";

export const PhoenixDaily3 = () => {
  const { data: picks, isLoading } = usePhoenixDaily3();
  const { canAccessFeature } = useSubscription();
  const [showUpgrade, setShowUpgrade] = useState(false);

  const hasAccess = canAccessFeature('phoenix_daily_3');

  if (!hasAccess) {
    return (
      <>
        <Card className="p-8 text-center border-2 border-yellow-500/30 bg-yellow-500/5 backdrop-blur">
          <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-foreground mb-2">
            Phoenix Daily 3 - Elite Feature
          </h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Unlock AI's top 3 daily crypto picks with elite-level analysis, entry/exit recommendations, and risk assessment.
          </p>
          <Button 
            onClick={() => setShowUpgrade(true)}
            className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-300 hover:to-orange-400 text-white font-bold"
          >
            Upgrade to Elite
          </Button>
        </Card>
        <PaymentModal 
          isOpen={showUpgrade}
          onClose={() => setShowUpgrade(false)}
          tier="elite"
        />
      </>
    );
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="p-6 bg-background/40 backdrop-blur border-primary/20">
            <div className="h-32 bg-primary/5 animate-pulse rounded" />
          </Card>
        ))}
      </div>
    );
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-400 bg-green-500/10 border-green-500/30';
      case 'medium': return 'text-yellow-400 bg-yellow-500/10 border-yellow-500/30';
      case 'high': return 'text-red-400 bg-red-500/10 border-red-500/30';
      default: return 'text-gray-400 bg-gray-500/10 border-gray-500/30';
    }
  };

  const getRankBadge = (rank: number) => {
    const colors = [
      'bg-gradient-to-r from-yellow-400 to-orange-500 text-white',
      'bg-gradient-to-r from-gray-400 to-gray-500 text-white',
      'bg-gradient-to-r from-orange-400 to-red-500 text-white',
    ];
    return colors[rank - 1];
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/30 mb-4">
          <Crown className="w-5 h-5 text-yellow-400" />
          <span className="text-sm font-bold bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
            PHOENIX DAILY 3
          </span>
        </div>
        <h2 className="text-3xl font-bold text-foreground mb-2">
          AI's Top 3 Daily Picks
        </h2>
        <p className="text-muted-foreground">
          Elite AI analysis • Updated every 24 hours at 00:00 UTC
        </p>
      </div>

      {picks && picks.length > 0 ? (
        <div className="grid gap-6">
          {picks.map((pick) => (
            <Card key={pick.id} className="p-6 border-2 border-primary/30 bg-background/40 backdrop-blur hover:border-primary/50 transition-all duration-300">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className={`${getRankBadge(pick.rank)} px-4 py-2 rounded-xl font-bold text-lg`}>
                    #{pick.rank}
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-foreground">{pick.coin_name}</h3>
                    <p className="text-lg text-muted-foreground">{pick.coin_symbol.toUpperCase()}</p>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="text-2xl font-bold text-foreground">
                    ${pick.current_price?.toFixed(6) || '0'}
                  </div>
                  <div className={`flex items-center gap-1 justify-end ${
                    pick.price_change_24h && pick.price_change_24h > 0 ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {pick.price_change_24h && pick.price_change_24h > 0 ? (
                      <TrendingUp className="w-4 h-4" />
                    ) : (
                      <TrendingDown className="w-4 h-4" />
                    )}
                    <span className="font-bold">{pick.price_change_24h?.toFixed(2)}%</span>
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4 mb-4">
                <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
                  <div className="text-xs text-muted-foreground mb-1">AI Score</div>
                  <div className="text-2xl font-bold bg-gradient-to-r from-primary to-blue-500 bg-clip-text text-transparent">
                    {pick.ai_score}/100
                  </div>
                </div>
                <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
                  <div className="text-xs text-muted-foreground mb-1">Market Cap</div>
                  <div className="text-lg font-bold text-foreground">
                    ${(pick.market_cap / 1000000).toFixed(2)}M
                  </div>
                </div>
                <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
                  <div className="text-xs text-muted-foreground mb-1">24h Volume</div>
                  <div className="text-lg font-bold text-foreground">
                    ${(pick.volume_24h / 1000000).toFixed(2)}M
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4 mb-4">
                <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/30">
                  <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                    <Target className="w-3 h-3" />
                    Entry Price
                  </div>
                  <div className="text-sm font-bold text-green-400">
                    ${pick.ai_entry_price?.toFixed(6)}
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-neon-purple/10 border border-neon-purple/30">
                  <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                    <Target className="w-3 h-3" />
                    AI Exit Price
                  </div>
                  <div className="text-sm font-bold text-neon-purple">
                    ${pick.ai_exit_price?.toFixed(6)}
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30">
                  <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" />
                    Stop Loss
                  </div>
                  <div className="text-sm font-bold text-red-400">
                    ${pick.ai_stop_loss?.toFixed(6)}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <Badge className={`${getRiskColor(pick.risk_level)} border font-bold`}>
                  {pick.risk_level.toUpperCase()} RISK
                </Badge>
                <div className="text-xs text-muted-foreground">
                  Sentiment: {pick.sentiment_score?.toFixed(1)}/100
                </div>
              </div>

              <div className="mt-4 p-4 rounded-lg bg-primary/5 border border-primary/20">
                <p className="text-sm text-muted-foreground">{pick.ai_reasoning}</p>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="p-8 text-center border-primary/20 bg-background/40 backdrop-blur">
          <p className="text-muted-foreground">
            Phoenix is analyzing the market... Daily picks will be available soon.
          </p>
        </Card>
      )}
    </div>
  );
};