import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Settings, Plus, Trash2, LucideIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
export interface QuickAction {
  label: string;
  icon: LucideIcon;
  template: string;
}
interface TradingBotSettingsProps {
  quickActions: QuickAction[];
  onUpdateQuickActions: (actions: QuickAction[]) => void;
}
export const TradingBotSettings = ({
  quickActions,
  onUpdateQuickActions
}: TradingBotSettingsProps) => {
  const [localActions, setLocalActions] = useState(quickActions);
  const [open, setOpen] = useState(false);
  const {
    toast
  } = useToast();
  const handleSave = () => {
    onUpdateQuickActions(localActions);
    setOpen(false);
    toast({
      title: '✓ Settings Saved',
      description: 'Quick actions updated successfully'
    });
  };
  const handleAddAction = () => {
    const {
      Zap
    } = require('lucide-react');
    setLocalActions([...localActions, {
      label: 'New Action',
      icon: Zap,
      template: ''
    }]);
  };
  const handleRemoveAction = (index: number) => {
    setLocalActions(localActions.filter((_, i) => i !== index));
  };
  const handleUpdateAction = (index: number, field: keyof QuickAction, value: string) => {
    const updated = [...localActions];
    updated[index] = {
      ...updated[index],
      [field]: value
    };
    setLocalActions(updated);
  };
  return <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="border-primary/30 rounded-sm h-8 w-8 p-0">
          <Settings className="w-4 h-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto bg-card border-primary/30">
        <DialogHeader className="my-0 text-base mx-0 py-px px-0">
          <DialogTitle className="text-primary">Customize Quick Actions</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 mt-4">
          <p className="text-sm text-muted-foreground">
            Configure quick action buttons and their message templates. Use placeholders like {'{TOKEN}'}, {'{AMOUNT}'}, {'{PRICE}'}.
          </p>

          {localActions.map((action, index) => <div key={index} className="p-4 border border-primary/20 rounded-lg space-y-3 bg-muted/20">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-primary">Action {index + 1}</span>
                <Button variant="ghost" size="sm" onClick={() => handleRemoveAction(index)} className="text-destructive hover:text-destructive">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
              
              <div>
                <Label className="text-xs">Button Label</Label>
                <Input value={action.label} onChange={e => handleUpdateAction(index, 'label', e.target.value as any)} placeholder="e.g., Buy" className="mt-1" />
              </div>

              <div>
                <Label className="text-xs">Message Template</Label>
                <Input value={action.template} onChange={e => handleUpdateAction(index, 'template', e.target.value as any)} placeholder="e.g., Buy {TOKEN} with entry at ${ENTRY}, TP: ${TP}, SL: ${SL}" className="mt-1" />
                <p className="text-xs text-muted-foreground mt-1">
                  Use {'{TOKEN}'}, {'{ENTRY}'}, {'{TP}'}, {'{SL}'}, {'{PRICE}'}, {'{TSL}'} as placeholders
                </p>
              </div>
            </div>)}

          <Button variant="outline" onClick={handleAddAction} className="w-full border-primary/30">
            <Plus className="w-4 h-4 mr-2" />
            Add Quick Action
          </Button>
        </div>

        <div className="flex gap-3 mt-6">
          <Button variant="outline" onClick={() => setOpen(false)} className="flex-1">
            Cancel
          </Button>
          <Button onClick={handleSave} className="flex-1 bg-primary text-primary-foreground">
            Save Changes
          </Button>
        </div>
      </DialogContent>
    </Dialog>;
};