import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Bot, X, Send, History, Plus, Wallet, TrendingUp, LineChart, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ChatHistory } from "./ChatHistory";
import { WalletConnect, getWalletAddress } from "./WalletConnect";
import {
  Message,
  Conversation,
  createConversation,
  addMessageToConversation,
  getConversation,
} from "@/utils/chatStorage";

const AIChatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const quickActions = [
    { icon: TrendingUp, label: "Market Analysis", prompt: "Give me a quick analysis of the current crypto market trends" },
    { icon: LineChart, label: "Top Coins", prompt: "What are the top 5 trending cryptocurrencies right now?" },
    { icon: Zap, label: "Trading Tips", prompt: "Give me 3 actionable trading tips for today" },
  ];

  const startNewConversation = () => {
    const welcomeMsg: Message = {
      role: "assistant",
      content: "Hey! I'm Phoenix AI. Ask me anything about crypto - market trends, coin analysis, trading tips, or investment strategies. How can I help you today?",
      timestamp: Date.now(),
    };

    const walletAddress = getWalletAddress();
    
    if (walletAddress) {
      const conversation = createConversation(walletAddress, welcomeMsg);
      setCurrentConversation(conversation);
      setMessages([welcomeMsg]);
    } else {
      // Allow chat without wallet, but don't save to conversation
      setCurrentConversation(null);
      setMessages([welcomeMsg]);
    }
  };

  const loadConversation = (conversationId: string) => {
    const conversation = getConversation(conversationId);
    if (conversation) {
      setCurrentConversation(conversation);
      setMessages(conversation.messages);
      setIsHistoryOpen(false);
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleQuickAction = (prompt: string) => {
    setInput(prompt);
    sendMessage(prompt);
  };

  const sendMessage = async (overrideText?: string) => {
    const text = (overrideText ?? input).trim();
    if (!text || isLoading) return;

    const walletAddress = getWalletAddress();
    
    // Create new conversation if none exists
    if (!currentConversation && !messages.length) {
      startNewConversation();
    }

    // Validate message length
    const MAX_MESSAGE_LENGTH = 2000;
    if (text.length > MAX_MESSAGE_LENGTH) {
      toast({
        title: "Message Too Long",
        description: `Please limit messages to ${MAX_MESSAGE_LENGTH} characters`,
        variant: "destructive",
      });
      return;
    }

    const userMessage: Message = {
      role: "user",
      content: text,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMessage]);
    
    // Only save to conversation if wallet is connected
    if (walletAddress && currentConversation) {
      addMessageToConversation(currentConversation.id, userMessage);
    }
    
    setInput("");
    setIsLoading(true);

    try {
      const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-chat`;
      
      const response = await fetch(CHAT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ messages: [...messages, userMessage] }),
      });

      if (!response.ok) {
        if (response.status === 429) {
          toast({
            title: "Rate limit exceeded",
            description: "Please try again later.",
            variant: "destructive",
          });
          setIsLoading(false);
          return;
        }
        if (response.status === 402) {
          toast({
            title: "Payment required",
            description: "Please add funds to continue using AI features.",
            variant: "destructive",
          });
          setIsLoading(false);
          return;
        }
        throw new Error("Failed to get AI response");
      }

      if (!response.body) throw new Error("No response body");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let assistantMessage = "";

      setMessages((prev) => [...prev, { role: "assistant", content: "", timestamp: Date.now() }]);

      let textBuffer = "";
      let streamDone = false;

      while (!streamDone) {
        const { done, value } = await reader.read();
        if (done) break;
        
        textBuffer += decoder.decode(value, { stream: true });

        let newlineIndex: number;
        while ((newlineIndex = textBuffer.indexOf("\n")) !== -1) {
          let line = textBuffer.slice(0, newlineIndex);
          textBuffer = textBuffer.slice(newlineIndex + 1);

          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (line.startsWith(":") || line.trim() === "") continue;
          if (!line.startsWith("data: ")) continue;

          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") {
            streamDone = true;
            break;
          }

          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              assistantMessage += content;
              setMessages((prev) => {
                const newMessages = [...prev];
                newMessages[newMessages.length - 1] = {
                  role: "assistant",
                  content: assistantMessage,
                  timestamp: Date.now(),
                };
                return newMessages;
              });
            }
          } catch {
            textBuffer = line + "\n" + textBuffer;
            break;
          }
        }
      }

      // Save final assistant message
      if (assistantMessage) {
        const walletAddress = getWalletAddress();
        if (walletAddress && currentConversation) {
          const finalMessage: Message = {
            role: "assistant",
            content: assistantMessage,
            timestamp: Date.now(),
          };
          addMessageToConversation(currentConversation.id, finalMessage);
        }
      }

      setIsLoading(false);
    } catch (error) {
      console.error("Error sending message:", error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Button */}
      <motion.div
        initial={{ scale: 0, rotate: -180 }}
        animate={{ 
          scale: 1, 
          rotate: 0,
          y: [0, -10, 0]
        }}
        transition={{
          scale: { type: "spring", stiffness: 200 },
          rotate: { type: "spring", stiffness: 150 },
          y: {
            duration: 2,
            repeat: Infinity,
            repeatType: "reverse",
            ease: "easeInOut"
          }
        }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        className="fixed bottom-6 right-6 z-50"
      >
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className="rounded-full bg-gradient-to-r from-primary via-accent to-primary flex flex-col items-center justify-center gap-1 shadow-[0_0_30px_rgba(6,182,212,0.6)] hover:shadow-[0_0_50px_rgba(6,182,212,0.9)] transition-all px-4 py-3 h-auto animate-pulse-glow backdrop-blur-sm border-2 border-primary/30"
        >
          <Bot className="w-6 h-6 text-background drop-shadow-[0_0_10px_rgba(6,182,212,0.8)]" />
          <span className="text-[10px] font-bold text-background whitespace-nowrap tracking-wider">AI CHATBOT</span>
        </Button>
      </motion.div>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              scale: 1,
              boxShadow: [
                "0 0 20px rgba(6,182,212,0.3)",
                "0 0 40px rgba(139,92,246,0.4)",
                "0 0 20px rgba(6,182,212,0.3)"
              ]
            }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            transition={{ 
              type: "spring",
              stiffness: 200,
              damping: 25,
              boxShadow: {
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }
            }}
            className="fixed bottom-24 right-6 w-96 h-[600px] z-50 rounded-xl border-2 border-primary/40 flex flex-col backdrop-blur-xl bg-gradient-to-br from-background/95 via-background/90 to-background/85"
            style={{
              boxShadow: '0 0 40px rgba(6,182,212,0.4), 0 0 80px rgba(139,92,246,0.3), inset 0 0 60px rgba(6,182,212,0.1)'
            }}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-primary/20 bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10 backdrop-blur-xl">
              <div className="flex items-center gap-3">
                <Bot className="w-6 h-6 text-primary drop-shadow-[0_0_8px_rgba(6,182,212,0.6)]" />
                <h3 className="font-bold text-foreground">Phoenix AI Chatbot</h3>
              </div>
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={startNewConversation}
                  className="hover:bg-primary/10"
                  title="New conversation"
                >
                  <Plus className="w-5 h-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsHistoryOpen(true)}
                  className="hover:bg-primary/10"
                  title="View chat history"
                >
                  <History className="w-5 h-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsOpen(false)}
                  className="hover:bg-primary/10"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </div>

            {/* Wallet Connection Banner */}
            {!getWalletAddress() && (
              <div className="mx-4 mt-4 p-3 bg-gradient-to-r from-primary/20 to-accent/20 border border-primary/30 rounded-lg">
                <div className="flex items-start gap-2">
                  <Wallet className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-xs font-semibold text-foreground mb-1">Connect Wallet to Save History</p>
                    <p className="text-xs text-foreground/70 mb-2">
                      You can chat freely, but your conversation won't be saved
                    </p>
                    <WalletConnect />
                  </div>
                </div>
              </div>
            )}

            {/* Messages */}
            <ScrollArea className="flex-1 p-4" ref={scrollRef}>
              {messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
                  <Bot className="w-16 h-16 text-primary/50" />
                  <p className="text-sm text-muted-foreground mb-4">
                    Start a new conversation {getWalletAddress() ? "or load a previous one from history" : ""}
                  </p>
                  
                  {/* Quick Action Buttons */}
                  <div className="grid grid-cols-1 gap-2 w-full max-w-xs">
                   {quickActions.map((action, index) => (
                      <motion.button
                        key={index}
                        onClick={() => handleQuickAction(action.prompt)}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="flex items-center gap-3 p-3 rounded-lg border-2 border-primary/30 bg-gradient-to-r from-primary/10 to-accent/10 hover:from-primary/20 hover:to-accent/20 transition-all group"
                      >
                        <action.icon className="w-5 h-5 text-primary group-hover:scale-110 transition-transform" />
                        <span className="text-sm font-orbitron text-foreground group-hover:text-primary transition-colors">
                          {action.label}
                        </span>
                      </motion.button>
                    ))}
                  </div>

                  <Button 
                    onClick={startNewConversation} 
                    variant="outline"
                    className="mt-4 hover:scale-105 transition-transform"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    New Conversation
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {messages.map((message, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: message.role === "user" ? 20 : -20, scale: 0.9 }}
                        animate={{ opacity: 1, x: 0, scale: 1 }}
                        transition={{ 
                          type: "spring",
                          stiffness: 200,
                          damping: 20,
                          delay: index * 0.05 
                        }}
                        className={`flex ${
                          message.role === "user" ? "justify-end" : "justify-start"
                        }`}
                      >
                        <motion.div
                          whileHover={{ scale: 1.02, y: -2 }}
                          transition={{ type: "spring", stiffness: 300 }}
                          className={`max-w-[80%] p-4 rounded-xl backdrop-blur-sm border ${
                            message.role === "user"
                              ? "bg-gradient-to-br from-neon-purple to-neon-purple/80 text-white border-neon-purple/50 shadow-[0_0_15px_rgba(139,92,246,0.3)]"
                              : "bg-gradient-to-br from-muted/80 to-muted/60 border-primary/20 shadow-[0_0_10px_rgba(6,182,212,0.2)]"
                          }`}
                        >
                          {message.role === "assistant" && (
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              className="inline-flex items-center gap-2 mb-2"
                            >
                              <Bot className="w-4 h-4 text-primary" />
                              <span className="text-xs font-bold text-primary">Phoenix AI</span>
                            </motion.div>
                          )}
                          <p className="text-sm whitespace-pre-wrap leading-relaxed">{message.content}</p>
                        </motion.div>
                      </motion.div>
                    ))}
                    {isLoading && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ type: "spring", stiffness: 200 }}
                        className="flex justify-start"
                      >
                        <div className="bg-gradient-to-br from-muted/80 to-muted/60 backdrop-blur-sm p-4 rounded-xl border border-primary/20 shadow-[0_0_15px_rgba(6,182,212,0.3)]">
                          <div className="flex items-center gap-3">
                            <Bot className="w-5 h-5 text-primary" />
                            <div className="flex gap-1.5">
                              <motion.span 
                                className="w-2 h-2 bg-primary rounded-full"
                                animate={{ y: [-4, 4, -4], opacity: [1, 0.5, 1] }}
                                transition={{ duration: 1, repeat: Infinity, ease: "easeInOut" }}
                              />
                              <motion.span 
                                className="w-2 h-2 bg-primary rounded-full"
                                animate={{ y: [-4, 4, -4], opacity: [1, 0.5, 1] }}
                                transition={{ duration: 1, repeat: Infinity, ease: "easeInOut", delay: 0.2 }}
                              />
                              <motion.span 
                                className="w-2 h-2 bg-primary rounded-full"
                                animate={{ y: [-4, 4, -4], opacity: [1, 0.5, 1] }}
                                transition={{ duration: 1, repeat: Infinity, ease: "easeInOut", delay: 0.4 }}
                              />
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                </div>
              )}
            </ScrollArea>

            {/* Input */}
            <div className="p-4 border-t border-primary/20">
              <div className="flex gap-2">
                <div className="flex-1">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                    placeholder="Ask me anything about crypto..."
                    disabled={isLoading}
                    className="w-full"
                  />
                  {input.length > 0 && (
                    <div className={`text-xs mt-1 text-right ${input.length > 1800 ? 'text-destructive' : 'text-muted-foreground'}`}>
                      {input.length} / 2000
                    </div>
                  )}
                </div>
                <Button
                  onClick={() => sendMessage()}
                  disabled={isLoading || !input.trim()}
                  size="icon"
                  className="bg-primary hover:bg-primary/90"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat History Modal */}
      <ChatHistory
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        onLoadConversation={loadConversation}
      />
    </>
  );
};

export default AIChatbot;
