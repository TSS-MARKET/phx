import React, { useEffect, useRef, useState } from 'react';
import { motion, useInView, useScroll, useSpring, useTransform } from 'framer-motion';
import { Check, Lock, Volume2, VolumeX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useRoadmapSound } from '@/hooks/useRoadmapSound';
interface RoadmapPhase {
  title: string;
  description: string;
  bullets: string[];
  completed: boolean;
}
interface RoadmapTimelineProps {
  phases?: RoadmapPhase[];
  onPhaseComplete?: (index: number) => void;
}
const AUTO_DETECTED_PHASE_1: RoadmapPhase = {
  title: "Platform Launch",
  description: "Core infrastructure and essential features live",
  bullets: ["AI Trading Signals with machine learning analysis", "Trading Bot with automated execution", "MemeCoin Trending tracker with real-time data", "Wallet Integration (Phantom, Solflare)", "Portfolio Tracker with live balance updates", "AI Chatbot for trading assistance", "Social Buzz & Whale Alerts monitoring", "Technical Analysis charts & indicators"],
  completed: true
};
const DEFAULT_PHASES: RoadmapPhase[] = [AUTO_DETECTED_PHASE_1, {
  title: "Advanced Tools",
  description: "Power user features and automation",
  bullets: ["Token Creator with AI launch scoring", "Advanced Trading Bot automation with strategies", "Liquidity management tools", "Mobile app Beta (iOS & Android)", "Copy trading from top wallets", "Voice trading commands"],
  completed: true
}, {
  title: "Ecosystem Expansion",
  description: "Cross-chain and partner integrations",
  bullets: ["PHX Staking with rewards", "Cross-chain bridge (Ethereum, BSC)", "Jupiter DEX aggregator integration", "NFT portfolio tracking", "Advanced analytics dashboard", "API access for developers"],
  completed: false
}, {
  title: "Platform Maturity",
  description: "Enterprise-grade features and global reach",
  bullets: ["DAO governance for PHX holders", "Enterprise API with SLA guarantees", "White-label licensing for partners", "Multi-language support (10+ languages)", "Institutional trading features", "Educational academy with certifications"],
  completed: false
}];
export const RoadmapTimeline: React.FC<RoadmapTimelineProps> = ({
  phases = DEFAULT_PHASES,
  onPhaseComplete
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [revealedPhases, setRevealedPhases] = useState<Set<number>>(new Set());
  const {
    soundEnabled,
    setSoundEnabled,
    playTickSound,
    playRevealSound
  } = useRoadmapSound({
    enabled: false
  });
  const {
    scrollYProgress
  } = useScroll({
    target: containerRef,
    offset: ["start center", "end center"]
  });
  const pathLength = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  // Expose method for external phase completion
  useEffect(() => {
    (window as any).markPhaseComplete = (index: number) => {
      if (!revealedPhases.has(index)) {
        setRevealedPhases(prev => new Set([...prev, index]));
        playTickSound();
        onPhaseComplete?.(index);
      }
    };
    return () => {
      delete (window as any).markPhaseComplete;
    };
  }, [revealedPhases, playTickSound, onPhaseComplete]);
  return <div className="relative py-24" ref={containerRef}>
      {/* Sound Toggle */}
      <div className="absolute top-4 right-4 z-10">
        
      </div>

      {/* Section Header */}
      <motion.div initial={{
      opacity: 0,
      y: 20
    }} whileInView={{
      opacity: 1,
      y: 0
    }} viewport={{
      once: true
    }} className="text-center mb-20">
        <h2 className="text-4xl md:text-5xl font-black mb-4 font-orbitron">
          <span className="bg-gradient-to-r from-[hsl(var(--neon-cyan))] via-[hsl(var(--neon-purple))] to-[hsl(var(--neon-cyan))] text-transparent bg-clip-text">
            Development Roadmap
          </span>
        </h2>
        <p className="text-foreground/70 max-w-2xl mx-auto">
          Our journey from launch to becoming the premier AI-powered trading platform
        </p>
      </motion.div>

      {/* Timeline Container */}
      <div className="relative max-w-6xl mx-auto">
        {/* SVG Timeline Line */}
        <svg className="absolute left-8 md:left-1/2 top-0 h-full w-1 md:-ml-0.5 pointer-events-none" style={{
        zIndex: 0
      }}>
          <motion.path d={`M 0 0 L 0 ${phases.length * 400}`} stroke="url(#gradient)" strokeWidth="2" fill="none" strokeDasharray="1 0" style={{
          pathLength,
          filter: 'drop-shadow(0 0 8px hsl(var(--neon-cyan) / 0.6))'
        }} />
          <defs>
            <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="hsl(var(--neon-cyan))" />
              <stop offset="50%" stopColor="hsl(var(--neon-purple))" />
              <stop offset="100%" stopColor="hsl(var(--neon-cyan))" />
            </linearGradient>
          </defs>
        </svg>

        {/* Phases */}
        <div className="space-y-32">
          {phases.map((phase, index) => <RoadmapPhaseItem key={index} phase={phase} index={index} isRevealed={revealedPhases.has(index)} onReveal={() => {
          if (!revealedPhases.has(index)) {
            setRevealedPhases(prev => new Set([...prev, index]));
            playRevealSound();
            if (phase.completed) {
              setTimeout(() => playTickSound(), 600);
            }
          }
        }} />)}
        </div>
      </div>
    </div>;
};
interface RoadmapPhaseItemProps {
  phase: RoadmapPhase;
  index: number;
  isRevealed: boolean;
  onReveal: () => void;
}
const RoadmapPhaseItem: React.FC<RoadmapPhaseItemProps> = ({
  phase,
  index,
  isRevealed,
  onReveal
}) => {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, {
    once: true,
    margin: "-100px"
  });
  useEffect(() => {
    if (isInView && !isRevealed) {
      onReveal();
    }
  }, [isInView, isRevealed, onReveal]);
  const isLeft = index % 2 === 0;
  return <div ref={ref} className={`relative flex items-start gap-8 ${isLeft ? 'md:flex-row' : 'md:flex-row-reverse'} flex-col`}>
      {/* Timeline Marker */}
      <div className="absolute left-8 md:left-1/2 -ml-6 md:-ml-6 z-10">
        <motion.div initial={{
        scale: 0
      }} animate={isRevealed ? {
        scale: 1
      } : {
        scale: 0
      }} transition={{
        duration: 0.3,
        delay: 0.2,
        type: "spring",
        stiffness: 200
      }} className="relative">
          {/* Marker Circle */}
          <motion.div className={`w-12 h-12 rounded-full border-2 flex items-center justify-center relative
              ${phase.completed ? 'bg-[hsl(142,76%,36%)] border-[hsl(142,76%,56%)]' : 'bg-card border-[hsl(var(--neon-cyan))]'}`} animate={phase.completed && isRevealed ? {
          boxShadow: ['0 0 20px hsl(142, 76%, 56% / 0.4)', '0 0 40px hsl(142, 76%, 56% / 0.8)', '0 0 20px hsl(142, 76%, 56% / 0.4)']
        } : {}} transition={{
          duration: 0.6,
          delay: 0.45
        }}>
            {phase.completed ? <motion.div initial={{
            pathLength: 0,
            opacity: 0
          }} animate={isRevealed ? {
            pathLength: 1,
            opacity: 1
          } : {}} transition={{
            duration: 0.42,
            delay: 0.6,
            ease: [0.16, 0.84, 0.29, 1]
          }}>
                <Check className="w-6 h-6 text-white" strokeWidth={3} />
              </motion.div> : <motion.div animate={{
            scale: [1, 1.2, 1],
            opacity: [0.5, 1, 0.5]
          }} transition={{
            duration: 2,
            repeat: Infinity
          }}>
                <Lock className="w-5 h-5 text-muted-foreground" />
              </motion.div>}
          </motion.div>

          {/* Pulsing Ring for Active Phase */}
          {!phase.completed && isRevealed && <motion.div className="absolute inset-0 rounded-full border-2 border-[hsl(var(--neon-cyan))]" animate={{
          scale: [1, 1.5],
          opacity: [0.6, 0]
        }} transition={{
          duration: 2,
          repeat: Infinity
        }} />}
        </motion.div>
      </div>

      {/* Content Card */}
      <div className={`flex-1 ${isLeft ? 'md:pr-16' : 'md:pl-16'} pl-20 md:pl-0`}>
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} animate={isRevealed ? {
        opacity: 1,
        y: 0
      } : {}} transition={{
        duration: 0.45,
        ease: [0.16, 0.84, 0.29, 1]
      }} whileHover={{
        y: -6,
        transition: {
          duration: 0.2
        }
      }} className={`bg-card border border-border rounded-lg p-6 relative
            ${phase.completed ? 'opacity-90' : 'opacity-100'}
            hover:border-[hsl(var(--neon-cyan))] transition-all duration-300`} style={{
        boxShadow: phase.completed ? '0 4px 20px hsl(142, 76%, 36% / 0.2)' : '0 4px 20px hsl(var(--neon-cyan) / 0.1)'
      }}>
          {/* Blink Effect */}
          {phase.completed && isRevealed && <motion.div className="absolute inset-0 rounded-lg bg-[hsl(142,76%,56%)]" initial={{
          opacity: 0
        }} animate={{
          opacity: [0, 0.1, 0],
          scale: [1, 1.06, 1]
        }} transition={{
          duration: 0.6,
          delay: 0.45
        }} />}

          {/* Phase Header */}
          <div className="flex items-start justify-between mb-3 relative z-10">
            <div>
              <h3 className="text-2xl font-bold font-orbitron mb-1">
                Phase {index + 1}: {phase.title}
              </h3>
              <p className="text-sm text-muted-foreground">{phase.description}</p>
            </div>
            {phase.completed && <motion.span initial={{
            opacity: 0,
            scale: 0.8
          }} animate={isRevealed ? {
            opacity: 1,
            scale: 1
          } : {}} transition={{
            delay: 0.9
          }} className="px-3 py-1 bg-[hsl(142,76%,36%)] text-white text-xs font-semibold rounded-full">
                Completed
              </motion.span>}
          </div>

          {/* Bullets */}
          <ul className="space-y-2 relative z-10">
            {phase.bullets.map((bullet, bulletIndex) => <motion.li key={bulletIndex} initial={{
            opacity: 0,
            x: -10
          }} animate={isRevealed ? {
            opacity: 1,
            x: 0
          } : {}} transition={{
            delay: 0.3 + bulletIndex * 0.12,
            ease: [0.16, 0.84, 0.29, 1]
          }} className="flex items-start gap-2">
                <motion.span initial={{
              scale: 0
            }} animate={isRevealed ? {
              scale: 1
            } : {}} transition={{
              delay: 0.4 + bulletIndex * 0.12
            }} className={`w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0
                    ${phase.completed ? 'bg-[hsl(142,76%,56%)]' : 'bg-[hsl(var(--neon-cyan))]'}`} style={{
              boxShadow: phase.completed ? '0 0 8px hsl(142, 76%, 56% / 0.6)' : '0 0 8px hsl(var(--neon-cyan) / 0.6)'
            }} />
                <span className="text-sm text-foreground/80">{bullet}</span>
              </motion.li>)}
          </ul>
        </motion.div>
      </div>

      {/* Spacer for alignment */}
      <div className="hidden md:block flex-1" />
    </div>;
};