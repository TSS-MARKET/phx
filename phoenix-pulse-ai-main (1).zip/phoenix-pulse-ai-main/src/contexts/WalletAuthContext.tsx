import { createContext, useContext, ReactNode, useEffect, useState } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { supabase } from '@/integrations/supabase/client';

const ADMIN_WALLET = '4BPeopNXjATGrewivH58WNtBAJs9xykvhisTLVPHNsx2';

interface WalletAuthContextType {
  walletAddress: string | null;
  isAdmin: boolean;
  isConnected: boolean;
  subscription: any;
  refreshSubscription: () => Promise<void>;
}

const WalletAuthContext = createContext<WalletAuthContextType | undefined>(undefined);

export const WalletAuthProvider = ({ children }: { children: ReactNode }) => {
  const { publicKey, connected } = useWallet();
  const [subscription, setSubscription] = useState<any>(null);
  const walletAddress = publicKey?.toBase58() || null;
  const isAdmin = walletAddress === ADMIN_WALLET;

  const refreshSubscription = async () => {
    if (!walletAddress) {
      setSubscription(null);
      return;
    }

    try {
      let { data, error } = await supabase
        .from('user_subscriptions')
        .select('*')
        .eq('user_id', walletAddress)
        .single();

      if (error && error.code === 'PGRST116') {
        // Create default subscription
        const { data: newSub, error: insertError } = await supabase
          .from('user_subscriptions')
          .insert({
            user_id: walletAddress,
            tier: isAdmin ? 'elite' : 'free',
            status: 'active'
          })
          .select()
          .single();

        if (insertError) throw insertError;
        data = newSub;
      } else if (error) {
        throw error;
      }

      // Admin always gets elite tier
      if (isAdmin && data.tier !== 'elite') {
        const { data: updated } = await supabase
          .from('user_subscriptions')
          .update({ tier: 'elite', status: 'active' })
          .eq('user_id', walletAddress)
          .select()
          .single();
        data = updated;
      }

      setSubscription(data);
    } catch (error) {
      console.error('Error fetching subscription:', error);
    }
  };

  useEffect(() => {
    if (connected && walletAddress) {
      refreshSubscription();
    } else {
      setSubscription(null);
    }
  }, [connected, walletAddress]);

  return (
    <WalletAuthContext.Provider
      value={{
        walletAddress,
        isAdmin,
        isConnected: connected,
        subscription,
        refreshSubscription
      }}
    >
      {children}
    </WalletAuthContext.Provider>
  );
};

export const useWalletAuth = () => {
  const context = useContext(WalletAuthContext);
  if (!context) {
    throw new Error('useWalletAuth must be used within WalletAuthProvider');
  }
  return context;
};
