import { lazy, Suspense, useMemo } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { ConnectionProvider, WalletProvider } from "@solana/wallet-adapter-react";
import { WalletModalProvider } from "@solana/wallet-adapter-react-ui";
import { PhantomWalletAdapter, SolflareWalletAdapter } from "@solana/wallet-adapter-wallets";
import { WalletAuthProvider } from "@/contexts/WalletAuthContext";
import { WalletNavigation } from "@/components/WalletNavigation";
import { AnimatePresence } from "framer-motion";
import { LoadingSkeleton } from "@/components/ui/loading-skeleton";
import PageTransition from "./components/PageTransition";

// Lazy load pages for better performance
const Home = lazy(() => import("./pages/Home"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const Features = lazy(() => import("./pages/Features"));
const Token = lazy(() => import("./pages/Token"));
const About = lazy(() => import("./pages/About"));
const Contact = lazy(() => import("./pages/Contact"));
const Holdings = lazy(() => import("./pages/Holdings"));
const WalletSubscription = lazy(() => import("./pages/WalletSubscription"));
const WalletDApp = lazy(() => import("./pages/WalletDApp"));
const AdminPanel = lazy(() => import("./pages/AdminPanel"));
const AdminDashboard = lazy(() => import("./pages/AdminDashboard"));
const NotFound = lazy(() => import("./pages/NotFound"));
const AIChatbot = lazy(() => import("./components/AIChatbot"));

import "@solana/wallet-adapter-react-ui/styles.css";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60000, // 1 minute
      gcTime: 300000, // 5 minutes
      refetchOnWindowFocus: false,
    },
  },
});

const MAINNET_RPC = "https://wider-aged-energy.solana-mainnet.quiknode.pro/1e5a51e2fd0fb6cfedf80885b9c6f6f6029aa20a/";

const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center">
    <div className="space-y-4 w-full max-w-4xl px-4">
      <LoadingSkeleton variant="card" className="h-64" />
      <LoadingSkeleton variant="card" className="h-48" />
    </div>
  </div>
);

const AnimatedRoutes = () => {
  const location = useLocation();

  return (
    <AnimatePresence initial={false} mode="sync">
      <Suspense fallback={null}>
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<PageTransition><Home /></PageTransition>} />
          <Route path="/dashboard" element={<PageTransition><Dashboard /></PageTransition>} />
          <Route path="/features" element={<PageTransition><Features /></PageTransition>} />
          <Route path="/token" element={<PageTransition><Token /></PageTransition>} />
          <Route path="/holdings" element={<PageTransition><Holdings /></PageTransition>} />
          <Route path="/about" element={<PageTransition><About /></PageTransition>} />
          <Route path="/contact" element={<PageTransition><Contact /></PageTransition>} />
          <Route path="/subscription" element={<PageTransition><WalletSubscription /></PageTransition>} />
          <Route path="/dapp" element={<PageTransition><WalletDApp /></PageTransition>} />
          <Route path="/admin" element={<PageTransition><AdminPanel /></PageTransition>} />
          <Route path="/admin/dashboard" element={<PageTransition><AdminDashboard /></PageTransition>} />
          <Route path="*" element={<PageTransition><NotFound /></PageTransition>} />
        </Routes>
      </Suspense>
    </AnimatePresence>
  );
};

const App = () => {
  const endpoint = useMemo(() => MAINNET_RPC, []);
  
  const wallets = useMemo(
    () => [
      new PhantomWalletAdapter(),
      new SolflareWalletAdapter(),
    ],
    []
  );

  return (
    <ConnectionProvider endpoint={endpoint}>
      <WalletProvider wallets={wallets} autoConnect>
        <WalletModalProvider>
          <WalletAuthProvider>
            <QueryClientProvider client={queryClient}>
              <TooltipProvider>
                <Toaster />
                <Sonner />
                <BrowserRouter>
                  <WalletNavigation />
                  <Suspense fallback={null}>
                    <AIChatbot />
                  </Suspense>
                  <AnimatedRoutes />
                </BrowserRouter>
              </TooltipProvider>
            </QueryClientProvider>
          </WalletAuthProvider>
        </WalletModalProvider>
      </WalletProvider>
    </ConnectionProvider>
  );
};

export default App;
