export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      admin_analytics: {
        Row: {
          created_at: string | null
          date: string
          elite_users: number | null
          free_users: number | null
          id: string
          new_users: number | null
          pro_users: number | null
          total_fees_collected: number | null
          total_trades: number | null
          total_users: number | null
          total_volume: number | null
        }
        Insert: {
          created_at?: string | null
          date: string
          elite_users?: number | null
          free_users?: number | null
          id?: string
          new_users?: number | null
          pro_users?: number | null
          total_fees_collected?: number | null
          total_trades?: number | null
          total_users?: number | null
          total_volume?: number | null
        }
        Update: {
          created_at?: string | null
          date?: string
          elite_users?: number | null
          free_users?: number | null
          id?: string
          new_users?: number | null
          pro_users?: number | null
          total_fees_collected?: number | null
          total_trades?: number | null
          total_users?: number | null
          total_volume?: number | null
        }
        Relationships: []
      }
      bot_settings: {
        Row: {
          auto_trading_enabled: boolean | null
          created_at: string | null
          id: string
          max_daily_trades: number | null
          risk_per_trade: number | null
          slippage_tolerance: number | null
          stop_loss_percentage: number | null
          take_profit_percentage: number | null
          trailing_stop_enabled: boolean | null
          trailing_stop_percentage: number | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          auto_trading_enabled?: boolean | null
          created_at?: string | null
          id?: string
          max_daily_trades?: number | null
          risk_per_trade?: number | null
          slippage_tolerance?: number | null
          stop_loss_percentage?: number | null
          take_profit_percentage?: number | null
          trailing_stop_enabled?: boolean | null
          trailing_stop_percentage?: number | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          auto_trading_enabled?: boolean | null
          created_at?: string | null
          id?: string
          max_daily_trades?: number | null
          risk_per_trade?: number | null
          slippage_tolerance?: number | null
          stop_loss_percentage?: number | null
          take_profit_percentage?: number | null
          trailing_stop_enabled?: boolean | null
          trailing_stop_percentage?: number | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          content: string
          created_at: string | null
          id: string
          role: string
          session_id: string
          user_id: string | null
        }
        Insert: {
          content: string
          created_at?: string | null
          id?: string
          role: string
          session_id: string
          user_id?: string | null
        }
        Update: {
          content?: string
          created_at?: string | null
          id?: string
          role?: string
          session_id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      phoenix_daily_picks: {
        Row: {
          ai_entry_price: number | null
          ai_exit_price: number | null
          ai_reasoning: string | null
          ai_score: number
          ai_stop_loss: number | null
          coin_id: string
          coin_name: string
          coin_symbol: string
          created_at: string | null
          current_price: number | null
          id: string
          market_cap: number | null
          pick_date: string
          price_change_24h: number | null
          rank: number
          risk_level: string
          sentiment_score: number | null
          volume_24h: number | null
        }
        Insert: {
          ai_entry_price?: number | null
          ai_exit_price?: number | null
          ai_reasoning?: string | null
          ai_score: number
          ai_stop_loss?: number | null
          coin_id: string
          coin_name: string
          coin_symbol: string
          created_at?: string | null
          current_price?: number | null
          id?: string
          market_cap?: number | null
          pick_date?: string
          price_change_24h?: number | null
          rank: number
          risk_level: string
          sentiment_score?: number | null
          volume_24h?: number | null
        }
        Update: {
          ai_entry_price?: number | null
          ai_exit_price?: number | null
          ai_reasoning?: string | null
          ai_score?: number
          ai_stop_loss?: number | null
          coin_id?: string
          coin_name?: string
          coin_symbol?: string
          created_at?: string | null
          current_price?: number | null
          id?: string
          market_cap?: number | null
          pick_date?: string
          price_change_24h?: number | null
          rank?: number
          risk_level?: string
          sentiment_score?: number | null
          volume_24h?: number | null
        }
        Relationships: []
      }
      price_alerts: {
        Row: {
          alert_type: string
          coin_id: string
          created_at: string | null
          current_price: number | null
          id: string
          is_active: boolean | null
          target_price: number
          token_symbol: string
          triggered_at: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          alert_type: string
          coin_id: string
          created_at?: string | null
          current_price?: number | null
          id?: string
          is_active?: boolean | null
          target_price: number
          token_symbol: string
          triggered_at?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          alert_type?: string
          coin_id?: string
          created_at?: string | null
          current_price?: number | null
          id?: string
          is_active?: boolean | null
          target_price?: number
          token_symbol?: string
          triggered_at?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      rate_limits: {
        Row: {
          count: number | null
          created_at: string | null
          id: string
          key: string
          updated_at: string | null
          window_start: string | null
        }
        Insert: {
          count?: number | null
          created_at?: string | null
          id?: string
          key: string
          updated_at?: string | null
          window_start?: string | null
        }
        Update: {
          count?: number | null
          created_at?: string | null
          id?: string
          key?: string
          updated_at?: string | null
          window_start?: string | null
        }
        Relationships: []
      }
      trading_history: {
        Row: {
          ai_confidence: number | null
          amount_in: number
          amount_out: number | null
          closed_at: string | null
          created_at: string | null
          entry_price: number | null
          executed_at: string | null
          exit_price: number | null
          fee_amount: number | null
          from_token: string
          id: string
          mode: string
          price: number | null
          profit_loss: number | null
          profit_loss_percentage: number | null
          status: string
          stop_loss: number | null
          take_profit: number | null
          to_token: string
          trade_type: string
          transaction_signature: string | null
          user_id: string
        }
        Insert: {
          ai_confidence?: number | null
          amount_in: number
          amount_out?: number | null
          closed_at?: string | null
          created_at?: string | null
          entry_price?: number | null
          executed_at?: string | null
          exit_price?: number | null
          fee_amount?: number | null
          from_token: string
          id?: string
          mode: string
          price?: number | null
          profit_loss?: number | null
          profit_loss_percentage?: number | null
          status?: string
          stop_loss?: number | null
          take_profit?: number | null
          to_token: string
          trade_type: string
          transaction_signature?: string | null
          user_id: string
        }
        Update: {
          ai_confidence?: number | null
          amount_in?: number
          amount_out?: number | null
          closed_at?: string | null
          created_at?: string | null
          entry_price?: number | null
          executed_at?: string | null
          exit_price?: number | null
          fee_amount?: number | null
          from_token?: string
          id?: string
          mode?: string
          price?: number | null
          profit_loss?: number | null
          profit_loss_percentage?: number | null
          status?: string
          stop_loss?: number | null
          take_profit?: number | null
          to_token?: string
          trade_type?: string
          transaction_signature?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_subscriptions: {
        Row: {
          created_at: string | null
          daily_analysis_count: number | null
          id: string
          last_analysis_reset: string | null
          status: string
          subscription_end: string | null
          subscription_start: string | null
          tier: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          daily_analysis_count?: number | null
          id?: string
          last_analysis_reset?: string | null
          status?: string
          subscription_end?: string | null
          subscription_start?: string | null
          tier?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          daily_analysis_count?: number | null
          id?: string
          last_analysis_reset?: string | null
          status?: string
          subscription_end?: string | null
          subscription_start?: string | null
          tier?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_tiers: {
        Row: {
          id: string
          last_verified_at: string | null
          phx_balance: number | null
          tier: string
          updated_at: string | null
          user_id: string
          verified_at: string | null
          wallet_address: string | null
        }
        Insert: {
          id?: string
          last_verified_at?: string | null
          phx_balance?: number | null
          tier?: string
          updated_at?: string | null
          user_id: string
          verified_at?: string | null
          wallet_address?: string | null
        }
        Update: {
          id?: string
          last_verified_at?: string | null
          phx_balance?: number | null
          tier?: string
          updated_at?: string | null
          user_id?: string
          verified_at?: string | null
          wallet_address?: string | null
        }
        Relationships: []
      }
      user_tokens: {
        Row: {
          ai_launch_score: number | null
          created_at: string | null
          id: string
          liquidity_added: boolean | null
          liquidity_pool_address: string | null
          metadata_uri: string | null
          phoenix_approved: boolean | null
          token_address: string
          token_decimals: number
          token_name: string
          token_supply: number
          token_symbol: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          ai_launch_score?: number | null
          created_at?: string | null
          id?: string
          liquidity_added?: boolean | null
          liquidity_pool_address?: string | null
          metadata_uri?: string | null
          phoenix_approved?: boolean | null
          token_address: string
          token_decimals?: number
          token_name: string
          token_supply: number
          token_symbol: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          ai_launch_score?: number | null
          created_at?: string | null
          id?: string
          liquidity_added?: boolean | null
          liquidity_pool_address?: string | null
          metadata_uri?: string | null
          phoenix_approved?: boolean | null
          token_address?: string
          token_decimals?: number
          token_name?: string
          token_supply?: number
          token_symbol?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_trading_analytics: {
        Row: {
          average_roi: number | null
          best_trade_profit: number | null
          created_at: string | null
          id: string
          last_updated: string | null
          losing_trades: number | null
          total_profit_loss: number | null
          total_trades: number | null
          total_volume_traded: number | null
          user_id: string
          win_rate: number | null
          winning_trades: number | null
          worst_trade_loss: number | null
        }
        Insert: {
          average_roi?: number | null
          best_trade_profit?: number | null
          created_at?: string | null
          id?: string
          last_updated?: string | null
          losing_trades?: number | null
          total_profit_loss?: number | null
          total_trades?: number | null
          total_volume_traded?: number | null
          user_id: string
          win_rate?: number | null
          winning_trades?: number | null
          worst_trade_loss?: number | null
        }
        Update: {
          average_roi?: number | null
          best_trade_profit?: number | null
          created_at?: string | null
          id?: string
          last_updated?: string | null
          losing_trades?: number | null
          total_profit_loss?: number | null
          total_trades?: number | null
          total_volume_traded?: number | null
          user_id?: string
          win_rate?: number | null
          winning_trades?: number | null
          worst_trade_loss?: number | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_access_feature: {
        Args: { _feature: string; _user_id: string }
        Returns: boolean
      }
      cleanup_rate_limits: { Args: never; Returns: undefined }
      reset_daily_analysis_count: { Args: never; Returns: undefined }
    }
    Enums: {
      subscription_status: "active" | "cancelled" | "expired" | "trialing"
      subscription_tier: "free" | "pro" | "elite"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      subscription_status: ["active", "cancelled", "expired", "trialing"],
      subscription_tier: ["free", "pro", "elite"],
    },
  },
} as const
