import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWalletAuth } from '@/contexts/WalletAuthContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { Bot, Droplet, Coins, Lock } from 'lucide-react';
import { TradingBotWallet } from '@/components/TradingBotWallet';
import { TokenCreatorWallet } from '@/components/TokenCreatorWallet';
import { useWalletSubscription } from '@/hooks/useWalletSubscription';
import { Badge } from '@/components/ui/badge';

export default function WalletDApp() {
  const { walletAddress } = useWalletAuth();
  const { canAccessFeature } = useWalletSubscription();
  const navigate = useNavigate();

  const canAccessBot = canAccessFeature('trading_bot');
  const canAccessToken = canAccessFeature('token_creator');

  if (!walletAddress) {
    return (
      <div className="min-h-screen pt-24 pb-16 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <h1 className="text-4xl font-bold mb-4">Connect Your Wallet</h1>
          <p className="text-muted-foreground">Please connect your Solana wallet to access DApp features.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20">
      <Tabs defaultValue="trading-bot" className="w-full">
        <div className="container mx-auto max-w-7xl px-4 mb-6">
          <TabsList className="grid w-full grid-cols-3 bg-muted/50">
            <TabsTrigger value="trading-bot" className="data-[state=active]:bg-cyan-500/20">
              <Bot className="w-4 h-4 mr-2" />
              Trading Bot
            </TabsTrigger>
            <TabsTrigger value="liquidity" disabled className="opacity-50">
              <Droplet className="w-4 h-4 mr-2" />
              Liquidity
              <Lock className="w-3 h-3 ml-2" />
            </TabsTrigger>
            <TabsTrigger value="token-creator" className="data-[state=active]:bg-yellow-500/20">
              <Coins className="w-4 h-4 mr-2" />
              Token Creator
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="trading-bot" className="m-0">
          {canAccessBot ? (
            <TradingBotWallet />
          ) : (
            <div className="container mx-auto max-w-7xl px-4">
              <Card className="p-12 text-center border-yellow-500/30 bg-yellow-500/5">
                <Lock className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-2">Trading Bot - Elite Feature</h3>
                <p className="text-muted-foreground mb-6">Upgrade to Elite to access AI-powered trading signals and automated execution.</p>
                <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black cursor-pointer" onClick={() => navigate('/subscription')}>
                  Upgrade to Elite
                </Badge>
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="liquidity" className="m-0">
          <div className="container mx-auto max-w-7xl px-4">
            <Card className="p-12 text-center border-cyan-500/30 bg-cyan-500/5">
              <Droplet className="w-16 h-16 text-cyan-400 mx-auto mb-4 animate-pulse" />
              <h3 className="text-2xl font-bold mb-2">Liquidity Launcher</h3>
              <p className="text-muted-foreground">Coming Soon - Create and manage liquidity pools for your tokens</p>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="token-creator" className="m-0">
          {canAccessToken ? (
            <TokenCreatorWallet />
          ) : (
            <div className="container mx-auto max-w-7xl px-4">
              <Card className="p-12 text-center border-yellow-500/30 bg-yellow-500/5">
                <Lock className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-2">Token Creator - Elite Feature</h3>
                <p className="text-muted-foreground mb-6">Upgrade to Elite to deploy Solana tokens with AI scoring and Phoenix Approved badge.</p>
                <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black cursor-pointer" onClick={() => navigate('/subscription')}>
                  Upgrade to Elite
                </Badge>
              </Card>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
