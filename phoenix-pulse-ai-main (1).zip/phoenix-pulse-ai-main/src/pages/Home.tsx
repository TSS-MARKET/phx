import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { TrendingUp, Bot, Shield } from "lucide-react";
import phoenixLogo from "@/assets/phx-ai-logo.png";
import { useLiveStats } from "@/hooks/useLiveStats";
import { MarketMetrics } from "@/components/MarketMetrics";
import { useState, useEffect } from "react";
import { ScrollAnimated3D } from "@/components/ScrollAnimated3D";
import { Tilt3DCard } from "@/components/Tilt3DCard";

const Home = () => {
  const navigate = useNavigate();
  const liveStats = useLiveStats();

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Animated Grid Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-cyber-darker via-background to-cyber-dark">
        <motion.div 
          className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iY3lhbiIgc3Ryb2tlLW9wYWNpdHk9IjAuMSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-20"
          animate={{
            backgroundPosition: ['0% 0%', '100% 100%'],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            repeatType: 'reverse',
            ease: 'linear',
          }}
        />
        {/* Floating orbs */}
        <motion.div
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            x: [0, 50, 0],
            y: [0, -30, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
        <motion.div
          className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.3, 1],
            x: [0, -50, 0],
            y: [0, 40, 0],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
      </div>

      <div className="relative z-10 container mx-auto px-4 pt-32 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center max-w-5xl mx-auto"
        >
          <motion.div
            animate={{ 
              y: [0, -8, 0]
            }}
            transition={{ 
              duration: 4, 
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="mb-8 flex justify-center"
          >
            <div className="relative">
              <div className="absolute inset-0 blur-3xl bg-primary/30 rounded-full"></div>
              
              <motion.img 
                src={phoenixLogo} 
                alt="Phoenix AI" 
                className="w-48 h-48 rounded-full relative z-10 border-2 border-primary/30 shadow-[0_0_30px_rgba(6,182,212,0.4)]"
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </motion.div>

          <motion.h1 
            className="text-7xl md:text-8xl font-black mb-6 glow-cyan font-orbitron relative"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <span className="relative inline-block">
              PHOENIX AI
              <motion.div
                className="absolute inset-0 blur-xl"
                animate={{
                  opacity: [0.3, 0.6, 0.3],
                }}
                transition={{ duration: 3, repeat: Infinity }}
                style={{
                  background: 'linear-gradient(90deg, hsl(184, 100%, 50%), hsl(268, 85%, 58%))',
                  WebkitBackgroundClip: 'text',
                }}
              />
            </span>
          </motion.h1>
          
          <div className="h-24 mb-8">
            <TypewriterText
              texts={[
                "Rebirth of Crypto.",
                "Where Crypto Limits End.",
                "The Future of AI Trading.",
              ]}
            />
          </div>

          <p className="text-xl md:text-2xl text-foreground/80 mb-12 max-w-3xl mx-auto">
            Experience the next evolution of cryptocurrency trading. 
            AI-powered analysis, real-time insights, and intelligent automation.
          </p>

          <div className="flex flex-wrap justify-center gap-4 mb-16">
              <motion.button
                onClick={() => navigate("/dashboard")}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 rounded-xl font-bold text-lg relative overflow-hidden group bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 animate-gradient-shift bg-[length:200%_200%] shadow-[0_0_30px_rgba(6,182,212,0.4)] hover:shadow-[0_0_50px_rgba(6,182,212,0.8)] transition-all duration-300"
              >
                <span className="relative z-10">Launch Phoenix AI</span>
              </motion.button>
              <motion.button
                onClick={() => navigate("/features")}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 rounded-xl font-bold text-lg relative overflow-hidden group bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 animate-gradient-shift bg-[length:200%_200%] shadow-[0_0_30px_rgba(6,182,212,0.4)] hover:shadow-[0_0_50px_rgba(6,182,212,0.8)] transition-all duration-300"
              >
                <span className="relative z-10">Explore Features</span>
              </motion.button>
          </div>

          <div className="space-y-4 mb-8 mt-24">
            <h3 className="text-2xl font-bold text-center glow-cyan">
              Live Statistics of Phoenix AI
            </h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
            <ScrollAnimated3D delay={0}>
              <Tilt3DCard>
                <StatCard
                  icon={<TrendingUp className="w-8 h-8" />}
                  value={liveStats.activeTraders.toLocaleString()}
                  label="Active Traders"
                />
              </Tilt3DCard>
            </ScrollAnimated3D>
            <ScrollAnimated3D delay={0.1}>
              <Tilt3DCard>
                <StatCard
                  icon={<Bot className="w-8 h-8" />}
                  value={liveStats.signalsGenerated.toLocaleString()}
                  label="Signals Generated"
                />
              </Tilt3DCard>
            </ScrollAnimated3D>
            <ScrollAnimated3D delay={0.2}>
              <Tilt3DCard>
                <StatCard
                  icon={<Shield className="w-8 h-8" />}
                  value={`${liveStats.successRate}%`}
                  label="Success Rate"
                />
              </Tilt3DCard>
            </ScrollAnimated3D>
            <ScrollAnimated3D delay={0.3}>
              <Tilt3DCard>
                <StatCard
                  icon={<TrendingUp className="w-8 h-8" />}
                  value={`$${liveStats.tradingVolume.toLocaleString()}`}
                  label="Trading Volume"
                />
              </Tilt3DCard>
            </ScrollAnimated3D>
          </div>
        </motion.div>

        {/* Separator */}
        <motion.div 
          className="mt-20 mb-12 max-w-4xl mx-auto"
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
        >
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-primary/30"></div>
            </div>
            <div className="relative flex justify-center">
              <span className="px-6 py-2 bg-background/80 backdrop-blur-sm text-sm font-bold text-primary uppercase tracking-wider border border-primary/30 rounded-full glow-cyan">
                Core Features
              </span>
            </div>
          </div>
        </motion.div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          <ScrollAnimated3D delay={0}>
            <Tilt3DCard maxTilt={8}>
              <FeatureCard
                title="AI Analysis"
                description="Advanced machine learning algorithms analyze market trends in real-time"
                gradient="from-primary/20 to-transparent"
                onClick={() => navigate("/dashboard")}
              />
            </Tilt3DCard>
          </ScrollAnimated3D>
          <ScrollAnimated3D delay={0.15}>
            <Tilt3DCard maxTilt={8}>
              <FeatureCard
                title="Smart Trading"
                description="Automated trading strategies powered by cutting-edge AI technology"
                gradient="from-secondary/20 to-transparent"
                onClick={() => navigate("/features")}
              />
            </Tilt3DCard>
          </ScrollAnimated3D>
          <ScrollAnimated3D delay={0.3}>
            <Tilt3DCard maxTilt={8}>
              <FeatureCard
                title="Memecoin Tracker"
                description="Track trending memecoins with social sentiment analysis"
                gradient="from-accent/20 to-transparent"
                onClick={() => navigate("/dashboard")}
              />
            </Tilt3DCard>
          </ScrollAnimated3D>
        </div>

        <div className="mt-16 max-w-6xl mx-auto">
          <ScrollAnimated3D>
            <h2 className="text-4xl font-bold text-center mb-16 glow-cyan">
              Advanced Trading Tools
            </h2>
          </ScrollAnimated3D>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ScrollAnimated3D delay={0}>
              <Tilt3DCard maxTilt={8}>
                <FeatureCard
                  title="Portfolio Analytics"
                  description="Track your investments with real-time profit/loss calculations and comprehensive asset management"
                  gradient="from-primary/20 to-transparent"
                  onClick={() => {
                    navigate("/dashboard");
                    setTimeout(() => {
                      const element = document.querySelector('[value="portfolio"]');
                      if (element) (element as HTMLElement).click();
                    }, 100);
                  }}
                />
              </Tilt3DCard>
            </ScrollAnimated3D>
            <ScrollAnimated3D delay={0.1}>
              <Tilt3DCard maxTilt={8}>
                <FeatureCard
                  title="Whale Alerts"
                  description="Monitor large crypto transactions and follow the smart money with instant whale movement notifications"
                  gradient="from-secondary/20 to-transparent"
                  onClick={() => {
                    navigate("/dashboard");
                    setTimeout(() => {
                      const element = document.querySelector('[value="whale-alerts"]');
                      if (element) (element as HTMLElement).click();
                    }, 100);
                  }}
                />
              </Tilt3DCard>
            </ScrollAnimated3D>
            <ScrollAnimated3D delay={0.2}>
              <Tilt3DCard maxTilt={8}>
                <FeatureCard
                  title="Trading Signals"
                  description="AI-generated buy and sell signals with confidence ratings to guide your trading decisions"
                  gradient="from-accent/20 to-transparent"
                  onClick={() => {
                    navigate("/dashboard");
                    setTimeout(() => {
                      const element = document.querySelector('[value="signals"]');
                      if (element) (element as HTMLElement).click();
                    }, 100);
                  }}
                />
              </Tilt3DCard>
            </ScrollAnimated3D>
            <ScrollAnimated3D delay={0.3}>
              <Tilt3DCard maxTilt={8}>
                <FeatureCard
                  title="Market Sentiment"
                  description="Real-time sentiment analysis from social media, news, and on-chain data"
                  gradient="from-primary/20 to-transparent"
                  onClick={() => navigate("/dashboard")}
                />
              </Tilt3DCard>
            </ScrollAnimated3D>
          </div>
        </div>
      </div>

      <MarketMetrics />
    </div>
  );
};

const TypewriterText = ({ texts }: { texts: string[] }) => {
  const [index, setIndex] = useState(0);
  const [displayText, setDisplayText] = useState("");

  useEffect(() => {
    const currentText = texts[index];
    if (displayText.length < currentText.length) {
      const t = setTimeout(() => {
        setDisplayText(currentText.slice(0, displayText.length + 1));
      }, 70);
      return () => clearTimeout(t);
    } else {
      const pause = setTimeout(() => {
        setDisplayText("");
        setIndex((prev) => (prev + 1) % texts.length);
      }, 1800);
      return () => clearTimeout(pause);
    }
  }, [displayText, index, texts]);

  return (
    <h2 className="text-4xl md:text-5xl font-bold glow-orange min-h-[80px] flex items-center justify-center">
      {displayText}
      <span className="animate-pulse">|</span>
    </h2>
  );
};

const StatCard = ({ icon, value, label }: { icon: React.ReactNode; value: string; label: string }) => {
  return (
    <motion.div 
      layout
      className="glass-card p-6 rounded-xl relative overflow-hidden group border border-primary/30 shadow-[0_0_30px_rgba(79,209,197,0.15)] hover:shadow-[0_0_50px_rgba(79,209,197,0.35)] transition-all duration-500 ease-out shimmer min-h-[160px] flex flex-col justify-center"
      whileHover={{ y: -8 }}
    >
      {/* Animated scanline effect */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/20 to-transparent opacity-0 group-hover:opacity-100"
        animate={{
          y: ['-100%', '200%'],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: 'linear',
        }}
      />
      
      {/* Corner accents */}
      <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-primary/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-primary/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-primary/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-primary/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      
      <div className="flex flex-col items-center relative z-10">
        <motion.div 
          className="text-primary mb-3"
          whileHover={{ scale: 1.2, rotate: 360 }}
          transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
        >
          {icon}
        </motion.div>
        <motion.div 
          className="text-3xl font-bold glow-cyan mb-2"
          initial={{ scale: 1 }}
          whileInView={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          {value}
        </motion.div>
        <div className="text-sm text-muted-foreground font-medium">{label}</div>
      </div>
    </motion.div>
  );
};

const FeatureCard = ({ title, description, gradient, onClick }: { title: string; description: string; gradient: string; onClick?: () => void }) => {
  return (
    <motion.div 
      layout
      onClick={onClick}
      className={`glass-card p-8 rounded-xl bg-gradient-to-br ${gradient} border border-primary/30 shadow-[0_0_30px_rgba(79,209,197,0.15)] hover:shadow-[0_0_60px_rgba(79,209,197,0.5)] transition-all duration-500 ease-out relative overflow-hidden group shimmer min-h-[200px] flex flex-col ${onClick ? 'cursor-pointer' : ''}`}
      whileHover={{ scale: 1.02, y: -5 }}
      transition={{ duration: 0.3 }}
    >
      {/* Animated gradient overlay */}
      <motion.div
        className="absolute inset-0 opacity-0 group-hover:opacity-100"
        style={{
          background: 'linear-gradient(135deg, transparent 0%, rgba(79,209,197,0.1) 50%, transparent 100%)',
        }}
        animate={{
          x: ['-100%', '100%'],
        }}
        transition={{
          duration: 1.5,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />
      
      {/* Data stream effect */}
      <motion.div
        className="absolute right-0 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-primary to-transparent opacity-0 group-hover:opacity-60"
        animate={{
          scaleY: [0, 1, 0],
          y: ['-100%', '100%'],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: 'linear',
        }}
      />
      
      <motion.h3 
        className="text-2xl font-bold mb-4 glow-cyan relative z-10"
        whileHover={{ x: 5 }}
        transition={{ duration: 0.2 }}
      >
        {title}
      </motion.h3>
      <p className="text-foreground/70 relative z-10 leading-relaxed flex-1">{description}</p>
      
      {/* Floating dots */}
      <motion.div
        className="absolute bottom-4 right-4 w-2 h-2 rounded-full bg-primary/50"
        animate={{
          scale: [1, 1.5, 1],
          opacity: [0.5, 1, 0.5],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />
      <motion.div
        className="absolute bottom-4 right-8 w-2 h-2 rounded-full bg-accent/50"
        animate={{
          scale: [1, 1.5, 1],
          opacity: [0.5, 1, 0.5],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: 'easeInOut',
          delay: 0.3,
        }}
      />
    </motion.div>
  );
};

export default Home;
