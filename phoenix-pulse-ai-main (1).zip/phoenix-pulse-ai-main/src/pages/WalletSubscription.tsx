import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Crown, Zap, Check } from 'lucide-react';
import { useWalletAuth } from '@/contexts/WalletAuthContext';
import { useWalletSubscription } from '@/hooks/useWalletSubscription';
import { PaymentModal } from '@/components/PaymentModal';
import { motion } from 'framer-motion';

export default function WalletSubscription() {
  const { walletAddress, isAdmin } = useWalletAuth();
  const { subscription, isLoading } = useWalletSubscription();
  const [showPayment, setShowPayment] = useState(false);
  const [selectedTier, setSelectedTier] = useState<'pro' | 'elite'>('pro');

  const plans = [
    {
      name: 'Free',
      price: '$0',
      tier: 'free',
      icon: Zap,
      color: 'from-gray-400 to-gray-600',
      features: [
        '1 Signal Follow Per Day',
        'Basic Market Data',
        'Technical Indicators',
        'Community Support'
      ]
    },
    {
      name: 'Pro',
      price: '$9.99',
      tier: 'pro',
      icon: Zap,
      color: 'from-cyan-400 to-blue-500',
      features: [
        'Unlimited Signal Follows',
        'Advanced Sentiment Tracker',
        'Portfolio AI Insights',
        'Priority Support',
        'Real-time Whale Alerts'
      ]
    },
    {
      name: 'Elite',
      price: '$49.99',
      tier: 'elite',
      icon: Crown,
      color: 'from-yellow-400 to-orange-500',
      features: [
        'All Pro Features',
        'Phoenix Daily 3 AI Picks',
        'AI Trading Bot (Signal + Auto)',
        'MemeCoin Hype Tracker',
        'Token Creator Access',
        'Liquidity Launcher',
        'Telegram/Discord Alerts',
        'Phoenix Approved Badge'
      ]
    }
  ];

  if (!walletAddress) {
    return (
      <div className="min-h-screen pt-24 pb-16 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <h1 className="text-4xl font-bold mb-4">Connect Your Wallet</h1>
          <p className="text-muted-foreground">Please connect your Solana wallet to view subscription plans.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-16 px-4 bg-gradient-to-b from-background via-background to-cyan-950/10">
      <div className="container mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
            Choose Your Power Level
          </h1>
          <p className="text-xl text-muted-foreground">Unlock AI-powered trading features</p>
          
          {subscription && (
            <div className="mt-6 inline-flex items-center gap-2 px-6 py-3 bg-cyan-500/10 border border-cyan-500/30 rounded-xl">
              <Badge className="bg-gradient-to-r from-cyan-400 to-blue-500">
                {subscription.tier.toUpperCase()}
              </Badge>
              <span className="text-sm text-muted-foreground">Current Plan</span>
            </div>
          )}
          
          {isAdmin && (
            <Badge className="ml-3 bg-gradient-to-r from-yellow-400 to-orange-500">
              ADMIN ACCESS
            </Badge>
          )}
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.tier}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className={`relative p-8 h-full border-2 ${
                subscription?.tier === plan.tier
                  ? 'border-cyan-500 shadow-lg shadow-cyan-500/20'
                  : 'border-border'
              } ${plan.tier === 'elite' ? 'bg-gradient-to-b from-yellow-500/5 to-orange-500/5' : ''}`}>
                {subscription?.tier === plan.tier && (
                  <Badge className="absolute top-4 right-4 bg-cyan-500">ACTIVE</Badge>
                )}
                
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-4`}>
                  <plan.icon className="w-8 h-8 text-white" />
                </div>

                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <div className="mb-6">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  {plan.price !== '$0' && <span className="text-muted-foreground">/month</span>}
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>

                {subscription?.tier !== plan.tier && plan.tier !== 'free' && (
                  <Button
                    onClick={() => {
                      setSelectedTier(plan.tier as 'pro' | 'elite');
                      setShowPayment(true);
                    }}
                    className={`w-full bg-gradient-to-r ${plan.color} text-white font-bold hover:opacity-90 transition-opacity`}
                  >
                    Upgrade to {plan.name}
                  </Button>
                )}
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      <PaymentModal
        isOpen={showPayment}
        onClose={() => setShowPayment(false)}
        tier={selectedTier}
      />
    </div>
  );
}
