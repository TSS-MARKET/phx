import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Flame, Lock, Users, Zap, CheckCircle } from "lucide-react";
import phoenixLogo from "@/assets/phx-ai-logo.png";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import { PlatformAvailability } from "@/components/PlatformAvailability";
import { RoadmapTimeline } from "@/components/RoadmapTimeline";
import React from "react";

const distributionData = [
  { name: "Public Sale", value: 40, color: "hsl(var(--primary))" },
  { name: "Team & Advisors", value: 20, color: "hsl(var(--secondary))" },
  { name: "Development", value: 15, color: "hsl(var(--accent))" },
  { name: "Marketing", value: 10, color: "#10b981" },
  { name: "Liquidity Pool", value: 10, color: "#8b5cf6" },
  { name: "Reserve", value: 5, color: "#f59e0b" },
];

const Token = () => {
  const tokenomics = [
    { label: "Total Supply", value: "1,000,000,000 PHX" },
    { label: "Circulating Supply", value: "350,000,000 PHX" },
    { label: "Market Cap", value: "$25,000,000" },
    { label: "Holder Benefits", value: "Premium Access" },
  ];

  const utilities = [
    "Access to premium AI trading signals",
    "Reduced fees on platform transactions",
    "Early access to new features",
    "Exclusive holder-only tools",
    "Governance voting rights",
    "Staking rewards (Coming Soon)",
  ];

  return (
    <div className="min-h-screen pt-24 pb-12">
      <div className="container mx-auto px-4">
        {/* Header with Premium Logo */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <div className="flex justify-center mb-8">
            <motion.div
              animate={{ 
                y: [0, -8, 0],
                scale: [1, 1.02, 1]
              }}
              transition={{ 
                duration: 4, 
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="relative"
            >
              <div className="absolute inset-0 blur-xl bg-primary/20 rounded-full"></div>
              <motion.img
                src={phoenixLogo} 
                alt="Phoenix AI Token" 
                className="w-32 h-32 rounded-full relative z-10 border border-primary/20"
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
              />
            </motion.div>
          </div>
          <motion.h1 
            className="text-5xl md:text-6xl font-black mb-6 glow-orange font-orbitron"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            whileHover={{ scale: 1.05 }}
          >
            <motion.span
              animate={{
                textShadow: [
                  "0 0 20px rgba(251, 146, 60, 0.5)",
                  "0 0 40px rgba(251, 146, 60, 0.8)",
                  "0 0 20px rgba(251, 146, 60, 0.5)",
                ]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              $PHX Token
            </motion.span>
          </motion.h1>
          <p className="text-xl text-foreground/70 max-w-3xl mx-auto">
            The native utility token powering the Phoenix AI ecosystem
          </p>
        </motion.div>

        {/* Platform Availability */}
        <PlatformAvailability />

        {/* Tokenomics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {tokenomics.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
            >
              <Card className="glass-card p-6 text-center hover-glow">
                <div className="text-sm text-muted-foreground mb-2">{item.label}</div>
                <div className="text-2xl font-bold glow-cyan">{item.value}</div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Token Distribution - Enhanced Modern Visualization */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mb-16"
        >
          <Card className="glass-card p-8 max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-8 glow-cyan">Token Distribution</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              {/* 3D Donut Chart */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
              >
                <ResponsiveContainer width="100%" height={400}>
                  <PieChart>
                    <defs>
                      {distributionData.map((entry, index) => (
                        <linearGradient key={`gradient-${index}`} id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor={entry.color} stopOpacity={1}/>
                          <stop offset="100%" stopColor={entry.color} stopOpacity={0.6}/>
                        </linearGradient>
                      ))}
                    </defs>
                    <Pie
                      data={distributionData}
                      cx="50%"
                      cy="50%"
                      outerRadius={140}
                      innerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      animationBegin={0}
                      animationDuration={1500}
                      animationEasing="ease-out"
                      stroke="hsl(var(--background))"
                      strokeWidth={3}
                    >
                      {distributionData.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={`url(#gradient-${index})`}
                          style={{
                            filter: `drop-shadow(0 4px 8px ${entry.color}40)`,
                          }}
                        />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: "hsl(var(--background))", 
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                        color: "hsl(var(--foreground))",
                        padding: "12px"
                      }}
                      labelStyle={{ color: "hsl(var(--foreground))" }}
                      itemStyle={{ color: "hsl(var(--foreground))" }}
                      formatter={(value: number, name: string) => [`${value}%`, name]}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </motion.div>

              {/* Distribution Details */}
              <div className="space-y-4">
                {distributionData.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.1 * index }}
                    className="relative"
                  >
                    <div className="flex items-center justify-between p-4 rounded-lg bg-card/50 border border-border/50 hover:border-border transition-all">
                      <div className="flex items-center gap-3">
                        <motion.div
                          className="w-4 h-4 rounded-full"
                          style={{ background: item.color }}
                          whileHover={{ scale: 1.3 }}
                          transition={{ duration: 0.2 }}
                        />
                        <span className="font-bold text-lg">{item.name}</span>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold" style={{ color: item.color }}>
                          {item.value}%
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {(1000000000 * item.value / 100).toLocaleString()} PHX
                        </div>
                      </div>
                    </div>
                    {/* Progress bar */}
                    <motion.div
                      className="absolute bottom-0 left-0 h-1 rounded-full"
                      style={{ background: item.color }}
                      initial={{ width: 0 }}
                      whileInView={{ width: `${item.value}%` }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.2 + 0.1 * index, duration: 0.8 }}
                    />
                  </motion.div>
                ))}
              </div>
            </div>
          </Card>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-7xl mx-auto mb-16">
          {/* Token Utility */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <Card className="glass-card p-8 h-full">
              <div className="flex items-center gap-3 mb-6">
                <motion.div
                  animate={{
                    rotate: [0, 5, -5, 0],
                    scale: [1, 1.1, 1],
                  }}
                  transition={{ duration: 3, repeat: Infinity }}
                >
                  <Zap className="w-8 h-8 text-primary" />
                </motion.div>
                <h2 className="text-3xl font-bold glow-cyan">Token Utility</h2>
              </div>
              <div className="space-y-4">
                {utilities.map((utility, index) => (
                  <motion.div 
                    key={index} 
                    className="flex items-start gap-3"
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ x: 4, scale: 1.02 }}
                  >
                    <motion.div
                      animate={{
                        scale: [1, 1.2, 1],
                      }}
                      transition={{ 
                        duration: 2, 
                        repeat: Infinity,
                        delay: index * 0.2 
                      }}
                    >
                      <CheckCircle className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    </motion.div>
                    <span className="text-foreground/80">{utility}</span>
                  </motion.div>
                ))}
              </div>
            </Card>
          </motion.div>

          {/* Buy/Verify Section */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <Card className="glass-card p-8 h-full bg-gradient-to-br from-primary/10 to-secondary/10">
              <div className="flex items-center gap-3 mb-6">
                <motion.div
                  animate={{
                    rotate: [0, -10, 10, 0],
                  }}
                  transition={{ duration: 4, repeat: Infinity }}
                >
                  <Lock className="w-8 h-8 text-secondary" />
                </motion.div>
                <h2 className="text-3xl font-bold glow-purple">Holder Benefits</h2>
              </div>
              <motion.p 
                className="text-foreground/70 mb-6"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
              >
                Connect your wallet to verify your $PHX holdings and unlock premium features
              </motion.p>
              <div className="space-y-4">
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.3 }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 font-bold text-lg py-6 neon-border-cyan">
                    Connect Wallet
                  </Button>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.4 }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button variant="outline" className="w-full font-bold text-lg py-6 border-secondary neon-border-purple">
                    Buy $PHX Token
                  </Button>
                </motion.div>
              </div>
              <motion.div 
                className="mt-8 p-4 rounded-lg bg-accent/10 border border-accent/30"
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.5 }}
                whileHover={{ 
                  scale: 1.02,
                  borderColor: "hsl(var(--accent))",
                  transition: { duration: 0.2 }
                }}
              >
                <div className="flex items-start gap-3">
                  <motion.div
                    animate={{
                      scale: [1, 1.3, 1],
                    }}
                    transition={{ duration: 2.5, repeat: Infinity }}
                  >
                    <Users className="w-5 h-5 text-accent mt-1" />
                  </motion.div>
                  <div>
                    <div className="font-bold text-accent mb-1">Join the Community</div>
                    <p className="text-sm text-foreground/70">
                      Connect with thousands of $PHX holders and get exclusive insights
                    </p>
                  </div>
                </div>
              </motion.div>
            </Card>
          </motion.div>
        </div>

        {/* Roadmap */}
        <RoadmapTimeline />

        {/* Token Utility Details */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="mt-16"
        >
          <Card className="glass-card p-12 max-w-5xl mx-auto">
            <motion.h2 
              className="text-4xl font-bold text-center mb-12 glow-cyan"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              animate={{
                textShadow: [
                  "0 0 20px rgba(34, 211, 238, 0.5)",
                  "0 0 40px rgba(34, 211, 238, 0.8)",
                  "0 0 20px rgba(34, 211, 238, 0.5)",
                ]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              Why Hold $PHX?
            </motion.h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                {
                  title: "Exclusive Access",
                  color: "glow-purple",
                  content: "Gain access to premium features including advanced AI trading signals, priority customer support, and early access to new platform features before they're available to the public."
                },
                {
                  title: "Fee Reduction",
                  color: "glow-orange",
                  content: "Enjoy reduced transaction fees on all platform operations. Higher tier holders receive up to 50% discount on trading fees and premium subscriptions."
                },
                {
                  title: "Governance Rights",
                  color: "glow-cyan",
                  content: "Participate in platform governance and vote on important decisions including new feature development, fee structures, and strategic partnerships."
                },
                {
                  title: "Staking Rewards",
                  color: "glow-purple",
                  content: "Stake your $PHX tokens to earn passive income. Upcoming staking platform will offer competitive APY rates with flexible lock-up periods."
                }
              ].map((benefit, index) => (
                <motion.div 
                  key={index}
                  className="space-y-4 p-6 rounded-lg bg-card/30 border border-border/50"
                  initial={{ opacity: 0, y: 30, scale: 0.95 }}
                  whileInView={{ opacity: 1, y: 0, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.15, duration: 0.5 }}
                  whileHover={{ 
                    scale: 1.03,
                    borderColor: "hsl(var(--primary))",
                    boxShadow: "0 8px 30px rgba(251, 146, 60, 0.3)",
                    transition: { duration: 0.3 }
                  }}
                >
                  <h3 className={`text-2xl font-bold ${benefit.color}`}>{benefit.title}</h3>
                  <p className="text-foreground/70">
                    {benefit.content}
                  </p>
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default Token;
