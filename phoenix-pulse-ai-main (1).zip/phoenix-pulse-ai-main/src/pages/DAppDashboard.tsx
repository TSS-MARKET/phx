import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SubscriptionDashboard } from "@/components/SubscriptionDashboard";
import { PhoenixDaily3 } from "@/components/PhoenixDaily3";
import { TradingBot } from "@/components/TradingBot";
import { TokenCreator } from "@/components/TokenCreator";
import { Crown, TrendingUp, Bot, Coins } from "lucide-react";
import { Navigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useState, useEffect } from "react";

export default function DAppDashboard() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user);
      setLoading(false);
    });
  }, []);

  if (loading) return <div className="min-h-screen bg-background flex items-center justify-center"><div className="text-muted-foreground">Loading...</div></div>;
  if (!user) return <Navigate to="/auth" />;

  return (
    <div className="min-h-screen bg-background py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary via-blue-500 to-cyan-400 bg-clip-text text-transparent mb-4">
            Phoenix AI DApp
          </h1>
          <p className="text-muted-foreground">Born from chaos, built for clarity.</p>
        </div>

        <Tabs defaultValue="subscription" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8 bg-background/40 backdrop-blur border border-primary/20">
            <TabsTrigger value="subscription" className="flex items-center gap-2">
              <Crown className="w-4 h-4" />
              Subscription
            </TabsTrigger>
            <TabsTrigger value="daily3" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Daily 3
            </TabsTrigger>
            <TabsTrigger value="trading" className="flex items-center gap-2">
              <Bot className="w-4 h-4" />
              Trading Bot
            </TabsTrigger>
            <TabsTrigger value="token" className="flex items-center gap-2">
              <Coins className="w-4 h-4" />
              Token Creator
            </TabsTrigger>
          </TabsList>

          <TabsContent value="subscription"><SubscriptionDashboard /></TabsContent>
          <TabsContent value="daily3"><PhoenixDaily3 /></TabsContent>
          <TabsContent value="trading"><TradingBot /></TabsContent>
          <TabsContent value="token"><TokenCreator /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
}