import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWalletAuth } from '@/contexts/WalletAuthContext';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Users, TrendingUp, DollarSign, Activity, BarChart3 } from 'lucide-react';

export default function AdminPanel() {
  const { isAdmin, walletAddress } = useWalletAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
    }
  }, [isAdmin, navigate]);

  const { data: stats } = useQuery({
    queryKey: ['admin-stats'],
    queryFn: async () => {
      const [subsData, tradesData, analyticsData] = await Promise.all([
        supabase.from('user_subscriptions').select('*'),
        supabase.from('trading_history').select('*'),
        supabase.from('user_trading_analytics').select('*')
      ]);

      const totalUsers = subsData.data?.length || 0;
      const freeTier = subsData.data?.filter(s => s.tier === 'free').length || 0;
      const proTier = subsData.data?.filter(s => s.tier === 'pro').length || 0;
      const eliteTier = subsData.data?.filter(s => s.tier === 'elite').length || 0;
      
      const totalTrades = tradesData.data?.length || 0;
      const completedTrades = tradesData.data?.filter(t => t.status === 'completed').length || 0;
      
      const totalFees = 0;
      const totalVolume = analyticsData.data?.reduce((sum, a) => sum + (Number(a.total_volume_traded) || 0), 0) || 0;

      return {
        totalUsers,
        freeTier,
        proTier,
        eliteTier,
        totalTrades,
        completedTrades,
        totalFees,
        totalVolume
      };
    },
    enabled: isAdmin,
    refetchInterval: 30000
  });

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen pt-24 pb-16 px-4 bg-gradient-to-b from-background via-background to-yellow-950/10">
      <div className="container mx-auto max-w-7xl">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-4 mb-2">
              <h1 className="text-4xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                Admin Control Panel
              </h1>
              <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold">
                ADMIN MODE
              </Badge>
            </div>
            <p className="text-muted-foreground">Admin Wallet: {walletAddress}</p>
          </div>
          <Button 
            onClick={() => navigate('/admin/dashboard')}
            className="bg-gradient-to-r from-violet-600 to-purple-600"
          >
            <BarChart3 className="w-4 h-4 mr-2" />
            Analytics Dashboard
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="p-6 bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
            <div className="flex items-center justify-between mb-4">
              <Users className="w-8 h-8 text-cyan-400" />
              <Badge className="bg-cyan-500/20 text-cyan-400">USERS</Badge>
            </div>
            <h3 className="text-3xl font-bold mb-1">{stats?.totalUsers || 0}</h3>
            <p className="text-sm text-muted-foreground">Total Users</p>
            <div className="mt-4 space-y-1 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Free:</span>
                <span className="text-cyan-400">{stats?.freeTier || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Pro:</span>
                <span className="text-neon-purple">{stats?.proTier || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Elite:</span>
                <span className="text-yellow-400">{stats?.eliteTier || 0}</span>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/30">
            <div className="flex items-center justify-between mb-4">
              <TrendingUp className="w-8 h-8 text-green-400" />
              <Badge className="bg-green-500/20 text-green-400">TRADES</Badge>
            </div>
            <h3 className="text-3xl font-bold mb-1">{stats?.totalTrades || 0}</h3>
            <p className="text-sm text-muted-foreground">Total Trades</p>
            <div className="mt-4 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Completed:</span>
                <span className="text-green-400">{stats?.completedTrades || 0}</span>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border-yellow-500/30">
            <div className="flex items-center justify-between mb-4">
              <DollarSign className="w-8 h-8 text-yellow-400" />
              <Badge className="bg-yellow-500/20 text-yellow-400">FEES</Badge>
            </div>
            <h3 className="text-3xl font-bold mb-1">${stats?.totalFees.toFixed(2) || '0.00'}</h3>
            <p className="text-sm text-muted-foreground">Total Fees Collected</p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/30">
            <div className="flex items-center justify-between mb-4">
              <Activity className="w-8 h-8 text-purple-400" />
              <Badge className="bg-purple-500/20 text-purple-400">VOLUME</Badge>
            </div>
            <h3 className="text-3xl font-bold mb-1">${stats?.totalVolume.toFixed(2) || '0.00'}</h3>
            <p className="text-sm text-muted-foreground">Total Trading Volume</p>
          </Card>
        </div>

        <Card className="p-6 border-yellow-500/30 bg-gradient-to-br from-yellow-500/5 to-orange-500/5">
          <h2 className="text-2xl font-bold mb-4">Platform Overview</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-2 text-cyan-400">Active Features</h3>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>✓ Wallet-Based Authentication</li>
                <li>✓ Subscription Management</li>
                <li>✓ Phoenix Daily 3 AI Picks</li>
                <li>✓ Trading Bot (Signal Mode)</li>
                <li>✓ Analytics & Tracking</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2 text-yellow-400">Admin Capabilities</h3>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>✓ Real-time Platform Stats</li>
                <li>✓ User Subscription Overview</li>
                <li>✓ Trading Volume Monitoring</li>
                <li>✓ Fee Collection Tracking</li>
                <li>✓ Elite Access (All Features)</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
