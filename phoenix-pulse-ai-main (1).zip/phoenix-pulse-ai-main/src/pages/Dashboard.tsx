import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TrendingUp, TrendingDown, Activity, Zap, Lock } from "lucide-react";
import { useTopCoins, useGlobalMarketData, useTrendingCoins } from "@/hooks/useCoinGecko";
import { Skeleton } from "@/components/ui/skeleton";
import { NewsSection } from "@/components/NewsSection";
import { SocialBuzzSection } from "@/components/SocialBuzzSection";
import TechnicalAnalysis from "@/components/TechnicalAnalysis";
import AIInsights from "@/components/AIInsights";
import { PortfolioTracker } from "@/components/PortfolioTracker";
import { SignalsSection } from "@/components/SignalsSection";
import { WhaleAlertsSection } from "@/components/WhaleAlertsSection";
import { useHoldingsTier } from "@/hooks/useHoldingsTier";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useCoinLogos } from "@/hooks/useCoinLogos";
import { AnimatedCounter } from "@/components/ui/animated-counter";
import { useCoinSparkline } from "@/hooks/useCoinSparkline";
import { Sparkline } from "@/components/ui/sparkline";
import { PerformanceChart } from "@/components/ui/performance-chart";
import { MarketSentimentGauge } from "@/components/ui/market-sentiment-gauge";
import { ScrollAnimated3D } from "@/components/ScrollAnimated3D";
import { Tilt3DCard } from "@/components/Tilt3DCard";
import { ParticleHover } from "@/components/ui/particle-hover";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import { useCoinDetails } from "@/hooks/useCoinDetails";
import { PriceAlerts } from "@/components/PriceAlerts";
import { Watchlist } from "@/components/Watchlist";

const Dashboard = () => {
  const [selectedTab, setSelectedTab] = useState("overview");
  const { tier, hasAccess } = useHoldingsTier();
  const navigate = useNavigate();
  
  const { data: topCoinsData, isLoading: coinsLoading } = useTopCoins();
  const { data: globalData, isLoading: globalLoading } = useGlobalMarketData();
  const { data: trendingData, isLoading: trendingLoading } = useTrendingCoins();
  
  const coinIds = useMemo(() => {
    const ids: string[] = [];
    if (topCoinsData) {
      topCoinsData
        .filter((coin: any) => coin.symbol.toLowerCase() !== 'usdt' && coin.symbol.toLowerCase() !== 'usdc')
        .slice(0, 5)
        .forEach((coin: any) => ids.push(coin.id));
    }
    if (trendingData?.coins) {
      trendingData.coins.slice(0, 6).forEach((item: any) => ids.push(item.item.id));
    }
    return ids;
  }, [topCoinsData, trendingData]);
  
  const { data: coinLogos } = useCoinLogos(coinIds);

  return (
    <div className="min-h-screen pt-24 pb-12">
      <div className="container mx-auto px-4">
        {/* Holdings Banner */}
        {tier === "none" && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <Card className="glass-card p-6 border-2 border-accent/50 bg-gradient-to-r from-accent/10 to-secondary/10">
              <div className="flex items-center justify-between flex-wrap gap-4">
                <div className="flex items-center gap-3">
                  <Lock className="w-6 h-6 text-accent" />
                  <div>
                    <h3 className="text-lg font-bold text-white">Unlock Premium Features</h3>
                    <p className="text-sm text-white/70">
                      Connect your wallet and verify $PHX holdings to access advanced features
                    </p>
                  </div>
                </div>
                <Button
                  onClick={() => navigate("/holdings")}
                  className="bg-gradient-to-r from-accent to-secondary hover:opacity-90 font-bold"
                >
                  Verify Holdings
                </Button>
              </div>
            </Card>
          </motion.div>
        )}

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-black mb-4 text-white">
            Trading Dashboard
          </h1>
          <p className="text-xl text-white/90">
            Real-time market data powered by AI analysis
          </p>
        </motion.div>

        {/* Market Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {globalLoading ? (
            <>
              {[...Array(4)].map((_, i) => (
                <Skeleton key={i} className="h-32 rounded-xl" />
              ))}
            </>
          ) : (
            <>
              <ScrollAnimated3D delay={0}>
                <Tilt3DCard scale={1.02}>
                  <StatCard
                    title="Market Cap"
                    value={(globalData?.data?.total_market_cap?.usd / 1e12).toFixed(2)}
                    change={globalData?.data?.market_cap_change_percentage_24h_usd || 0}
                    icon={<Activity />}
                    suffix="T"
                    prefix="$"
                  />
                </Tilt3DCard>
              </ScrollAnimated3D>
              <ScrollAnimated3D delay={0.1}>
                <Tilt3DCard scale={1.02}>
                  <StatCard
                    title="24h Volume"
                    value={(globalData?.data?.total_volume?.usd / 1e9).toFixed(2)}
                    change={globalData?.data?.total_volume_change_24h_usd || 0}
                    icon={<Zap />}
                    suffix="B"
                    prefix="$"
                  />
                </Tilt3DCard>
              </ScrollAnimated3D>
              <ScrollAnimated3D delay={0.2}>
                <Tilt3DCard scale={1.02}>
                  <StatCard
                    title="Bitcoin Dominance"
                    value={globalData?.data?.market_cap_percentage?.btc?.toFixed(2)}
                    icon={<TrendingUp />}
                    suffix="%"
                    dominance
                  />
                </Tilt3DCard>
              </ScrollAnimated3D>
              <ScrollAnimated3D delay={0.3}>
                <Tilt3DCard scale={1.02}>
                  <StatCard
                    title="ETH Dominance"
                    value={globalData?.data?.market_cap_percentage?.eth?.toFixed(2)}
                    icon={<Activity />}
                    subtitle={`Market Share`}
                    suffix="%"
                    dominance
                  />
                </Tilt3DCard>
              </ScrollAnimated3D>
            </>
          )}
        </div>

        {/* Main Content Tabs */}
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
          <TabsList className="glass-card mb-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="signals">Signals</TabsTrigger>
            <TabsTrigger value="whale">Whale Alerts</TabsTrigger>
            <TabsTrigger value="news">News & Sentiment</TabsTrigger>
            <TabsTrigger value="analysis">AI Analysis</TabsTrigger>
            <TabsTrigger value="memecoins">Memecoins</TabsTrigger>
            <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
              className="space-y-6"
            >
              {/* Market Sentiment Gauge */}
              <MarketSentimentGauge />

              {/* Market Overview Summary */}
              <Card className="glass-card p-8 animated-bg-vibrant">
                <h3 className="text-3xl font-bold mb-6 text-white">Market Overview</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <motion.div 
                    className="p-6 rounded-xl bg-gradient-to-br from-primary/10 to-transparent border border-primary/20 relative overflow-hidden cursor-pointer"
                    whileHover={{ 
                      scale: 1.05,
                      y: -8,
                      borderColor: "rgba(79, 209, 197, 0.6)",
                      boxShadow: "0 12px 40px rgba(79, 209, 197, 0.4)",
                    }}
                    transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
                  >
                    <motion.div 
                      className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/20 to-primary/0"
                      initial={{ x: "-100%" }}
                      whileHover={{ x: "100%" }}
                      transition={{ duration: 0.8, ease: "easeInOut" }}
                    />
                    <div className="relative z-10">
                      <div className="text-sm text-white/70 mb-2">Total Market Cap</div>
                      <div className="text-2xl font-bold glow-cyan">
                        $<AnimatedCounter value={globalData?.data?.total_market_cap?.usd / 1e12} decimals={2} />T
                      </div>
                      <div className={`text-sm mt-2 ${((globalData?.data?.market_cap_change_percentage_24h_usd || 0) >= 0) ? 'text-primary glow-cyan' : 'text-destructive'}`}>
                        24h Change: {(globalData?.data?.market_cap_change_percentage_24h_usd || 0) >= 0 ? '+' : ''}
                        {globalData?.data?.market_cap_change_percentage_24h_usd?.toFixed(2)}%
                      </div>
                    </div>
                  </motion.div>
                  
                  <motion.div 
                    className="p-6 rounded-xl bg-gradient-to-br from-primary/10 to-transparent border border-primary/20 relative overflow-hidden cursor-pointer"
                    whileHover={{ 
                      scale: 1.05,
                      y: -8,
                      borderColor: "rgba(79, 209, 197, 0.6)",
                      boxShadow: "0 12px 40px rgba(79, 209, 197, 0.4)",
                    }}
                    transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
                  >
                    <motion.div 
                      className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/20 to-primary/0"
                      initial={{ x: "-100%" }}
                      whileHover={{ x: "100%" }}
                      transition={{ duration: 0.8, ease: "easeInOut" }}
                    />
                    <div className="relative z-10">
                      <div className="text-sm text-white/70 mb-2">Market Sentiment</div>
                      <div className={`text-2xl font-bold ${
                        globalData?.data?.market_cap_change_percentage_24h_usd > 0 
                          ? 'text-primary glow-cyan' 
                          : 'text-red-500'
                      }`}>
                        {globalData?.data?.market_cap_change_percentage_24h_usd > 0 ? 'Bullish' : 'Bearish'}
                      </div>
                      <div className="text-sm text-primary glow-cyan mt-2">
                        BTC Dominance: {globalData?.data?.market_cap_percentage?.btc?.toFixed(2)}%
                      </div>
                    </div>
                  </motion.div>
                  
                  <motion.div 
                    className="p-6 rounded-xl bg-gradient-to-br from-primary/10 to-transparent border border-primary/20 relative overflow-hidden cursor-pointer"
                    whileHover={{ 
                      scale: 1.05,
                      y: -8,
                      borderColor: "rgba(79, 209, 197, 0.6)",
                      boxShadow: "0 12px 40px rgba(79, 209, 197, 0.4)",
                    }}
                    transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
                  >
                    <motion.div 
                      className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/20 to-primary/0"
                      initial={{ x: "-100%" }}
                      whileHover={{ x: "100%" }}
                      transition={{ duration: 0.8, ease: "easeInOut" }}
                    />
                    <div className="relative z-10">
                      <div className="text-sm text-white/70 mb-2">Market Season</div>
                      <div className="text-2xl font-bold glow-cyan">
                        {globalData?.data?.market_cap_percentage?.btc > 60 ? 'Bitcoin Season' : 'Altcoin Season'}
                      </div>
                      <div className="text-sm text-primary glow-cyan mt-2">
                        ETH Dominance: {globalData?.data?.market_cap_percentage?.eth?.toFixed(2)}%
                      </div>
                    </div>
                  </motion.div>
                </div>
              </Card>
            </motion.div>

            {/* Top Coins */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
            <Card className="glass-card p-6 animated-bg-purple">
              <h3 className="text-2xl font-bold mb-4 text-white">Top Cryptocurrencies</h3>
                <div className="space-y-4">
                {coinsLoading ? (
                  [...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-20 rounded-lg" />
                  ))
                ) : (
                  topCoinsData
                    ?.filter((coin: any) => coin.symbol.toLowerCase() !== 'usdt' && coin.symbol.toLowerCase() !== 'usdc')
                    .slice(0, 5)
                    .map((coin: any) => (
                      <CoinRow
                        key={coin.id}
                        name={coin.name}
                        symbol={coin.symbol.toUpperCase()}
                        price={coin.current_price}
                        change={coin.price_change_percentage_24h}
                        volume={`$${(coin.total_volume / 1e9).toFixed(2)}B`}
                        logo={coinLogos?.[coin.id]}
                        coinId={coin.id}
                      />
                    ))
                )}
              </div>
            </Card>
            </motion.div>

            {/* Trending Coins */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
            <Card className="glass-card p-6 animated-bg-purple">
              <h3 className="text-2xl font-bold mb-4 text-white">Trending Now</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {trendingLoading ? (
                  [...Array(3)].map((_, i) => (
                    <Skeleton key={i} className="h-24 rounded-lg" />
                  ))
                ) : (
                  trendingData?.coins?.slice(0, 6).map((item: any, index: number) => {
                    const TrendingCard = ({ children }: { children: React.ReactNode }) => {
                      const { data: coinDetails } = useCoinDetails(item.item.id);
                      
                      return (
                        <HoverCard openDelay={200}>
                          <HoverCardTrigger asChild>
                            <motion.div
                              whileHover={{ 
                                scale: 1.05,
                                y: -4,
                                borderColor: "rgba(79, 209, 197, 0.8)",
                                boxShadow: "0 12px 40px rgba(79, 209, 197, 0.5)",
                              }}
                              transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
                              className="p-4 rounded-lg bg-muted/30 border border-primary/20 transition-all cursor-pointer relative overflow-hidden"
                            >
                              <motion.div 
                                className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/20 to-primary/0"
                                initial={{ x: "-100%" }}
                                whileHover={{ x: "100%" }}
                                transition={{ duration: 0.8, ease: "easeInOut" }}
                              />
                              {children}
                            </motion.div>
                          </HoverCardTrigger>
                          <HoverCardContent className="w-80 bg-card/95 backdrop-blur-xl border-primary/30 p-4 z-[100]">
                            <div className="space-y-3">
                              <div className="flex items-center gap-3">
                                {coinLogos?.[item.item.id] && (
                                  <img src={coinLogos[item.item.id]} alt={item.item.name} className="w-10 h-10 rounded-full" />
                                )}
                                <div>
                                  <div className="font-bold text-lg">{item.item.name}</div>
                                  <div className="text-sm text-muted-foreground">{item.item.symbol}</div>
                                </div>
                              </div>
                              
                              {coinDetails ? (
                                <div className="grid grid-cols-2 gap-3 text-sm">
                                  <div className="space-y-1">
                                    <div className="text-muted-foreground">Market Cap</div>
                                    <div className="font-semibold">
                                      ${(coinDetails.market_cap / 1e9).toFixed(2)}B
                                    </div>
                                  </div>
                                  <div className="space-y-1">
                                    <div className="text-muted-foreground">24h Volume</div>
                                    <div className="font-semibold">
                                      ${(coinDetails.total_volume / 1e9).toFixed(2)}B
                                    </div>
                                  </div>
                                  <div className="space-y-1">
                                    <div className="text-muted-foreground">24h High</div>
                                    <div className="font-semibold text-primary">
                                      ${coinDetails.high_24h?.toLocaleString()}
                                    </div>
                                  </div>
                                  <div className="space-y-1">
                                    <div className="text-muted-foreground">24h Low</div>
                                    <div className="font-semibold text-red-500">
                                      ${coinDetails.low_24h?.toLocaleString()}
                                    </div>
                                  </div>
                                  <div className="space-y-1">
                                    <div className="text-muted-foreground">Market Rank</div>
                                    <div className="font-semibold text-primary">
                                      #{item.item.market_cap_rank}
                                    </div>
                                  </div>
                                  <div className="space-y-1">
                                    <div className="text-muted-foreground">24h Change</div>
                                    <div className={`font-bold ${coinDetails.price_change_percentage_24h >= 0 ? "text-primary" : "text-red-500"}`}>
                                      {coinDetails.price_change_percentage_24h >= 0 ? '+' : ''}
                                      {coinDetails.price_change_percentage_24h?.toFixed(2)}%
                                    </div>
                                  </div>
                                </div>
                              ) : (
                                <div className="text-sm text-muted-foreground">Loading details...</div>
                              )}
                            </div>
                          </HoverCardContent>
                        </HoverCard>
                      );
                    };

                    return (
                      <TrendingCard key={item.item.id}>
                        <div className="flex items-center gap-3 mb-2 relative z-10">
                          {coinLogos?.[item.item.id] && (
                            <motion.img 
                              src={coinLogos[item.item.id]} 
                              alt={item.item.name} 
                              className="w-8 h-8 rounded-full" 
                              whileHover={{ scale: 1.2, rotate: 5 }}
                              transition={{ duration: 0.3 }}
                            />
                          )}
                          <div>
                            <div className="font-bold text-white">{item.item.name}</div>
                            <div className="text-sm text-white/60">{item.item.symbol}</div>
                          </div>
                        </div>
                        <div className="text-xs text-primary glow-cyan relative z-10">Rank #{item.item.market_cap_rank}</div>
                      </TrendingCard>
                    );
                  })
                )}
              </div>
            </Card>
            </motion.div>
          </TabsContent>

          <TabsContent value="signals">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
            >
              <SignalsSection />
            </motion.div>
          </TabsContent>

          <TabsContent value="whale">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
            >
              <WhaleAlertsSection />
            </motion.div>
          </TabsContent>

          <TabsContent value="news">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* AI Sentiment */}
                <Card className="glass-card p-6">
                  <h3 className="text-2xl font-bold mb-4 glow-purple">AI Market Sentiment</h3>
                  <div className="space-y-4">
                    <SentimentBar label="Bullish" percentage={65} color="primary" />
                    <SentimentBar label="Neutral" percentage={25} color="secondary" />
                    <SentimentBar label="Bearish" percentage={10} color="accent" />
                  </div>
                  <div className="mt-6 p-4 rounded-lg bg-primary/10 border border-primary/30">
                    <p className="text-sm text-white/80">
                      <span className="font-bold text-primary">AI Analysis:</span> Market showing strong bullish signals 
                      with increased volume and positive sentiment across major assets.
                    </p>
                  </div>
                </Card>

                {/* News via API */}
                <NewsSection />
              </div>
            </motion.div>
          </TabsContent>

          <TabsContent value="analysis">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
              className="space-y-6"
            >
              <TechnicalAnalysis />
              <AIInsights />
            </motion.div>
          </TabsContent>

          <TabsContent value="memecoins">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
              className="space-y-6"
            >
              <SocialBuzzSection />
            </motion.div>
          </TabsContent>

          <TabsContent value="portfolio">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
              className="space-y-6"
            >
              <PortfolioTracker />
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <PriceAlerts />
                <Watchlist />
              </div>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, change, icon, subtitle, prefix = '', suffix = '', dominance = false, className = '' }: any) => (
  <motion.div 
    layout
    className={`glass-card p-6 rounded-xl relative overflow-hidden group border border-primary/30 shadow-[0_0_30px_rgba(79,209,197,0.15)] hover:shadow-[0_0_50px_rgba(79,209,197,0.35)] transition-all duration-500 ease-out ${className || 'h-32'} flex flex-col justify-between`}
    whileHover={{ scale: 1.02 }}
    transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
  >
    <motion.div 
      className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 rounded-xl"
      animate={{
        opacity: [0.3, 0.6, 0.3],
      }}
      transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
    />

    <div className="flex items-start justify-between mb-2 relative z-10">
      <div className="text-white/70 text-sm font-medium">{title}</div>
      <motion.div 
        className="text-primary"
        whileHover={{ scale: 1.2, rotate: 10 }}
        animate={{
          scale: [1, 1.05, 1],
        }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
      >
        {icon}
      </motion.div>
    </div>
    <motion.div 
      className={`text-2xl md:text-3xl font-bold mb-1 relative z-10 ${dominance ? 'text-primary glow-cyan' : 'glow-cyan'}`}
      initial={{ scale: 0.9 }}
      animate={{ scale: 1 }}
      transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
    >
      {prefix}<AnimatedCounter value={value} decimals={2} />{suffix}
    </motion.div>
    {subtitle && <div className="text-xs text-white/60 relative z-10">{subtitle}</div>}
    {typeof change === 'number' && (
      <div className={`flex items-center gap-1 text-xs relative z-10 ${change >= 0 ? 'text-primary glow-cyan' : 'text-destructive'}`}>
        {change >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
        {change >= 0 ? '+' : ''}{change.toFixed(2)}%
      </div>
    )}
  </motion.div>
);

const CoinRow = ({ name, symbol, price, change, volume, logo, coinId }: any) => {
  const { data: sparklineData } = useCoinSparkline(coinId || symbol.toLowerCase());
  const { data: coinDetails } = useCoinDetails(coinId || symbol.toLowerCase());
  const [isHovered, setIsHovered] = useState(false);
  
  return (
    <HoverCard openDelay={200} closeDelay={100}>
      <HoverCardTrigger asChild>
        <motion.div 
          className="flex items-center justify-between p-4 rounded-lg bg-muted/30 relative overflow-hidden border border-transparent cursor-pointer"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          whileHover={{ 
            scale: 1.03,
            y: -4,
            backgroundColor: "rgba(79, 209, 197, 0.1)",
            borderColor: "rgba(79, 209, 197, 0.5)",
            boxShadow: "0 8px 32px rgba(79, 209, 197, 0.3), 0 0 0 1px rgba(79, 209, 197, 0.2)",
          }}
          transition={{ 
            duration: 0.3,
            ease: [0.23, 1, 0.32, 1]
          }}
        >
          <ParticleHover isHovered={isHovered} particleCount={12} />
          
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/10 to-primary/0"
            initial={{ x: "-100%" }}
            whileHover={{ x: "100%" }}
            transition={{ duration: 0.6, ease: "easeInOut" }}
          />
          
          <div className="flex items-center gap-3 relative z-10">
            {logo && (
              <motion.div
                whileHover={{ scale: 1.1, rotate: 5 }}
                transition={{ duration: 0.2 }}
              >
                <img 
                  src={logo} 
                  alt={name} 
                  className="w-10 h-10 rounded-full ring-2 ring-primary/20 hover:ring-primary/60 transition-all"
                />
              </motion.div>
            )}
            <div>
              <div className="font-bold text-white">{name}</div>
              <div className="text-sm text-white/60">{symbol}</div>
            </div>
          </div>
          
          {sparklineData && sparklineData.length > 0 && (
            <div className="mx-4 relative z-10">
              <Sparkline data={sparklineData.slice(-24)} height={40} width={100} />
            </div>
          )}
          
          <div className="text-right relative z-10">
            <div className="font-bold text-white">$<AnimatedCounter value={price} decimals={2} /></div>
            <div className={`text-sm font-semibold ${change >= 0 ? "text-primary glow-cyan" : "text-destructive"}`}>
              {change >= 0 ? "+" : ""}{change.toFixed(2)}%
            </div>
          </div>
        </motion.div>
      </HoverCardTrigger>
      
      <HoverCardContent className="w-80 glass-card border-primary/30" side="top">
        <div className="space-y-3">
          <div className="flex items-center gap-3 pb-3 border-b border-primary/20">
            {logo && <img src={logo} alt={name} className="w-12 h-12 rounded-full" />}
            <div>
              <h4 className="text-lg font-bold text-white">{name}</h4>
              <p className="text-sm text-white/60">{symbol}</p>
            </div>
          </div>
          
          {coinDetails && (
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="p-2 rounded bg-muted/30">
                <div className="text-white/60 text-xs mb-1">Market Cap</div>
                <div className="font-bold text-primary">
                  ${(coinDetails.market_cap / 1e9).toFixed(2)}B
                </div>
              </div>
              
              <div className="p-2 rounded bg-muted/30">
                <div className="text-white/60 text-xs mb-1">24h Volume</div>
                <div className="font-bold text-primary">
                  ${(coinDetails.total_volume / 1e9).toFixed(2)}B
                </div>
              </div>
              
              <div className="p-2 rounded bg-muted/30">
                <div className="text-white/60 text-xs mb-1">24h High</div>
                <div className="font-bold text-white">
                  ${coinDetails.high_24h.toLocaleString()}
                </div>
              </div>
              
              <div className="p-2 rounded bg-muted/30">
                <div className="text-white/60 text-xs mb-1">24h Low</div>
                <div className="font-bold text-white">
                  ${coinDetails.low_24h.toLocaleString()}
                </div>
              </div>
              
              <div className="p-2 rounded bg-muted/30 col-span-2">
                <div className="text-white/60 text-xs mb-1">Circulating Supply</div>
                <div className="font-bold text-white">
                  {(coinDetails.circulating_supply / 1e6).toFixed(2)}M {symbol}
                </div>
              </div>
            </div>
          )}
        </div>
      </HoverCardContent>
    </HoverCard>
  );
};

const SentimentBar = ({ label, percentage, color }: any) => (
  <motion.div
    className="p-3 rounded-lg border border-transparent cursor-pointer relative overflow-hidden"
    whileHover={{ 
      scale: 1.02,
      y: -2,
      backgroundColor: "rgba(79, 209, 197, 0.05)",
      borderColor: "rgba(79, 209, 197, 0.3)",
      boxShadow: "0 4px 20px rgba(79, 209, 197, 0.2)",
    }}
    transition={{ 
      duration: 0.3,
      ease: [0.23, 1, 0.32, 1]
    }}
  >
    <motion.div 
      className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/5 to-primary/0"
      initial={{ x: "-100%" }}
      whileHover={{ x: "100%" }}
      transition={{ duration: 0.5, ease: "easeInOut" }}
    />
    
    <div className="relative z-10">
      <div className="flex justify-between mb-2">
        <span className="text-sm font-medium text-white">{label}</span>
        <motion.span 
          className="text-sm text-white/80 font-bold"
          whileHover={{ scale: 1.1, color: "rgba(79, 209, 197, 1)" }}
        >
          {percentage}%
        </motion.span>
      </div>
      <div className="w-full bg-muted rounded-full h-2.5 overflow-hidden">
        <motion.div
          className={`h-2.5 rounded-full bg-${color}`}
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          whileHover={{ height: "12px" }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
      </div>
    </div>
  </motion.div>
);

export default Dashboard;