import { motion } from "framer-motion";
import { HoldingsVerification } from "@/components/HoldingsVerification";
import { useHoldingsTier } from "@/hooks/useHoldingsTier";
import { Card } from "@/components/ui/card";
import { Shield } from "lucide-react";

const Holdings = () => {
  const { updateTier } = useHoldingsTier();

  return (
    <div className="min-h-screen pt-24 pb-12">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="flex justify-center mb-4">
            <Shield className="w-16 h-16 text-primary" />
          </div>
          <h1 className="text-5xl md:text-6xl font-black mb-4 glow-cyan">
            Holdings Verification
          </h1>
          <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
            Connect your wallet to verify your $PHX holdings and unlock premium features
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <HoldingsVerification onConnect={updateTier} />
        </motion.div>

        {/* Information Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-12 max-w-4xl mx-auto"
        >
          <Card className="glass-card p-8">
            <h2 className="text-2xl font-bold mb-4 glow-purple">How It Works</h2>
            <div className="space-y-4 text-foreground/80">
              <p>
                1. <strong>Connect Your Wallet:</strong> Use the demo wallet connection to simulate holding $PHX tokens.
              </p>
              <p>
                2. <strong>Verify Holdings:</strong> The system will automatically detect your $PHX balance and assign you the appropriate tier.
              </p>
              <p>
                3. <strong>Unlock Features:</strong> Based on your tier, you'll gain access to different platform features:
              </p>
              <ul className="list-disc list-inside pl-4 space-y-2">
                <li><strong>Basic (500+ PHX):</strong> Essential AI analysis and daily signals</li>
                <li><strong>Premium (2,500+ PHX):</strong> Advanced analytics and real-time signals</li>
                <li><strong>Elite (12,500+ PHX):</strong> VIP features and priority support</li>
              </ul>
              <p className="text-sm text-muted-foreground mt-6">
                Note: Token contract address will be announced upon launch. Demo mode allows you to preview the system.
              </p>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default Holdings;
