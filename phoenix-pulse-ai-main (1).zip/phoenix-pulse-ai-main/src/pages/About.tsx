import React from "react";
import { Card } from "@/components/ui/card";
import { Target, Rocket, Heart, Brain, Zap, Shield, TrendingUp, Code, Lightbulb, Users, Award, Sparkles } from "lucide-react";
import { FaTelegram, FaTwitter, FaInstagram } from "react-icons/fa";

const About = () => {
  return (
    <div className="min-h-screen pt-24 pb-12 overflow-hidden">
      <div className="container mx-auto px-4 fade-in-up">
        {/* Creator Section - Premium Shiny */}
        <div className="max-w-5xl mx-auto mb-20 fade-in-scale">
          <Card className="premium-card glass-card p-12 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500/10 to-transparent animate-gradient-xy" />
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-purple-500/10 to-accent/20 animate-gradient-xy opacity-50" />
            
            <div className="relative z-10">
              <div className="flex justify-center mb-8">
                <div className="relative icon-glow">
                  <Award className="w-24 h-24 text-primary" />
                  <div className="absolute inset-0 bg-primary/20 rounded-full blur-xl animate-pulse-glow" />
                </div>
              </div>

              <h1 className="text-5xl md:text-6xl font-black text-center mb-6 glow-purple">
                Meet the Creator
              </h1>

              <div className="text-center mb-8">
                <h2 className="text-4xl font-bold mb-2 bg-gradient-to-r from-cyan-500 to-purple-500 bg-clip-text text-transparent">
                  Tanishq Saluja
                </h2>
                <p className="text-xl text-muted-foreground mb-6">16-Year-Old Visionary Developer</p>
                
                <div className="flex justify-center gap-4 mb-8 flex-wrap">
                  <div className="glass-card px-4 py-2 rounded-full border border-primary/30 scale-hover">
                    <span className="text-sm font-semibold">🚀 AI Enthusiast</span>
                  </div>
                  <div className="glass-card px-4 py-2 rounded-full border border-accent/30 scale-hover">
                    <span className="text-sm font-semibold">⛓️ Blockchain Developer</span>
                  </div>
                  <div className="glass-card px-4 py-2 rounded-full border border-purple-500/30 scale-hover">
                    <span className="text-sm font-semibold">📈 Crypto Trader</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4 text-center max-w-3xl mx-auto">
                <p className="text-lg text-foreground/80 leading-relaxed">
                  At just 16 years old, Tanishq Saluja is revolutionizing the crypto space with Phoenix AI. 
                  Combining a passion for artificial intelligence, blockchain technology, and financial markets, 
                  Tanishq built Phoenix AI to bridge the gap between complex trading strategies and everyday users.
                </p>
                <p className="text-lg text-foreground/80 leading-relaxed">
                  Starting his coding journey at age 12, Tanishq has mastered multiple programming languages, 
                  AI frameworks, and blockchain protocols. Phoenix AI represents the culmination of years of 
                  dedication to creating tools that democratize access to advanced trading technology.
                </p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
                <StatCard number="4+" label="Years Coding" />
                <StatCard number="10+" label="Projects Built" />
                <StatCard number="5+" label="AI Models Trained" />
                <StatCard number="1" label="Revolutionary Platform" />
              </div>
            </div>
          </Card>
        </div>

        {/* Phoenix AI Story */}
        <div className="text-center mb-16 fade-in-up">
          <h2 className="text-5xl md:text-6xl font-black mb-6 glow-cyan inline-flex items-center gap-4 justify-center flex-wrap">
            The Phoenix AI Story <span className="text-6xl">🐦‍🔥</span>
          </h2>
          <p className="text-xl text-foreground/70 max-w-3xl mx-auto">
            From Ashes to Intelligence - Rising Above the Noise
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-7xl mx-auto mb-20 fade-in-up">
          <Card className="premium-card glass-card p-8 h-full relative overflow-hidden group hover:shadow-[0_0_30px_rgba(6,182,212,0.3)] transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500/10 to-transparent animate-gradient-xy" />
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-6">
                <Target className="w-8 h-8 text-primary" />
                <h2 className="text-3xl font-bold glow-cyan">Our Mission</h2>
              </div>
              <p className="text-foreground/80 leading-relaxed mb-4">
                Phoenix AI was born from a vision to democratize cryptocurrency trading through 
                artificial intelligence. We believe that everyone deserves access to professional-grade 
                trading tools and insights.
              </p>
              <p className="text-foreground/80 leading-relaxed">
                By combining cutting-edge AI technology with real-time market data, we're making 
                crypto trading smarter, faster, and more accessible to traders of all levels.
              </p>
            </div>
          </Card>

          <Card className="premium-card glass-card p-8 h-full relative overflow-hidden group hover:shadow-[0_0_30px_rgba(251,146,60,0.3)] transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-orange-500/10 to-transparent animate-gradient-xy" />
            <div className="absolute inset-0 bg-gradient-to-br from-accent/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-6">
                <Rocket className="w-8 h-8 text-accent" />
                <h2 className="text-3xl font-bold glow-orange">Our Vision</h2>
              </div>
              <p className="text-foreground/80 leading-relaxed mb-4">
                To become the world's most trusted AI-powered cryptocurrency trading platform, 
                where human intuition meets artificial intelligence.
              </p>
              <p className="text-foreground/80 leading-relaxed">
                We're building a future where trading decisions are enhanced by AI, risks are 
                minimized through intelligent analysis, and opportunities are maximized through 
                real-time insights.
              </p>
            </div>
          </Card>
        </div>

        {/* Technology Stack */}
        <div className="mb-20 fade-in-up">
          <h2 className="text-4xl font-bold text-center mb-12 glow-purple">Powered by Cutting-Edge Technology</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
            <TechCard icon={<Brain className="w-10 h-10" />} title="Advanced AI Models" description="Leveraging state-of-the-art machine learning algorithms for market prediction" />
            <TechCard icon={<Zap className="w-10 h-10" />} title="Real-Time Analysis" description="Lightning-fast processing of market data for instant insights" />
            <TechCard icon={<Shield className="w-10 h-10" />} title="Secure Architecture" description="Bank-grade security protecting your data and investments" />
            <TechCard icon={<TrendingUp className="w-10 h-10" />} title="Predictive Analytics" description="AI-powered forecasting to stay ahead of market trends" />
            <TechCard icon={<Code className="w-10 h-10" />} title="Open Integration" description="Seamless connection with major exchanges and wallets" />
            <TechCard icon={<Lightbulb className="w-10 h-10" />} title="Smart Insights" description="Actionable intelligence delivered in real-time" />
          </div>
        </div>

        {/* Values Section */}
        <div className="max-w-7xl mx-auto mb-20 fade-in-up">
          <h2 className="text-4xl font-bold text-center mb-12 glow-cyan">Our Core Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: <Heart className="w-12 h-12" />, title: "User First", description: "Every feature is designed with our users in mind, prioritizing simplicity and effectiveness", gradient: "from-red-500/20 to-pink-500/20" },
              { icon: <Target className="w-12 h-12" />, title: "Accuracy", description: "We leverage the latest AI models to provide the most accurate market predictions and analysis", gradient: "from-primary/20 to-cyan-500/20" },
              { icon: <Rocket className="w-12 h-12" />, title: "Innovation", description: "Constantly pushing boundaries to bring cutting-edge technology to crypto trading", gradient: "from-accent/20 to-orange-500/20" }
            ].map((value, index) => (
              <Card key={index} className="premium-card glass-card p-8 text-center h-full group scale-hover">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500/10 to-transparent animate-gradient-xy" />
                <div className={`absolute inset-0 bg-gradient-to-br ${value.gradient} opacity-0 group-hover:opacity-100 transition-opacity rounded-lg`} />
                <div className="relative z-10">
                  <div className="flex justify-center mb-6 text-primary icon-rotate-hover">{value.icon}</div>
                  <h3 className="text-2xl font-bold mb-4 glow-cyan">{value.title}</h3>
                  <p className="text-foreground/70 leading-relaxed">{value.description}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Community Section */}
        <div className="max-w-5xl mx-auto mb-20 fade-in-scale">
          <Card className="premium-card glass-card p-12 text-center bg-gradient-to-br from-primary/10 via-purple-500/10 to-accent/10 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/10 to-transparent animate-gradient-xy" />
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-50 animate-gradient-shift" />
            <div className="relative z-10">
              <Users className="w-16 h-16 text-primary mx-auto mb-6" />
              <h2 className="text-4xl font-bold mb-6 glow-cyan">Join the Phoenix Community</h2>
              <p className="text-xl text-foreground/80 mb-8 max-w-3xl mx-auto leading-relaxed">
                Become part of a growing community of traders, developers, and crypto enthusiasts 
                who are shaping the future of intelligent trading. Together, we're rising from 
                the ashes to create something extraordinary.
              </p>
              
              <div className="flex justify-center gap-6 mb-8">
                <a href="https://twitter.com/phoenixai" target="_blank" rel="noopener noreferrer" className="glass-card p-4 rounded-full border border-primary/30 hover:border-primary/60 hover:shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all scale-hover">
                  <FaTwitter className="w-8 h-8 text-primary" />
                </a>
                <a href="https://t.me/phoenixai" target="_blank" rel="noopener noreferrer" className="glass-card p-4 rounded-full border border-cyan-500/30 hover:border-cyan-500/60 hover:shadow-[0_0_20px_rgba(34,211,238,0.4)] transition-all scale-hover">
                  <FaTelegram className="w-8 h-8 text-cyan-400" />
                </a>
                <a href="https://instagram.com/phoenixai" target="_blank" rel="noopener noreferrer" className="glass-card p-4 rounded-full border border-purple-500/30 hover:border-purple-500/60 hover:shadow-[0_0_20px_rgba(168,85,247,0.4)] transition-all scale-hover">
                  <FaInstagram className="w-8 h-8 text-purple-400" />
                </a>
              </div>
            </div>
          </Card>
        </div>

        {/* CTA with Phoenix & Revolving Cards */}
        <div className="relative fade-in-up">
          <div className="max-w-6xl mx-auto relative">
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-0 left-1/4 w-3 h-3 bg-cyan-400 rounded-full animate-float opacity-60" style={{ animationDelay: '0s', animationDuration: '4s' }} />
              <div className="absolute top-1/4 right-1/4 w-2 h-2 bg-purple-400 rounded-full animate-float opacity-60" style={{ animationDelay: '1s', animationDuration: '5s' }} />
              <div className="absolute bottom-1/4 left-1/3 w-2 h-2 bg-orange-400 rounded-full animate-float opacity-60" style={{ animationDelay: '2s', animationDuration: '6s' }} />
              <div className="absolute inset-0 border border-cyan-500/20 rounded-3xl animate-ping" style={{ animationDuration: '3s' }} />
            </div>
            
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/30 via-purple-500/30 to-orange-500/30 blur-3xl opacity-60 animate-pulse" style={{ animationDuration: '4s' }} />
            
            <div className="relative bg-gradient-to-br from-card/80 via-primary/10 to-card/80 border-2 border-primary/50 rounded-3xl p-12 overflow-hidden shadow-[0_0_60px_rgba(6,182,212,0.3)]">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500/10 to-transparent animate-gradient-xy" />
              
              <div className="relative z-10 grid lg:grid-cols-2 gap-12 items-center">
                <div className="text-center lg:text-left">
                  <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 border border-primary/30 rounded-full mb-6">
                    <Sparkles className="w-4 h-4 text-primary" />
                    <span className="text-sm font-semibold glow-cyan">Start Your Journey</span>
                  </div>
                  <h2 className="text-5xl md:text-6xl font-black mb-6 bg-gradient-to-r from-cyan-400 via-purple-400 to-orange-400 bg-clip-text text-transparent leading-tight">
                    Ready to Rise Like a Phoenix?
                  </h2>
                  <p className="text-lg text-foreground/80 mb-8 leading-relaxed">
                    Join thousands of traders transforming their crypto journey with AI-powered insights.
                  </p>
                  <div className="flex flex-wrap gap-3 mb-8 justify-center lg:justify-start">
                    {['AI-Powered', 'Real-Time Data', 'Smart Signals', 'Free to Start'].map((feature, i) => (
                      <span key={i} className="px-3 py-1 bg-gradient-to-r from-primary/20 to-accent/20 border border-primary/30 rounded-full text-sm font-medium">✓ {feature}</span>
                    ))}
                  </div>
                  <button className="group relative px-10 py-5 bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 rounded-xl font-bold text-lg text-white shadow-[0_0_40px_rgba(6,182,212,0.4)] hover:shadow-[0_0_60px_rgba(6,182,212,0.6)] transition-all overflow-hidden scale-hover" onClick={() => window.location.href = '/dashboard'}>
                    <span className="relative z-10 flex items-center gap-2">Launch Dashboard →</span>
                    <div className="absolute inset-0 bg-gradient-to-r from-purple-600 via-blue-600 to-cyan-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                </div>

                <div className="relative hidden lg:block">
                  <div className="relative w-full aspect-square flex items-center justify-center">
                    <div className="relative w-80 h-80 flex items-center justify-center">
                      <div className="absolute inset-0 bg-gradient-to-br from-cyan-500 via-purple-500 to-orange-500 rounded-full blur-3xl opacity-30 animate-pulse" style={{ animationDuration: '3s' }} />
                      <div className="relative w-full h-full flex items-center justify-center overflow-visible pb-16">
                        <div className="text-[220px] leading-none animate-float" style={{ background: 'linear-gradient(135deg, #06b6d4 0%, #a855f7 50%, #fb923c 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text', filter: 'drop-shadow(0 0 30px rgba(6, 182, 212, 0.6))', transform: 'translateY(-20px)', paddingBottom: '20px' }}>🐦‍🔥</div>
                      </div>
                    </div>
                    <div className="absolute inset-0 revolving-cards-container">
                      {[{ icon: "📈", label: "Smart Analysis" }, { icon: "⚡", label: "Lightning Fast" }, { icon: "🎯", label: "AI Precision" }, { icon: "🔒", label: "Secure" }].map((stat, i) => (
                        <div key={i} className="revolving-card glass-card px-4 py-2 rounded-lg border border-primary/40 shadow-lg" style={{ animationDelay: `${-i * 2}s` }}>
                          <div className="flex items-center gap-2">
                            <span className="text-xl">{stat.icon}</span>
                            <span className="text-xs font-bold whitespace-nowrap">{stat.label}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-12 pt-8 border-t border-primary/20">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  {[{ number: "10K+", label: "Active Traders" }, { number: "99.9%", label: "Uptime" }, { number: "50+", label: "Cryptocurrencies" }, { number: "24/7", label: "AI Support" }].map((stat, i) => (
                    <div key={i} className="text-center">
                      <div className="text-3xl font-black bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-1">{stat.number}</div>
                      <div className="text-sm text-muted-foreground">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ number, label }: { number: string; label: string }) => (
  <div className="glass-card p-4 rounded-lg border border-primary/30 text-center scale-hover relative overflow-hidden group">
    {/* Digital scanline */}
    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/10 to-transparent opacity-0 group-hover:opacity-100 animate-data-stream" />
    {/* Corner accents */}
    <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-primary/50 opacity-0 group-hover:opacity-100 transition-opacity" />
    <div className="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-primary/50 opacity-0 group-hover:opacity-100 transition-opacity" />
    <div className="relative z-10">
      <div className="text-3xl font-bold text-primary mb-1 transition-all group-hover:scale-110 group-hover:text-shadow-glow">{number}</div>
      <div className="text-sm text-muted-foreground">{label}</div>
    </div>
  </div>
);

const TechCard = ({ icon, title, description }: any) => (
  <Card className="premium-card glass-card p-6 hover:shadow-[0_0_30px_rgba(6,182,212,0.3)] transition-all duration-300 scale-hover relative overflow-hidden group">
    {/* Animated gradient background */}
    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500/10 to-transparent animate-gradient-xy" />
    
    {/* Holographic shimmer overlay */}
    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 holographic-shimmer" />
    
    {/* Data stream lines */}
    <div className="absolute right-2 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-primary to-transparent opacity-0 group-hover:opacity-60 animate-data-stream" />
    <div className="absolute right-4 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-accent to-transparent opacity-0 group-hover:opacity-40 animate-data-stream" style={{ animationDelay: '0.3s' }} />
    
    {/* Corner brackets */}
    <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-primary/40 opacity-0 group-hover:opacity-100 transition-opacity" />
    <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-primary/40 opacity-0 group-hover:opacity-100 transition-opacity" />
    <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-primary/40 opacity-0 group-hover:opacity-100 transition-opacity" />
    <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-primary/40 opacity-0 group-hover:opacity-100 transition-opacity" />
    
    <div className="relative z-10">
      <div className="flex justify-center mb-4 text-primary icon-rotate-hover transition-transform group-hover:scale-110">{icon}</div>
      <h3 className="text-xl font-bold mb-3 text-center glow-cyan transition-all group-hover:tracking-wider">{title}</h3>
      <p className="text-foreground/70 text-center text-sm leading-relaxed">{description}</p>
    </div>
    
    {/* Animated dot indicators */}
    <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5">
      <div className="w-1.5 h-1.5 rounded-full bg-primary/50 animate-pulse" />
      <div className="w-1.5 h-1.5 rounded-full bg-primary/50 animate-pulse" style={{ animationDelay: '0.2s' }} />
      <div className="w-1.5 h-1.5 rounded-full bg-primary/50 animate-pulse" style={{ animationDelay: '0.4s' }} />
    </div>
  </Card>
);

export default About;
