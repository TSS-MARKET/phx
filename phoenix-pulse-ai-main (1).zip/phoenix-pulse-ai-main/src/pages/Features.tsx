import { motion, useScroll, useTransform } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Brain, TrendingUp, Rocket, Shield, Zap, Target, Search, Database, Lock, Bell, BarChart3, Wallet, Globe, Award, MessageSquare, Activity } from "lucide-react";
import { useRef } from "react";

const Features = () => {
  // Removed laggy scroll animations that cause blur

  const features = [
    {
      icon: <Brain className="w-12 h-12" />,
      title: "AI-Powered Analysis",
      description: "Advanced machine learning algorithms analyze market patterns, sentiment, and technical indicators in real-time to provide actionable insights.",
      gradient: "from-primary/20 to-transparent",
      color: "primary",
    },
    {
      icon: <TrendingUp className="w-12 h-12" />,
      title: "Real-Time Market Data",
      description: "Live cryptocurrency prices, charts, and trading volumes powered by CoinGecko API with instant updates and historical data.",
      gradient: "from-secondary/20 to-transparent",
      color: "secondary",
    },
    {
      icon: <Rocket className="w-12 h-12" />,
      title: "Memecoin Tracker",
      description: "Track trending memecoins with social sentiment analysis from Twitter, Telegram, and Reddit. Never miss the next moonshot.",
      gradient: "from-accent/20 to-transparent",
      color: "accent",
    },
    {
      icon: <Shield className="w-12 h-12" />,
      title: "Token Security Scanner",
      description: "Analyze smart contracts for potential risks, verify liquidity locks, and check holder distribution before investing.",
      gradient: "from-primary/20 to-transparent",
      color: "primary",
    },
    {
      icon: <Zap className="w-12 h-12" />,
      title: "AI Trading Signals",
      description: "Receive intelligent buy/sell signals based on complex technical analysis, market sentiment, and AI predictions.",
      gradient: "from-secondary/20 to-transparent",
      color: "secondary",
    },
    {
      icon: <Target className="w-12 h-12" />,
      title: "Portfolio Tracking",
      description: "Connect your wallet to automatically track your holdings, profit/loss, and receive AI-powered rebalancing suggestions.",
      gradient: "from-accent/20 to-transparent",
      color: "accent",
    },
    {
      icon: <Search className="w-12 h-12" />,
      title: "Advanced Token Search",
      description: "Search any cryptocurrency by name, symbol, or contract address across multiple chains with instant results.",
      gradient: "from-purple-500/20 to-transparent",
      color: "purple",
    },
    {
      icon: <Database className="w-12 h-12" />,
      title: "Multi-Chain Support",
      description: "Track assets across Ethereum, BSC, Solana, Polygon, and more blockchains from a unified dashboard.",
      gradient: "from-cyan-500/20 to-transparent",
      color: "cyan",
    },
    {
      icon: <Lock className="w-12 h-12" />,
      title: "Wallet Integration",
      description: "Seamlessly connect your crypto wallet for real-time portfolio tracking and secure transaction signing.",
      gradient: "from-orange-500/20 to-transparent",
      color: "orange",
    },
    {
      icon: <Bell className="w-12 h-12" />,
      title: "Price Alerts",
      description: "Set custom price alerts and get instant notifications when your target prices are reached.",
      gradient: "from-primary/20 to-transparent",
      color: "primary",
    },
    {
      icon: <BarChart3 className="w-12 h-12" />,
      title: "Technical Analysis Tools",
      description: "Professional-grade charting with 100+ indicators, drawing tools, and pattern recognition.",
      gradient: "from-secondary/20 to-transparent",
      color: "secondary",
    },
    {
      icon: <Wallet className="w-12 h-12" />,
      title: "Whale Monitoring",
      description: "Track large wallet movements and follow smart money to identify potential market-moving transactions.",
      gradient: "from-accent/20 to-transparent",
      color: "accent",
    },
    {
      icon: <Globe className="w-12 h-12" />,
      title: "Global Market News",
      description: "Stay updated with real-time crypto news from trusted sources, filtered by relevance and sentiment.",
      gradient: "from-purple-500/20 to-transparent",
      color: "purple",
    },
    {
      icon: <Award className="w-12 h-12" />,
      title: "Leaderboards & Rankings",
      description: "Compare your trading performance with top traders and climb the community leaderboards.",
      gradient: "from-cyan-500/20 to-transparent",
      color: "cyan",
    },
    {
      icon: <MessageSquare className="w-12 h-12" />,
      title: "AI Chat Assistant",
      description: "Get instant answers about crypto markets, trading strategies, and token analysis from our AI chatbot.",
      gradient: "from-orange-500/20 to-transparent",
      color: "orange",
    },
    {
      icon: <Activity className="w-12 h-12" />,
      title: "Live Trading Statistics",
      description: "Monitor active traders, success rates, and trading volume in real-time across the platform.",
      gradient: "from-primary/20 to-transparent",
      color: "primary",
    },
  ];

  return (
    <div className="min-h-screen pt-24 pb-12 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-cyber-darker via-background to-cyber-dark">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iY3lhbiIgc3Ryb2tlLW9wYWNpdHk9IjAuMSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-20"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <motion.h1 
            className="text-5xl md:text-6xl font-black mb-6 glow-cyan"
            animate={{
              textShadow: [
                "0 0 20px rgba(6, 182, 212, 0.5)",
                "0 0 40px rgba(6, 182, 212, 0.8)",
                "0 0 20px rgba(6, 182, 212, 0.5)",
              ]
            }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            Powerful Features
          </motion.h1>
          <p className="text-xl text-foreground/70 max-w-3xl mx-auto">
            Everything you need to dominate the crypto market with AI-powered intelligence
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {features.map((feature, index) => (
            <FeatureCard key={index} {...feature} index={index} />
          ))}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-20 text-center"
        >
          <Card className="glass-card p-12 max-w-3xl mx-auto bg-gradient-to-br from-primary/10 to-secondary/10 relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-4xl font-bold mb-6 glow-orange">
                Ready to Start Trading Smarter?
              </h2>
              <p className="text-xl text-foreground/70 mb-8">
                Join thousands of traders already using Phoenix AI to maximize their crypto profits
              </p>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 text-white px-12 py-4 rounded-xl font-bold text-lg animate-gradient-shift bg-[length:200%_200%] shadow-[0_0_30px_rgba(6,182,212,0.4)] hover:shadow-[0_0_40px_rgba(6,182,212,0.6)]"
              >
                Get Started Now
              </motion.button>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

const FeatureCard = ({ icon, title, description, gradient, index, color }: any) => {
  // Map color names to CSS variables
  const colorMap: Record<string, string> = {
    primary: 'var(--primary)',
    secondary: 'var(--secondary)',
    accent: 'var(--accent)',
    purple: '268 85% 58%',
    cyan: '194 100% 60%',
    orange: '14 100% 60%'
  };
  
  const hslColor = colorMap[color] || 'var(--primary)';
  
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ delay: index * 0.05, duration: 0.5 }}
      whileHover={{ 
        y: -8,
        transition: { duration: 0.2 }
      }}
      className={`glass-card p-6 rounded-xl bg-gradient-to-br ${gradient} relative overflow-hidden group border border-primary/10 hover:border-primary/30 transition-all duration-300 h-full flex flex-col`}
    >
      {/* Shiny border effect */}
      <motion.div
        className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{
          background: `linear-gradient(135deg, transparent 0%, hsl(${hslColor} / 0.2) 50%, transparent 100%)`,
          backgroundSize: "200% 200%",
        }}
        animate={{
          backgroundPosition: ["0% 0%", "100% 100%", "0% 0%"],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "linear"
        }}
      />
      {/* Animated background gradient */}
      <motion.div
        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity"
        style={{
          background: `radial-gradient(circle at 50% 50%, hsl(${hslColor} / 0.15) 0%, transparent 70%)`
        }}
      />
      
      {/* Floating particles effect */}
      <motion.div
        animate={{
          y: [0, -10, 0],
          opacity: [0.3, 0.6, 0.3]
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut",
          delay: index * 0.1
        }}
        className="absolute top-0 right-0 w-20 h-20 bg-primary/10 rounded-full blur-2xl"
      />
      
      <div className="relative z-10 flex-1 flex flex-col">
        <motion.div 
          className="mb-4"
          style={{ color: `hsl(${hslColor})` }}
          whileHover={{ rotate: [0, -10, 10, -10, 0] }}
          transition={{ duration: 0.5 }}
        >
          {icon}
        </motion.div>
        <h3 className="text-xl font-bold mb-3 glow-cyan">{title}</h3>
        <p className="text-foreground/70 text-sm leading-relaxed flex-1">{description}</p>
      </div>
      
      {/* Border flow animation */}
      <motion.div
        className="absolute inset-0 rounded-xl pointer-events-none"
        style={{
          background: `linear-gradient(90deg, transparent, hsl(${hslColor} / 0.4), transparent)`,
          backgroundSize: "200% 100%",
        }}
        animate={{
          backgroundPosition: ["0% 0%", "200% 0%"],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "linear"
        }}
      />
    </motion.div>
  );
};

export default Features;