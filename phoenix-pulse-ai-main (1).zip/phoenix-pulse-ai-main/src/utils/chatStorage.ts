export type Message = {
  role: "user" | "assistant";
  content: string;
  timestamp: number;
};

export type Conversation = {
  id: string;
  walletAddress: string;
  title: string;
  messages: Message[];
  createdAt: number;
  updatedAt: number;
};

const STORAGE_KEY = "phoenix_conversations";

export const getAllConversations = (walletAddress: string): Conversation[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return [];
    
    const allConversations: Conversation[] = JSON.parse(stored);
    return allConversations
      .filter(conv => conv.walletAddress === walletAddress)
      .sort((a, b) => b.updatedAt - a.updatedAt);
  } catch (error) {
    console.error("Error loading conversations:", error);
    return [];
  }
};

export const getConversation = (conversationId: string): Conversation | null => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return null;
    
    const allConversations: Conversation[] = JSON.parse(stored);
    return allConversations.find(conv => conv.id === conversationId) || null;
  } catch (error) {
    console.error("Error loading conversation:", error);
    return null;
  }
};

export const createConversation = (walletAddress: string, firstMessage?: Message): Conversation => {
  const conversation: Conversation = {
    id: `conv_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    walletAddress,
    title: "New Conversation",
    messages: firstMessage ? [firstMessage] : [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  
  saveConversation(conversation);
  return conversation;
};

export const saveConversation = (conversation: Conversation) => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    const allConversations: Conversation[] = stored ? JSON.parse(stored) : [];
    
    const index = allConversations.findIndex(conv => conv.id === conversation.id);
    
    if (index >= 0) {
      allConversations[index] = {
        ...conversation,
        updatedAt: Date.now(),
      };
    } else {
      allConversations.push({
        ...conversation,
        updatedAt: Date.now(),
      });
    }
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify(allConversations));
  } catch (error) {
    console.error("Error saving conversation:", error);
  }
};

export const addMessageToConversation = (conversationId: string, message: Message) => {
  const conversation = getConversation(conversationId);
  if (!conversation) return;
  
  conversation.messages.push(message);
  
  // Auto-generate title from first user message
  if (conversation.title === "New Conversation" && message.role === "user") {
    conversation.title = message.content.slice(0, 50) + (message.content.length > 50 ? "..." : "");
  }
  
  saveConversation(conversation);
};

export const deleteConversation = (conversationId: string) => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return;
    
    const allConversations: Conversation[] = JSON.parse(stored);
    const filtered = allConversations.filter(conv => conv.id !== conversationId);
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
  } catch (error) {
    console.error("Error deleting conversation:", error);
  }
};

export const clearAllConversations = (walletAddress: string) => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return;
    
    const allConversations: Conversation[] = JSON.parse(stored);
    const filtered = allConversations.filter(conv => conv.walletAddress !== walletAddress);
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
  } catch (error) {
    console.error("Error clearing conversations:", error);
  }
};
