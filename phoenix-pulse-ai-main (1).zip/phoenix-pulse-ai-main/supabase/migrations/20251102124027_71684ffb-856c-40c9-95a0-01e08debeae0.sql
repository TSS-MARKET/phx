-- Remove unused user_roles table and enum type
-- This table was created but never implemented in the application
-- Removing it reduces attack surface and technical debt

DROP TABLE IF EXISTS public.user_roles;
DROP TYPE IF EXISTS public.app_role;