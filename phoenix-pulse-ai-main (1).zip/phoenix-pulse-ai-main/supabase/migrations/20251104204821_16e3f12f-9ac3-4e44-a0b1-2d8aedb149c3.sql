-- Create subscription tiers enum
CREATE TYPE public.subscription_tier AS ENUM ('free', 'pro', 'elite');

-- Create subscription status enum
CREATE TYPE public.subscription_status AS ENUM ('active', 'cancelled', 'expired', 'trialing');

-- User subscriptions table
CREATE TABLE public.user_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tier subscription_tier NOT NULL DEFAULT 'free',
  status subscription_status NOT NULL DEFAULT 'active',
  stripe_subscription_id TEXT,
  stripe_customer_id TEXT,
  current_period_start TIMESTAMP WITH TIME ZONE,
  current_period_end TIMESTAMP WITH TIME ZONE,
  cancel_at_period_end BOOLEAN DEFAULT false,
  daily_analysis_count INTEGER DEFAULT 0,
  last_analysis_reset TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(user_id)
);

-- Phoenix Daily 3 picks table
CREATE TABLE public.phoenix_daily_picks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pick_date DATE NOT NULL DEFAULT CURRENT_DATE,
  rank INTEGER NOT NULL CHECK (rank BETWEEN 1 AND 3),
  coin_id TEXT NOT NULL,
  coin_name TEXT NOT NULL,
  coin_symbol TEXT NOT NULL,
  current_price NUMERIC(20, 10),
  price_change_24h NUMERIC(10, 2),
  market_cap NUMERIC(20, 2),
  volume_24h NUMERIC(20, 2),
  ai_score INTEGER NOT NULL CHECK (ai_score BETWEEN 0 AND 100),
  ai_entry_price NUMERIC(20, 10),
  ai_exit_price NUMERIC(20, 10),
  ai_stop_loss NUMERIC(20, 10),
  risk_level TEXT NOT NULL CHECK (risk_level IN ('low', 'medium', 'high')),
  ai_reasoning TEXT,
  sentiment_score NUMERIC(5, 2),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(pick_date, rank)
);

-- User created tokens table
CREATE TABLE public.user_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  token_name TEXT NOT NULL,
  token_symbol TEXT NOT NULL,
  token_supply BIGINT NOT NULL,
  token_decimals INTEGER NOT NULL DEFAULT 9,
  token_address TEXT NOT NULL UNIQUE,
  ai_launch_score INTEGER CHECK (ai_launch_score BETWEEN 0 AND 100),
  phoenix_approved BOOLEAN DEFAULT false,
  metadata_uri TEXT,
  liquidity_added BOOLEAN DEFAULT false,
  liquidity_pool_address TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Trading bot history table
CREATE TABLE public.trading_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  trade_type TEXT NOT NULL CHECK (trade_type IN ('buy', 'sell')),
  mode TEXT NOT NULL CHECK (mode IN ('signal', 'auto')),
  from_token TEXT NOT NULL,
  to_token TEXT NOT NULL,
  amount_in NUMERIC(20, 10) NOT NULL,
  amount_out NUMERIC(20, 10),
  price NUMERIC(20, 10),
  transaction_signature TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed')),
  profit_loss NUMERIC(20, 10),
  profit_loss_percentage NUMERIC(10, 2),
  ai_confidence INTEGER CHECK (ai_confidence BETWEEN 0 AND 100),
  executed_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- User trading analytics table
CREATE TABLE public.user_trading_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  total_trades INTEGER DEFAULT 0,
  winning_trades INTEGER DEFAULT 0,
  losing_trades INTEGER DEFAULT 0,
  total_profit_loss NUMERIC(20, 10) DEFAULT 0,
  average_roi NUMERIC(10, 2) DEFAULT 0,
  best_trade_profit NUMERIC(20, 10) DEFAULT 0,
  worst_trade_loss NUMERIC(20, 10) DEFAULT 0,
  total_volume_traded NUMERIC(20, 2) DEFAULT 0,
  last_updated TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.phoenix_daily_picks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trading_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_trading_analytics ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_subscriptions
CREATE POLICY "Users can view own subscription"
  ON public.user_subscriptions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own subscription"
  ON public.user_subscriptions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own subscription"
  ON public.user_subscriptions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for phoenix_daily_picks (public read for all authenticated users)
CREATE POLICY "All users can view daily picks"
  ON public.phoenix_daily_picks FOR SELECT
  TO authenticated
  USING (true);

-- RLS Policies for user_tokens
CREATE POLICY "Users can view own tokens"
  ON public.user_tokens FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create tokens"
  ON public.user_tokens FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own tokens"
  ON public.user_tokens FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for trading_history
CREATE POLICY "Users can view own trades"
  ON public.trading_history FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create trades"
  ON public.trading_history FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own trades"
  ON public.trading_history FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for user_trading_analytics
CREATE POLICY "Users can view own analytics"
  ON public.user_trading_analytics FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own analytics"
  ON public.user_trading_analytics FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own analytics"
  ON public.user_trading_analytics FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Triggers for updated_at
CREATE TRIGGER update_user_subscriptions_updated_at
  BEFORE UPDATE ON public.user_subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_user_tokens_updated_at
  BEFORE UPDATE ON public.user_tokens
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Function to reset daily analysis count
CREATE OR REPLACE FUNCTION public.reset_daily_analysis_count()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.user_subscriptions
  SET daily_analysis_count = 0,
      last_analysis_reset = now()
  WHERE last_analysis_reset < CURRENT_DATE;
END;
$$;

-- Function to check subscription access
CREATE OR REPLACE FUNCTION public.can_access_feature(
  _user_id UUID,
  _feature TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_tier subscription_tier;
  user_status subscription_status;
BEGIN
  SELECT tier, status INTO user_tier, user_status
  FROM public.user_subscriptions
  WHERE user_id = _user_id;
  
  -- If no subscription exists, user is on free tier
  IF user_tier IS NULL THEN
    user_tier := 'free';
  END IF;
  
  -- Check if subscription is active
  IF user_status IS NOT NULL AND user_status != 'active' THEN
    RETURN false;
  END IF;
  
  -- Feature access logic
  CASE _feature
    WHEN 'unlimited_analysis' THEN
      RETURN user_tier IN ('pro', 'elite');
    WHEN 'sentiment_tracker' THEN
      RETURN user_tier IN ('pro', 'elite');
    WHEN 'portfolio_insights' THEN
      RETURN user_tier IN ('pro', 'elite');
    WHEN 'memecoin_hype' THEN
      RETURN user_tier = 'elite';
    WHEN 'phoenix_daily_3' THEN
      RETURN user_tier = 'elite';
    WHEN 'trading_bot' THEN
      RETURN user_tier = 'elite';
    WHEN 'alerts' THEN
      RETURN user_tier = 'elite';
    ELSE
      RETURN false;
  END CASE;
END;
$$;

-- Function to update trading analytics
CREATE OR REPLACE FUNCTION public.update_trading_analytics()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NEW.status = 'completed' THEN
    INSERT INTO public.user_trading_analytics (user_id)
    VALUES (NEW.user_id)
    ON CONFLICT (user_id) DO NOTHING;
    
    UPDATE public.user_trading_analytics
    SET 
      total_trades = total_trades + 1,
      winning_trades = winning_trades + CASE WHEN NEW.profit_loss > 0 THEN 1 ELSE 0 END,
      losing_trades = losing_trades + CASE WHEN NEW.profit_loss < 0 THEN 1 ELSE 0 END,
      total_profit_loss = total_profit_loss + COALESCE(NEW.profit_loss, 0),
      total_volume_traded = total_volume_traded + NEW.amount_in,
      best_trade_profit = GREATEST(best_trade_profit, COALESCE(NEW.profit_loss, 0)),
      worst_trade_loss = LEAST(worst_trade_loss, COALESCE(NEW.profit_loss, 0)),
      last_updated = now()
    WHERE user_id = NEW.user_id;
    
    -- Calculate average ROI
    UPDATE public.user_trading_analytics
    SET average_roi = (total_profit_loss / NULLIF(total_volume_traded, 0)) * 100
    WHERE user_id = NEW.user_id;
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_analytics_on_trade
  AFTER INSERT OR UPDATE ON public.trading_history
  FOR EACH ROW
  EXECUTE FUNCTION public.update_trading_analytics();