-- Add user_id column to chat_messages
ALTER TABLE chat_messages ADD COLUMN user_id UUID REFERENCES auth.users(id);

-- Drop existing insecure policies
DROP POLICY IF EXISTS "Users can read own session messages" ON chat_messages;
DROP POLICY IF EXISTS "Users can insert to own session" ON chat_messages;

-- Create secure policies using authentication
CREATE POLICY "Users can read own messages"
ON chat_messages FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own messages"
ON chat_messages FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Create user_roles table for tier management
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL DEFAULT 'user',
  UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own role"
ON public.user_roles FOR SELECT
USING (auth.uid() = user_id);

-- Create user_tiers table for holdings verification
CREATE TABLE public.user_tiers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  tier TEXT NOT NULL CHECK (tier IN ('none', 'basic', 'premium', 'elite')) DEFAULT 'none',
  verified_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.user_tiers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own tier"
ON public.user_tiers FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can update own tier"
ON public.user_tiers FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own tier"
ON public.user_tiers FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_user_tiers_updated_at
BEFORE UPDATE ON public.user_tiers
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();