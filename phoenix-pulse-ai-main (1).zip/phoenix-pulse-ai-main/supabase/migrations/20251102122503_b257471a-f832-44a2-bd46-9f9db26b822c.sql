-- Add length constraint to chat_messages content
ALTER TABLE public.chat_messages
ADD CONSTRAINT content_length_check 
CHECK (length(content) <= 50000);

-- Add comment explaining the constraint
COMMENT ON CONSTRAINT content_length_check ON public.chat_messages 
IS 'Prevents database bloat and excessive AI API costs by limiting message length to 50,000 characters';