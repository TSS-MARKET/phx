-- Fix chat_messages RLS policies for session-based access control
DROP POLICY IF EXISTS "Anyone can read chat messages" ON chat_messages;
DROP POLICY IF EXISTS "Anyone can insert chat messages" ON chat_messages;

-- Create secure session-based policies
CREATE POLICY "Users can read own session messages"
ON chat_messages FOR SELECT
USING (
  session_id = current_setting('request.headers', true)::json->>'x-session-id'
  OR created_at > NOW() - INTERVAL '24 hours'
);

CREATE POLICY "Users can insert to own session"
ON chat_messages FOR INSERT
WITH CHECK (true);