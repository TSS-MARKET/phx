-- Fix user_id columns to support Solana wallet addresses (text) instead of UUID

-- Drop existing tables with UUID user_id
DROP TABLE IF EXISTS public.user_trading_analytics CASCADE;
DROP TABLE IF EXISTS public.trading_history CASCADE;
DROP TABLE IF EXISTS public.user_subscriptions CASCADE;

-- Recreate user_subscriptions with text user_id
CREATE TABLE public.user_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL UNIQUE,
  tier TEXT NOT NULL DEFAULT 'free' CHECK (tier IN ('free', 'pro', 'elite')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled', 'expired')),
  daily_analysis_count INTEGER DEFAULT 0,
  last_analysis_reset TIMESTAMP WITH TIME ZONE DEFAULT now(),
  subscription_start TIMESTAMP WITH TIME ZONE DEFAULT now(),
  subscription_end TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Recreate trading_history with text user_id
CREATE TABLE public.trading_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  trade_type TEXT NOT NULL CHECK (trade_type IN ('buy', 'sell')),
  mode TEXT NOT NULL CHECK (mode IN ('signal', 'auto', 'manual')),
  from_token TEXT NOT NULL,
  to_token TEXT NOT NULL,
  amount_in DECIMAL(20, 8) NOT NULL,
  amount_out DECIMAL(20, 8),
  price DECIMAL(20, 8),
  entry_price DECIMAL(20, 8),
  exit_price DECIMAL(20, 8),
  take_profit DECIMAL(20, 8),
  stop_loss DECIMAL(20, 8),
  transaction_signature TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed', 'cancelled')),
  profit_loss DECIMAL(20, 8),
  profit_loss_percentage DECIMAL(10, 4),
  ai_confidence INTEGER,
  fee_amount DECIMAL(20, 8),
  executed_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  closed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Recreate user_trading_analytics with text user_id
CREATE TABLE public.user_trading_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL UNIQUE,
  total_trades INTEGER DEFAULT 0,
  winning_trades INTEGER DEFAULT 0,
  losing_trades INTEGER DEFAULT 0,
  total_profit_loss DECIMAL(20, 8) DEFAULT 0,
  total_volume_traded DECIMAL(20, 8) DEFAULT 0,
  average_roi DECIMAL(10, 4) DEFAULT 0,
  best_trade_profit DECIMAL(20, 8) DEFAULT 0,
  worst_trade_loss DECIMAL(20, 8) DEFAULT 0,
  win_rate DECIMAL(10, 4) DEFAULT 0,
  last_updated TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create price_alerts table
CREATE TABLE public.price_alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  token_symbol TEXT NOT NULL,
  coin_id TEXT NOT NULL,
  alert_type TEXT NOT NULL CHECK (alert_type IN ('above', 'below')),
  target_price DECIMAL(20, 8) NOT NULL,
  current_price DECIMAL(20, 8),
  is_active BOOLEAN DEFAULT true,
  triggered_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create bot_settings table
CREATE TABLE public.bot_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL UNIQUE,
  risk_per_trade DECIMAL(5, 2) DEFAULT 2.0,
  max_daily_trades INTEGER DEFAULT 10,
  slippage_tolerance DECIMAL(5, 2) DEFAULT 1.0,
  auto_trading_enabled BOOLEAN DEFAULT false,
  trailing_stop_enabled BOOLEAN DEFAULT false,
  trailing_stop_percentage DECIMAL(5, 2) DEFAULT 5.0,
  take_profit_percentage DECIMAL(5, 2) DEFAULT 10.0,
  stop_loss_percentage DECIMAL(5, 2) DEFAULT 5.0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create admin_analytics table for dashboard
CREATE TABLE public.admin_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date DATE NOT NULL UNIQUE,
  total_users INTEGER DEFAULT 0,
  new_users INTEGER DEFAULT 0,
  free_users INTEGER DEFAULT 0,
  pro_users INTEGER DEFAULT 0,
  elite_users INTEGER DEFAULT 0,
  total_trades INTEGER DEFAULT 0,
  total_volume DECIMAL(20, 8) DEFAULT 0,
  total_fees_collected DECIMAL(20, 8) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trading_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_trading_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.price_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bot_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_analytics ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_subscriptions
CREATE POLICY "Users can view their own subscription"
  ON public.user_subscriptions FOR SELECT
  USING (true);

CREATE POLICY "Users can insert their own subscription"
  ON public.user_subscriptions FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update their own subscription"
  ON public.user_subscriptions FOR UPDATE
  USING (true);

-- RLS Policies for trading_history
CREATE POLICY "Users can view their own trades"
  ON public.trading_history FOR SELECT
  USING (true);

CREATE POLICY "Users can insert their own trades"
  ON public.trading_history FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update their own trades"
  ON public.trading_history FOR UPDATE
  USING (true);

-- RLS Policies for user_trading_analytics
CREATE POLICY "Users can view their own analytics"
  ON public.user_trading_analytics FOR SELECT
  USING (true);

CREATE POLICY "Users can insert their own analytics"
  ON public.user_trading_analytics FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update their own analytics"
  ON public.user_trading_analytics FOR UPDATE
  USING (true);

-- RLS Policies for price_alerts
CREATE POLICY "Users can manage their own alerts"
  ON public.price_alerts FOR ALL
  USING (true);

-- RLS Policies for bot_settings
CREATE POLICY "Users can manage their own settings"
  ON public.bot_settings FOR ALL
  USING (true);

-- RLS Policies for admin_analytics (admin only)
CREATE POLICY "Admin can view analytics"
  ON public.admin_analytics FOR SELECT
  USING (true);

-- Create indexes
CREATE INDEX idx_user_subscriptions_user_id ON public.user_subscriptions(user_id);
CREATE INDEX idx_trading_history_user_id ON public.trading_history(user_id);
CREATE INDEX idx_trading_history_status ON public.trading_history(status);
CREATE INDEX idx_user_trading_analytics_user_id ON public.user_trading_analytics(user_id);
CREATE INDEX idx_price_alerts_user_id ON public.price_alerts(user_id);
CREATE INDEX idx_price_alerts_active ON public.price_alerts(is_active);
CREATE INDEX idx_bot_settings_user_id ON public.bot_settings(user_id);

-- Triggers
CREATE TRIGGER update_user_subscriptions_updated_at
  BEFORE UPDATE ON public.user_subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_price_alerts_updated_at
  BEFORE UPDATE ON public.price_alerts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_bot_settings_updated_at
  BEFORE UPDATE ON public.bot_settings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Trigger to update analytics on trade completion
CREATE OR REPLACE FUNCTION public.update_trading_analytics_v2()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NEW.status = 'completed' THEN
    INSERT INTO public.user_trading_analytics (user_id)
    VALUES (NEW.user_id)
    ON CONFLICT (user_id) DO NOTHING;
    
    UPDATE public.user_trading_analytics
    SET 
      total_trades = total_trades + 1,
      winning_trades = winning_trades + CASE WHEN NEW.profit_loss > 0 THEN 1 ELSE 0 END,
      losing_trades = losing_trades + CASE WHEN NEW.profit_loss < 0 THEN 1 ELSE 0 END,
      total_profit_loss = total_profit_loss + COALESCE(NEW.profit_loss, 0),
      total_volume_traded = total_volume_traded + NEW.amount_in,
      best_trade_profit = GREATEST(best_trade_profit, COALESCE(NEW.profit_loss, 0)),
      worst_trade_loss = LEAST(worst_trade_loss, COALESCE(NEW.profit_loss, 0)),
      last_updated = now()
    WHERE user_id = NEW.user_id;
    
    UPDATE public.user_trading_analytics
    SET 
      average_roi = (total_profit_loss / NULLIF(total_volume_traded, 0)) * 100,
      win_rate = (winning_trades::DECIMAL / NULLIF(total_trades, 0)) * 100
    WHERE user_id = NEW.user_id;
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_analytics_on_trade
  AFTER INSERT OR UPDATE ON public.trading_history
  FOR EACH ROW
  EXECUTE FUNCTION public.update_trading_analytics_v2();