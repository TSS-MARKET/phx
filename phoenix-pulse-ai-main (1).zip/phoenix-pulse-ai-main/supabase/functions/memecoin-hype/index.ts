import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const COINGECKO_API_KEY = Deno.env.get('COINGECKO_API_KEY');
const LUNARCRUSH_API_KEY = Deno.env.get('LUNARCRUSH_API_KEY');

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  // Validate required API keys
  if (!COINGECKO_API_KEY || !LUNARCRUSH_API_KEY) {
    console.error('Missing required API keys: COINGECKO_API_KEY or LUNARCRUSH_API_KEY');
    return new Response(
      JSON.stringify({ error: 'Service configuration error' }),
      { status: 500, headers: corsHeaders }
    );
  }

  try {
    const body = await req.json().catch(() => ({}));
    let search = body.search || '';
    
    // Sanitize search input to prevent XSS
    if (search) {
      search = String(search).trim().slice(0, 100); // Limit length
      search = search.replace(/[<>\"']/g, ''); // Remove potentially dangerous characters
    }
    
    console.log('Fetching memecoin hype data:', { search });

    // Check if search is a contract/pair address (42-44 chars for Solana addresses)
    const isAddressSearch = search && search.length >= 32 && /^[a-zA-Z0-9]+$/.test(search);
    const isPairAddressSearch = search && /^0x[a-fA-F0-9]{40}$/.test(search); // Ethereum pair address

    // 1. Fetch from Dexscreener with better error handling
    let dexData: any[] = [];
    try {
      if (isAddressSearch || isPairAddressSearch) {
        // Try pair address first
        try {
          const pairRes = await fetch(`https://api.dexscreener.com/latest/dex/pairs/${search}`);
          console.log('Pair search status:', pairRes.status);
          if (pairRes.ok) {
            const pairJson = await pairRes.json();
            console.log('Pair search response:', JSON.stringify(pairJson).slice(0, 200));
            if (pairJson.pair) {
              dexData = [pairJson.pair];
              console.log('Found pair by address:', search);
            } else if (pairJson.pairs && pairJson.pairs.length > 0) {
              dexData = pairJson.pairs;
              console.log('Found pairs by address:', dexData.length);
            }
          }
        } catch (pairError) {
          console.log('Pair search failed, trying token search:', pairError);
        }

        // If pair search fails, try token address
        if (dexData.length === 0) {
          const tokenRes = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${search}`);
          console.log('Token search status:', tokenRes.status);
          if (tokenRes.ok) {
            const tokenJson = await tokenRes.json();
            console.log('Token search response:', JSON.stringify(tokenJson).slice(0, 200));
            dexData = tokenJson.pairs || [];
            console.log('Found by token address:', dexData.length);
          }
        }
      } else if (search) {
        const searchRes = await fetch(`https://api.dexscreener.com/latest/dex/search?q=${encodeURIComponent(search)}`);
        console.log('Search status:', searchRes.status);
        if (searchRes.ok) {
          const searchJson = await searchRes.json();
          console.log('Search response:', JSON.stringify(searchJson).slice(0, 200));
          dexData = searchJson.pairs || [];
          console.log('Search results:', dexData.length);
        }
      } else {
        // Fetch memecoins using popular search terms across chains
        console.log('Fetching trending memecoins using search terms...');
        
        // Popular memecoin search terms
        const searchTerms = ['pepe', 'doge', 'shib', 'bonk', 'floki', 'meme', 'inu', 'elon', 'baby', 'moon'];
        
        const searchPromises = searchTerms.slice(0, 5).map(async (term) => {
          try {
            const res = await fetch(`https://api.dexscreener.com/latest/dex/search?q=${term}`);
            if (!res.ok) {
              console.log(`Failed to search for ${term}: ${res.status}`);
              return [];
            }
            const json = await res.json();
            const pairs = json.pairs || [];
            console.log(`Found ${pairs.length} pairs for search term "${term}"`);
            return pairs;
          } catch (error) {
            console.error(`Error searching for ${term}:`, error);
            return [];
          }
        });
        
        const searchResults = await Promise.all(searchPromises);
        const allPairs = searchResults.flat();
        console.log(`Found ${allPairs.length} total pairs from search`);
        
        // Filter to only include pairs with good metrics and from our supported chains
        const supportedChains = ['solana', 'bsc', 'ethereum', 'base', 'arbitrum'];
        dexData = allPairs
          .filter((pair: any) => {
            const hasGoodVolume = pair.volume?.h24 > 10000;
            const hasLiquidity = pair.liquidity?.usd > 5000;
            const isSupportedChain = supportedChains.includes(pair.chainId);
            const hasTrendingScore = pair.trendingScoreH24 > 0;
            return hasGoodVolume && hasLiquidity && isSupportedChain && hasTrendingScore;
          })
          .sort((a: any, b: any) => (b.volume?.h24 || 0) - (a.volume?.h24 || 0))
          .slice(0, 100); // Take top 100 by volume
        
        console.log(`Filtered to ${dexData.length} high-quality pairs`);
      }
      console.log('Dexscreener data fetched:', dexData.length);
    } catch (e) {
      console.error('Dexscreener error:', e);
      console.error('Error stack:', e instanceof Error ? e.stack : 'No stack');
    }

    // 2. Fetch social data from LunarCrush
    let lunarData: any[] = [];
    try {
      const lunarRes = await fetch('https://lunarcrush.com/api4/public/assets?limit=50', {
        headers: { 'Authorization': `Bearer ${LUNARCRUSH_API_KEY}` }
      });
      const lunarJson = await lunarRes.json();
      lunarData = Array.isArray(lunarJson) ? lunarJson : (lunarJson.data || []);
      console.log('LunarCrush data fetched:', lunarData.length);
    } catch (e) {
      console.error('LunarCrush error:', e);
    }

    // 3. Fetch CoinGecko trending as backup
    let cgTrending: any[] = [];
    try {
      const cgRes = await fetch('https://api.coingecko.com/api/v3/search/trending', {
        headers: { 'x-cg-demo-api-key': COINGECKO_API_KEY }
      });
      const cgJson = await cgRes.json();
      cgTrending = (cgJson.coins || []).map((c: any) => c.item);
      console.log('CoinGecko trending fetched:', cgTrending.length);
    } catch (e) {
      console.error('CoinGecko error:', e);
    }

    // 4. Calculate hype scores
    // If searching by address, only show the first exact match
    const dataToProcess = isAddressSearch ? dexData.slice(0, 1) : dexData;
    
    // Sanitize function to prevent XSS in coin data
    const sanitizeString = (str: any, maxLength: number = 100): string => {
      return String(str || '').slice(0, maxLength).replace(/[<>\"']/g, '');
    };
    
    const combinedData = dataToProcess.map((pair: any, idx: number) => {
      const symbol = sanitizeString(pair.baseToken?.symbol, 20).toUpperCase();
      const name = sanitizeString(pair.baseToken?.name || symbol, 100);
      
      // Find matching social data
      const lunarMatch = lunarData.find(l => 
        l.symbol?.toUpperCase() === symbol.toUpperCase() || 
        l.name?.toLowerCase() === name.toLowerCase()
      );
      
      const cgMatch = cgTrending.find(c => 
        c.symbol?.toUpperCase() === symbol.toUpperCase() ||
        c.name?.toLowerCase() === name.toLowerCase()
      );

      // Calculate hype score using user's formula: (volume24h / 10000) + (priceChange.h24 * 5) + (liquidity.usd / 10000)
      const volume24h = pair.volume?.h24 || 0;
      const priceChange24h = pair.priceChange?.h24 || 0;
      const liquidityUsd = pair.liquidity?.usd || 0;
      
      // Base hype score calculation
      let rawHypeScore = (volume24h / 10000) + (priceChange24h * 5) + (liquidityUsd / 10000);
      
      // Add CoinGecko trending bonus (+10 if in trending list)
      const cgTrendingBonus = cgMatch ? 10 : 0;
      rawHypeScore += cgTrendingBonus;
      
      // Add social score bonus from LunarCrush
      const socialBonus = lunarMatch ? (lunarMatch.galaxy_score || 0) * 0.1 : 0;
      rawHypeScore += socialBonus;
      
      // Normalize to 0-100 scale
      const hypeScore = Math.min(100, Math.max(0, Math.round(rawHypeScore)));
      
      // Component scores for display
      const volumeScore = Math.min(100, (volume24h / 1000000) * 20);
      const socialScore = lunarMatch ? (lunarMatch.galaxy_score || 0) * 0.5 : (cgMatch ? 30 : 0);
      const velocityScore = Math.min(20, Math.abs(priceChange24h) + (volume24h / 1000000));
      const trendingScore = Math.min(50, (pair.trendingScoreH24 || 0) * 10);

      // Calculate reliability score (0-100) - based ONLY on 24hr volume
      const hasExcellentVolume = volume24h > 1000000; // Over 1M volume
      const hasGoodVolume = volume24h > 500000; // Over 500K volume
      const hasDecentVolume = volume24h > 100000; // Over 100K volume
      const hasLowVolume = volume24h > 50000; // Over 50K volume
      
      // Reliability based 100% on 24hr volume
      let reliabilityScore = 0;
      if (hasExcellentVolume) {
        reliabilityScore = 100;
      } else if (hasGoodVolume) {
        reliabilityScore = 80;
      } else if (hasDecentVolume) {
        reliabilityScore = 60;
      } else if (hasLowVolume) {
        reliabilityScore = 40;
      } else {
        reliabilityScore = Math.round(Math.min(40, (volume24h / 50000) * 40));
      }

      return {
        id: sanitizeString(pair.pairAddress || `${symbol}-${idx}`, 100),
        name,
        symbol,
        icon: sanitizeString(pair.info?.imageUrl || lunarMatch?.icon || cgMatch?.small, 500),
        price: pair.priceUsd || 0,
        priceChange24h: pair.priceChange?.h24 || 0,
        volume24h: pair.volume?.h24 || 0,
        liquidity: pair.liquidity?.usd || 0,
        marketCap: pair.marketCap || 0,
        fdv: pair.fdv || 0,
        holderCount: pair.txns?.h24?.buys + pair.txns?.h24?.sells || 0,
        
        // Hype components
        hypeScore,
        volumeScore: Math.round(volumeScore),
        socialScore: Math.round(socialScore),
        velocityScore: Math.round(velocityScore),
        trendingScore: Math.round(trendingScore),
        reliabilityScore,
        
        // Additional data
        socialMentions: lunarMatch?.social_volume || 0,
        galaxyScore: lunarMatch?.galaxy_score || 0,
        chain: pair.chainId || 'unknown',
        pairAddress: pair.pairAddress,
        dexId: pair.dexId,
        url: pair.url,
        pairCreatedAt: pair.pairCreatedAt,
        topInChain: false,
        mostReliable: false,
      };
    });

    // When searching, sort by volume first (most reliable), then tag the top one
    // When not searching, sort by hype score first
    if (search) {
      // Sort by volume (reliability)
      combinedData.sort((a, b) => b.volume24h - a.volume24h);
      // Tag the first one (highest volume) as most reliable
      if (combinedData.length > 0) {
        combinedData[0].mostReliable = true;
      }
    } else {
      // Sort by hype score
      combinedData.sort((a, b) => b.hypeScore - a.hypeScore);
    }
    
    let filteredData: any[];
    if (!search) {
      // Group by chain and take top 10 per chain
      const chainGroups = new Map<string, any[]>();
      combinedData.forEach(coin => {
        if (!chainGroups.has(coin.chain)) {
          chainGroups.set(coin.chain, []);
        }
        chainGroups.get(coin.chain)!.push(coin);
      });

      // Take top 10 from each chain, sorted by hype score
      filteredData = [];
      chainGroups.forEach((coins, chain) => {
        const top10 = coins.slice(0, 10);
        if (top10.length > 0) {
          top10[0].topInChain = true; // Mark the top coin in each chain
        }
        filteredData.push(...top10);
        
        console.log(`📊 Top ${top10.length} coins on ${chain}:`);
        top10.slice(0, 3).forEach(c => {
          console.log(`  ${c.symbol} | Hype: ${c.hypeScore} | Vol: $${c.volume24h.toLocaleString()} | Reliability: ${c.reliabilityScore}`);
        });
      });
    } else {
      filteredData = combinedData.slice(0, 20);
    }

    return new Response(JSON.stringify({ data: filteredData }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in memecoin-hype function:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
