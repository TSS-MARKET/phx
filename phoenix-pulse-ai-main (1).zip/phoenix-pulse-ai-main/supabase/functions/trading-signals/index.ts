import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, fromToken, toToken, amount } = await req.json();
    
    // Get user from auth
    const authHeader = req.headers.get("Authorization");
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: { headers: { Authorization: authHeader! } }
    });

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      throw new Error("Unauthorized");
    }

    // Check if user has elite subscription
    const { data: subscription } = await supabase
      .from('user_subscriptions')
      .select('tier, status')
      .eq('user_id', user.id)
      .single();

    if (!subscription || subscription.tier !== 'elite' || subscription.status !== 'active') {
      throw new Error("Elite subscription required for trading signals");
    }

    if (action === 'getQuote') {
      // Get quote from Jupiter
      const quote = await getJupiterQuote(fromToken, toToken, amount);
      return new Response(JSON.stringify(quote), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    } else if (action === 'analyzeTrade') {
      // Analyze trade with AI
      const analysis = await analyzeTradeWithAI(fromToken, toToken, amount);
      return new Response(JSON.stringify(analysis), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Invalid action" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Trading signals error:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

async function getJupiterQuote(inputMint: string, outputMint: string, amount: number) {
  try {
    const url = `https://quote-api.jup.ag/v6/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amount}&slippageBps=50`;
    const response = await fetch(url);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Jupiter quote error:", error);
    throw new Error("Failed to fetch Jupiter quote");
  }
}

async function analyzeTradeWithAI(fromToken: string, toToken: string, amount: number) {
  try {
    // Fetch market data for both tokens
    const [fromData, toData] = await Promise.all([
      fetchTokenData(fromToken),
      fetchTokenData(toToken),
    ]);

    // Calculate AI confidence score
    const volumeScore = calculateVolumeConfidence(toData.volume24h);
    const liquidityScore = calculateLiquidityConfidence(toData.liquidity);
    const momentumScore = calculateMomentumScore(toData.priceChange24h);
    const sentimentScore = await fetchSentimentScore(toToken);

    const aiConfidence = Math.min(100, Math.round(
      volumeScore * 0.3 +
      liquidityScore * 0.25 +
      momentumScore * 0.25 +
      sentimentScore * 0.2
    ));

    // Generate trade recommendation
    let recommendation = 'hold';
    let reasoning = '';

    if (aiConfidence > 75) {
      recommendation = 'strong_buy';
      reasoning = '🔥 High confidence trade. Strong volume, momentum, and sentiment alignment detected.';
    } else if (aiConfidence > 60) {
      recommendation = 'buy';
      reasoning = '⚡ Moderate confidence. Favorable conditions with acceptable risk/reward.';
    } else if (aiConfidence > 40) {
      recommendation = 'hold';
      reasoning = '📊 Neutral signal. Wait for clearer market direction.';
    } else {
      recommendation = 'avoid';
      reasoning = '⚠️ Low confidence. Insufficient volume or adverse conditions detected.';
    }

    return {
      recommendation,
      aiConfidence,
      reasoning,
      entryPrice: toData.price,
      targetPrice: toData.price * (1 + (aiConfidence / 200)), // Target based on confidence
      stopLoss: toData.price * 0.92, // 8% stop loss
      riskLevel: aiConfidence > 70 ? 'low' : aiConfidence > 50 ? 'medium' : 'high',
      volumeScore,
      liquidityScore,
      momentumScore,
      sentimentScore,
    };
  } catch (error) {
    console.error("AI analysis error:", error);
    throw error;
  }
}

async function fetchTokenData(tokenAddress: string) {
  try {
    const response = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${tokenAddress}`);
    const data = await response.json();
    
    if (data.pairs && data.pairs.length > 0) {
      const pair = data.pairs[0];
      return {
        price: parseFloat(pair.priceUsd || 0),
        volume24h: pair.volume?.h24 || 0,
        liquidity: pair.liquidity?.usd || 0,
        priceChange24h: pair.priceChange?.h24 || 0,
      };
    }
    
    return { price: 0, volume24h: 0, liquidity: 0, priceChange24h: 0 };
  } catch (error) {
    console.error("Token data fetch error:", error);
    return { price: 0, volume24h: 0, liquidity: 0, priceChange24h: 0 };
  }
}

async function fetchSentimentScore(tokenAddress: string): Promise<number> {
  // Simplified sentiment analysis - in production, integrate with social APIs
  try {
    // Could integrate with LunarCrush or other sentiment APIs
    return Math.floor(Math.random() * 40) + 30; // Placeholder: 30-70 range
  } catch (error) {
    return 50;
  }
}

function calculateVolumeConfidence(volume: number): number {
  if (volume > 5000000) return 30;
  if (volume > 1000000) return 25;
  if (volume > 500000) return 20;
  if (volume > 100000) return 15;
  return 10;
}

function calculateLiquidityConfidence(liquidity: number): number {
  if (liquidity > 2000000) return 25;
  if (liquidity > 1000000) return 20;
  if (liquidity > 500000) return 15;
  return 10;
}

function calculateMomentumScore(priceChange: number): number {
  if (priceChange > 30) return 25;
  if (priceChange > 15) return 20;
  if (priceChange > 5) return 15;
  if (priceChange < -15) return 5;
  return 10;
}