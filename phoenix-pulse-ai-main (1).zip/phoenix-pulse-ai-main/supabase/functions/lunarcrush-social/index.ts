import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { endpoint = 'assets', symbol } = await req.json();
    
    const apiKey = Deno.env.get('LUNARCRUSH_API_KEY') || '4pklxxwlwwq2b4j8lpufc0rbuhmheiq8fvnscyuyb';

    const fetchLunar = async (ep: string) => {
      const base = `https://lunarcrush.com/api4/public/${ep}`;
      const params = new URLSearchParams();
      if (symbol) params.append('symbol', symbol);
      params.append('limit', '15');
      const fullUrl = params.toString() ? `${base}?${params.toString()}` : base;
      console.log('Fetching LunarCrush data:', fullUrl);
      const res = await fetch(fullUrl, { headers: { 'Authorization': `Bearer ${apiKey}` } });
      try {
        return await res.json();
      } catch (_) {
        return null;
      }
    };

    const endpointsToTry = Array.from(new Set([endpoint, 'assets', 'coins', 'markets'].filter(Boolean)));
    let lunarData: any = null;

    for (const ep of endpointsToTry) {
      const json = await fetchLunar(ep);
      if (!json) continue;
      const items = Array.isArray(json) ? json : (json.data || json.coins || json.items || []);
      if (Array.isArray(items) && items.length > 0) {
        lunarData = items;
        break;
      }
    }

    if (lunarData) {
      const mapped = (lunarData as any[]).map((coin: any, idx: number) => ({
        id: coin.id || coin.symbol || coin.name || idx,
        name: coin.name || coin.symbol || `Asset ${idx + 1}`,
        symbol: (coin.symbol || coin.ticker || '').toString().toUpperCase(),
        galaxy_score: coin.galaxy_score || coin.galaxyscore || coin.score || 0,
        alt_rank: coin.alt_rank || 1000,
        icon: coin.icon || coin.logo || coin.image || coin.small,
        social_volume: coin.social_volume || coin.volume_social || coin.interactions || 0,
      }));

      return new Response(JSON.stringify({ data: mapped }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Fallback to CoinGecko trending if LunarCrush endpoints fail
    const cgUrl = 'https://api.coingecko.com/api/v3/search/trending';
    console.log('LunarCrush unavailable, using CoinGecko trending fallback:', cgUrl);
    const cgRes = await fetch(cgUrl, { headers: { 'accept': 'application/json' } });
    const cgData = await cgRes.json();
    const mapped = (cgData?.coins || []).map((c: any, idx: number) => ({
      id: c.item?.id || idx,
      name: c.item?.name || c.item?.symbol || `Asset ${idx + 1}`,
      symbol: (c.item?.symbol || '').toUpperCase(),
      galaxy_score: Math.min(100, 60 + (6 - (c.item?.score ?? idx)) * 6),
      alt_rank: 100 + (c.item?.score ?? idx),
      icon: c.item?.small,
      social_volume: 50 + ((c.item?.score ?? 0) * 15),
    }));

    return new Response(JSON.stringify({ data: mapped }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in lunarcrush-social function:', error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
