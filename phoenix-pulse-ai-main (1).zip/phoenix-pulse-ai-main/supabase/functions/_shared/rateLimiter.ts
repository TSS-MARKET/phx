import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.77.0';

interface RateLimitConfig {
  maxRequests: number;
  windowMinutes: number;
}

export async function checkRateLimit(
  req: Request,
  supabase: any,
  config: RateLimitConfig = { maxRequests: 100, windowMinutes: 1 }
): Promise<{ allowed: boolean; remaining: number; resetAt: Date }> {
  // Get identifier (IP address or authenticated user)
  const identifier = req.headers.get('x-forwarded-for') || 
                    req.headers.get('x-real-ip') || 
                    'anonymous';
  
  const rateLimitKey = `${identifier}:${new Date().toISOString().slice(0, 16)}`; // Per minute key
  const now = new Date();

  try {
    // Get or create rate limit entry
    const { data: existing, error: fetchError } = await supabase
      .from('rate_limits')
      .select('*')
      .eq('key', rateLimitKey)
      .single();

    const windowStart = new Date(now.getTime() - config.windowMinutes * 60 * 1000);

    if (fetchError && fetchError.code !== 'PGRST116') {
      console.error('Rate limit fetch error:', fetchError);
      // On error, allow the request but log it
      return { allowed: true, remaining: config.maxRequests - 1, resetAt: new Date(now.getTime() + config.windowMinutes * 60 * 1000) };
    }

    if (!existing || new Date(existing.window_start) < windowStart) {
      // Create new window
      const { error: upsertError } = await supabase
        .from('rate_limits')
        .upsert({
          key: rateLimitKey,
          count: 1,
          window_start: now,
          updated_at: now,
        });

      if (upsertError) {
        console.error('Rate limit upsert error:', upsertError);
      }

      return { 
        allowed: true, 
        remaining: config.maxRequests - 1,
        resetAt: new Date(now.getTime() + config.windowMinutes * 60 * 1000)
      };
    }

    // Check if limit exceeded
    if (existing.count >= config.maxRequests) {
      const resetAt = new Date(new Date(existing.window_start).getTime() + config.windowMinutes * 60 * 1000);
      return { allowed: false, remaining: 0, resetAt };
    }

    // Increment counter
    const { error: updateError } = await supabase
      .from('rate_limits')
      .update({ 
        count: existing.count + 1,
        updated_at: now,
      })
      .eq('key', rateLimitKey);

    if (updateError) {
      console.error('Rate limit update error:', updateError);
    }

    return { 
      allowed: true, 
      remaining: config.maxRequests - existing.count - 1,
      resetAt: new Date(new Date(existing.window_start).getTime() + config.windowMinutes * 60 * 1000)
    };
  } catch (error) {
    console.error('Rate limit check error:', error);
    // On error, allow the request
    return { allowed: true, remaining: config.maxRequests - 1, resetAt: new Date(now.getTime() + config.windowMinutes * 60 * 1000) };
  }
}

export function rateLimitHeaders(remaining: number, resetAt: Date) {
  return {
    'X-RateLimit-Remaining': remaining.toString(),
    'X-RateLimit-Reset': resetAt.toISOString(),
  };
}
