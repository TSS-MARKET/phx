import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const COINGECKO_API_KEY = Deno.env.get('COINGECKO_API_KEY') || 'CG-UzDfETn3kQjL4AsbvWvBtmZY';
const COINGECKO_BASE_URL = 'https://api.coingecko.com/api/v3';

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { endpoint, params } = await req.json();
    
    console.log('CoinGecko request:', { endpoint, params });

    // Build URL with params
    const url = new URL(`${COINGECKO_BASE_URL}${endpoint}`);
    if (params) {
      Object.keys(params).forEach(key => {
        url.searchParams.append(key, params[key]);
      });
    }

    const response = await fetch(url.toString(), {
      headers: {
        'x-cg-demo-api-key': COINGECKO_API_KEY,
        'accept': 'application/json',
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('CoinGecko API error:', response.status, errorText);
      
      // Return cached/fallback data for rate limit errors
      if (response.status === 429) {
        console.log('Rate limit hit, returning fallback data');
        return new Response(JSON.stringify({ 
          error: 'Rate limit exceeded',
          fallback: true,
          data: endpoint === '/global' ? { data: { active_cryptocurrencies: 19000, total_market_cap: { usd: 3700000000000 }}} : []
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      throw new Error(`CoinGecko API error: ${response.status}`);
    }

    const data = await response.json();
    console.log('CoinGecko response received');

    return new Response(JSON.stringify(data), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in coingecko-data function:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
