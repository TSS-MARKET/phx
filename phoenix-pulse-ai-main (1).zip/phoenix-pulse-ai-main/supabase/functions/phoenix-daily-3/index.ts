import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Check if picks already exist for today
    const today = new Date().toISOString().split('T')[0];
    const { data: existingPicks } = await supabase
      .from('phoenix_daily_picks')
      .select('*')
      .eq('pick_date', today);

    if (existingPicks && existingPicks.length === 3) {
      return new Response(JSON.stringify(existingPicks), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fetch data from multiple sources
    const [dexData, lunarData, coinGeckoData] = await Promise.all([
      fetchDexScreenerData(),
      fetchLunarCrushData(),
      fetchCoinGeckoTrending(),
    ]);

    // Combine and score coins
    const scoredCoins = await scoreCoins(dexData, lunarData, coinGeckoData);
    
    // Get top 3
    const top3 = scoredCoins.slice(0, 3);

    // Delete old picks and insert new ones
    await supabase.from('phoenix_daily_picks').delete().eq('pick_date', today);
    
    const picksToInsert = top3.map((coin, index) => ({
      pick_date: today,
      rank: index + 1,
      coin_id: coin.id,
      coin_name: coin.name,
      coin_symbol: coin.symbol,
      current_price: coin.price,
      price_change_24h: coin.priceChange24h,
      market_cap: coin.marketCap,
      volume_24h: coin.volume24h,
      ai_score: coin.aiScore,
      ai_entry_price: coin.entryPrice,
      ai_exit_price: coin.exitPrice,
      ai_stop_loss: coin.stopLoss,
      risk_level: coin.riskLevel,
      ai_reasoning: coin.reasoning,
      sentiment_score: coin.sentimentScore,
    }));

    const { data: newPicks, error } = await supabase
      .from('phoenix_daily_picks')
      .insert(picksToInsert)
      .select();

    if (error) throw error;

    return new Response(JSON.stringify(newPicks), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error generating Phoenix Daily 3:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

async function fetchDexScreenerData() {
  try {
    const response = await fetch("https://api.dexscreener.com/latest/dex/search?q=solana");
    const data = await response.json();
    return data.pairs || [];
  } catch (error) {
    console.error("DexScreener error:", error);
    return [];
  }
}

async function fetchLunarCrushData() {
  try {
    const apiKey = Deno.env.get("LUNARCRUSH_API_KEY");
    const response = await fetch(`https://lunarcrush.com/api4/public/coins/list/v2?sort=galaxy_score`, {
      headers: apiKey ? { "Authorization": `Bearer ${apiKey}` } : {},
    });
    const data = await response.json();
    return data.data || [];
  } catch (error) {
    console.error("LunarCrush error:", error);
    return [];
  }
}

async function fetchCoinGeckoTrending() {
  try {
    const apiKey = Deno.env.get("COINGECKO_API_KEY");
    const response = await fetch("https://api.coingecko.com/api/v3/search/trending", {
      headers: apiKey ? { "x-cg-pro-api-key": apiKey } : {},
    });
    const data = await response.json();
    return data.coins || [];
  } catch (error) {
    console.error("CoinGecko error:", error);
    return [];
  }
}

async function scoreCoins(dexData: any[], lunarData: any[], coinGeckoData: any[]) {
  const coinMap = new Map();

  // Process DexScreener data (volume, liquidity momentum)
  dexData.forEach((pair: any) => {
    if (!pair.baseToken) return;
    
    const key = pair.baseToken.symbol?.toLowerCase();
    if (!key) return;

    const volumeScore = calculateVolumeScore(pair.volume?.h24 || 0);
    const liquidityScore = calculateLiquidityScore(pair.liquidity?.usd || 0);
    const priceChangeScore = calculatePriceChangeScore(pair.priceChange?.h24 || 0);

    coinMap.set(key, {
      id: pair.baseToken.address || key,
      name: pair.baseToken.name || key,
      symbol: pair.baseToken.symbol || key,
      price: parseFloat(pair.priceUsd || 0),
      priceChange24h: pair.priceChange?.h24 || 0,
      marketCap: pair.fdv || 0,
      volume24h: pair.volume?.h24 || 0,
      volumeScore,
      liquidityScore,
      priceChangeScore,
      sentimentScore: 0,
      trendingScore: 0,
    });
  });

  // Add sentiment from LunarCrush
  lunarData.forEach((coin: any) => {
    const key = coin.symbol?.toLowerCase();
    if (!key) return;

    const existing = coinMap.get(key);
    const sentimentScore = (coin.galaxy_score || 0) / 100 * 30;
    
    if (existing) {
      existing.sentimentScore = sentimentScore;
    }
  });

  // Add trending score from CoinGecko
  coinGeckoData.forEach((item: any, index: number) => {
    const coin = item.item;
    const key = coin.symbol?.toLowerCase();
    if (!key) return;

    const existing = coinMap.get(key);
    const trendingScore = Math.max(0, 20 - index * 2);
    
    if (existing) {
      existing.trendingScore = trendingScore;
    }
  });

  // Calculate final AI score and generate recommendations
  const scoredCoins = Array.from(coinMap.values()).map((coin: any) => {
    const aiScore = Math.min(100, Math.round(
      coin.volumeScore * 0.3 +
      coin.liquidityScore * 0.2 +
      coin.priceChangeScore * 0.2 +
      coin.sentimentScore * 0.2 +
      coin.trendingScore * 0.1
    ));

    // Calculate entry/exit based on current price
    const currentPrice = coin.price || 0;
    const entryPrice = currentPrice * 0.98; // 2% below current
    const exitPrice = currentPrice * (1 + (aiScore / 100)); // Target based on score
    const stopLoss = currentPrice * 0.90; // 10% stop loss

    // Determine risk level
    let riskLevel = 'medium';
    if (coin.marketCap > 100000000) riskLevel = 'low';
    else if (coin.marketCap < 10000000) riskLevel = 'high';

    const reasoning = generateAIReasoning(coin, aiScore);

    return {
      ...coin,
      aiScore,
      entryPrice,
      exitPrice,
      stopLoss,
      riskLevel,
      reasoning,
    };
  });

  // Sort by AI score
  return scoredCoins.sort((a, b) => b.aiScore - a.aiScore);
}

function calculateVolumeScore(volume: number): number {
  if (volume > 10000000) return 40;
  if (volume > 5000000) return 35;
  if (volume > 1000000) return 30;
  if (volume > 500000) return 20;
  return 10;
}

function calculateLiquidityScore(liquidity: number): number {
  if (liquidity > 5000000) return 25;
  if (liquidity > 1000000) return 20;
  if (liquidity > 500000) return 15;
  return 10;
}

function calculatePriceChangeScore(priceChange: number): number {
  const absChange = Math.abs(priceChange);
  if (priceChange > 50) return 25;
  if (priceChange > 20) return 20;
  if (priceChange > 10) return 15;
  if (priceChange < -20) return 5;
  return 10;
}

function generateAIReasoning(coin: any, score: number): string {
  const reasons = [];
  
  if (coin.volumeScore > 30) reasons.push("Strong 24h volume surge");
  if (coin.liquidityScore > 20) reasons.push("Excellent liquidity depth");
  if (coin.priceChange24h > 20) reasons.push("Significant bullish momentum");
  if (coin.sentimentScore > 20) reasons.push("High social sentiment");
  if (coin.trendingScore > 15) reasons.push("Trending across platforms");
  
  if (score > 80) {
    return `🔥 PHOENIX ELITE PICK: ${reasons.join(". ")}. AI predicts strong continuation with ${score}% confidence.`;
  } else if (score > 60) {
    return `⚡ STRONG SIGNAL: ${reasons.join(". ")}. Moderate upside potential detected.`;
  } else {
    return `📊 WATCH LIST: ${reasons.join(". ")}. Monitor for entry opportunity.`;
  }
}