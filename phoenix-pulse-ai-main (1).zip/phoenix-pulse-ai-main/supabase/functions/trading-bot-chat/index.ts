import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const ADMIN_WALLET = '4BPeopNXjATGrewivH58WNtBAJs9xykvhisTLVPHNsx2';

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { message, walletAddress } = await req.json();
    console.log('Trading bot chat request:', { message, walletAddress });

    if (!walletAddress) {
      throw new Error('Wallet address required');
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const lovableApiKey = Deno.env.get("LOVABLE_API_KEY")!;
    const quicknodeUrl = Deno.env.get("QUICKNODE_API_URL")!;

    const supabase = createClient(supabaseUrl, supabaseKey);

    // Check subscription
    const { data: subscription } = await supabase
      .from('user_subscriptions')
      .select('tier, status')
      .eq('user_id', walletAddress)
      .single();

    const isAdmin = walletAddress === ADMIN_WALLET;
    const hasAccess = isAdmin || (subscription?.tier === 'elite' && subscription?.status === 'active');

    if (!hasAccess) {
      return new Response(
        JSON.stringify({ error: 'Elite subscription required for AI Trading Bot' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get recent Solana data from QuickNode if available
    let blockchainContext = '';
    try {
      const rpcResponse = await fetch(quicknodeUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          id: 1,
          method: 'getHealth'
        })
      });
      const rpcData = await rpcResponse.json();
      blockchainContext = `Solana network status: ${rpcData.result || 'ok'}`;
    } catch (error) {
      console.error('QuickNode RPC error:', error);
      blockchainContext = 'Unable to fetch blockchain data';
    }

    // Call Lovable AI for trading assistance
    const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${lovableApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          {
            role: 'system',
            content: `You are Phoenix AI, an elite Solana trading assistant. You help users execute trades on Jupiter DEX via voice commands.

${blockchainContext}

Your capabilities:
- Buy/Sell tokens on Solana via Jupiter aggregator
- Set Take Profit (TP) and Stop Loss (SL) levels
- Configure trailing stop losses
- Provide real-time market analysis
- Execute trades with confidence levels

Response format:
- For BUY commands: Confirm token, amount, and estimated output
- For SELL commands: Confirm closing position details
- For TP/SL commands: Confirm percentage and trigger levels
- For analysis: Provide confidence %, entry/exit recommendations
- Keep responses concise, actionable, and professional

Always format your response with:
✅ for confirmations
⚡ for action items
📊 for analysis
🔥 for high-confidence signals
⚠️ for warnings`
          },
          {
            role: 'user',
            content: message
          }
        ],
        temperature: 0.7,
        max_tokens: 300
      }),
    });

    if (!aiResponse.ok) {
      if (aiResponse.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit reached. Please try again later.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (aiResponse.status === 402) {
        return new Response(
          JSON.stringify({ error: 'AI service requires payment. Please contact support.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      throw new Error(`AI Gateway error: ${aiResponse.status}`);
    }

    const aiData = await aiResponse.json();
    const botResponse = aiData.choices[0].message.content;

    console.log('AI response generated successfully');

    return new Response(
      JSON.stringify({ response: botResponse }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Trading bot chat error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
