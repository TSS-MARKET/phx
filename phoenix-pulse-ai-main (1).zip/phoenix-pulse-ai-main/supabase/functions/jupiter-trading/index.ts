import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.77.0';
import "https://deno.land/x/xhr@0.1.0/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const ADMIN_WALLET = '4BPeopNXjATGrewivH58WNtBAJs9xykvhisTLVPHNsx2';
const ADMIN_FEE_BPS = 20; // 0.2% = 20 basis points

// Solana token addresses
const TOKEN_ADDRESSES: Record<string, string> = {
  'SOL': 'So11111111111111111111111111111111111111112',
  'USDC': 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
  'BONK': 'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263',
  'JUP': 'JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN',
  'WIF': 'EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm'
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, fromToken, toToken, amount, walletAddress, slippage = 50 } = await req.json();

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Jupiter Trading:', { action, fromToken, toToken, amount, walletAddress });

    // Check user subscription
    const { data: subscription } = await supabase
      .from('user_subscriptions')
      .select('tier, status')
      .eq('user_id', walletAddress)
      .single();

    const hasAccess = walletAddress === ADMIN_WALLET || 
      (subscription?.tier === 'elite' && subscription?.status === 'active');

    if (!hasAccess) {
      return new Response(
        JSON.stringify({ error: 'Elite subscription required' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'getQuote') {
      // Get Jupiter quote
      const inputMint = TOKEN_ADDRESSES[fromToken] || fromToken;
      const outputMint = TOKEN_ADDRESSES[toToken] || toToken;
      const amountLamports = Math.floor(amount * 1e9); // Convert to lamports

      const quoteUrl = `https://quote-api.jup.ag/v6/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amountLamports}&slippageBps=${slippage}`;
      
      console.log('Fetching Jupiter quote:', quoteUrl);
      
      const quoteResponse = await fetch(quoteUrl);
      const quoteData = await quoteResponse.json();

      if (!quoteResponse.ok) {
        throw new Error(`Jupiter API error: ${JSON.stringify(quoteData)}`);
      }

      // Calculate fees
      const outputAmount = parseInt(quoteData.outAmount) / 1e9;
      const fee = outputAmount * (ADMIN_FEE_BPS / 10000);
      const userReceives = outputAmount - fee;

      return new Response(
        JSON.stringify({
          quote: quoteData,
          outputAmount,
          fee,
          userReceives,
          adminWallet: ADMIN_WALLET,
          priceImpact: quoteData.priceImpactPct
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'analyzeTrade') {
      // Generate AI-powered trade signal with real market data
      try {
        const coingeckoKey = Deno.env.get('COINGECKO_API_KEY');
        if (!coingeckoKey) {
          throw new Error('CoinGecko API key not configured');
        }
        
        const inputId = getCoinGeckoId(fromToken);
        const outputId = getCoinGeckoId(toToken);

        // Fetch market data for target token
        const marketResponse = await fetch(
          `https://api.coingecko.com/api/v3/coins/${outputId}?localization=false&tickers=false&community_data=false&developer_data=false`,
          { headers: { 'x-cg-pro-api-key': coingeckoKey } }
        );

        if (!marketResponse.ok) {
          throw new Error('Failed to fetch market data');
        }

        const marketData = await marketResponse.json();
        const md = marketData.market_data;

        // Calculate comprehensive AI score
        const volumeScore = calculateVolumeScore(md.total_volume.usd, md.market_cap.usd);
        const momentumScore = calculateMomentumScore(
          md.price_change_percentage_24h || 0,
          md.price_change_percentage_7d || 0
        );
        const liquidityScore = calculateLiquidityScore(md.market_cap.usd, md.total_volume.usd);
        const volatilityScore = calculateVolatilityScore(
          md.high_24h.usd,
          md.low_24h.usd,
          md.current_price.usd
        );

        const aiConfidence = Math.min(100, Math.round(
          volumeScore * 0.30 +
          momentumScore * 0.25 +
          liquidityScore * 0.25 +
          volatilityScore * 0.20
        ));

        // Generate recommendation
        let recommendation = 'hold';
        let reasoning = '';

        if (aiConfidence >= 80 && momentumScore > 18) {
          recommendation = 'strong_buy';
          reasoning = `🔥 EXCEPTIONAL opportunity detected! High volume (${volumeScore}/30), strong momentum (+${md.price_change_percentage_24h.toFixed(1)}%), optimal liquidity. Market cap: $${(md.market_cap.usd / 1e6).toFixed(1)}M.`;
        } else if (aiConfidence >= 65) {
          recommendation = 'buy';
          reasoning = `⚡ FAVORABLE conditions with ${aiConfidence}% confidence. Volume: $${(md.total_volume.usd / 1e6).toFixed(1)}M, Momentum: ${momentumScore}/25.`;
        } else if (aiConfidence >= 45) {
          recommendation = 'hold';
          reasoning = `📊 NEUTRAL signal. Mixed indicators suggest waiting for clearer direction. Confidence: ${aiConfidence}%.`;
        } else {
          recommendation = 'avoid';
          reasoning = `⚠️ CAUTION advised. Low confidence (${aiConfidence}%). Weak volume or adverse conditions detected.`;
        }

        const currentPrice = md.current_price.usd;
        const volatility = Math.abs(md.price_change_percentage_24h) / 100;
        const baseMultiplier = aiConfidence / 100;

        return new Response(
          JSON.stringify({
            recommendation,
            aiConfidence,
            reasoning,
            entryPrice: currentPrice,
            targetPrice: currentPrice * (1 + (0.08 + volatility * 0.5) * baseMultiplier),
            stopLoss: currentPrice * (1 - (0.06 + volatility * 0.2)),
            riskLevel: amount > 100 ? 'high' : amount > 50 ? 'medium' : 'low',
            marketData: {
              volume24h: md.total_volume.usd,
              marketCap: md.market_cap.usd,
              priceChange24h: md.price_change_percentage_24h,
              priceChange7d: md.price_change_percentage_7d
            }
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      } catch (error) {
        console.error('Trade analysis error:', error);
        // Fallback to basic analysis
        return new Response(
          JSON.stringify({
            recommendation: 'hold',
            aiConfidence: 50,
            reasoning: '📊 Unable to fetch full market data. Proceed with caution.',
            entryPrice: 0,
            targetPrice: 0,
            stopLoss: 0,
            riskLevel: 'medium'
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    if (action === 'executeTrade') {
      // In production, this would:
      // 1. Create Jupiter swap transaction
      // 2. Send to user for signing
      // 3. Monitor transaction
      // 4. Collect fee and send to admin wallet
      
      // For now, simulate successful execution
      const mockTx = `tx_${Date.now()}_${Math.random().toString(36).substring(7)}`;
      
      // Record fee collection
      await supabase.from('admin_analytics').upsert({
        date: new Date().toISOString().split('T')[0],
        total_fees_collected: amount * 0.002,
        total_volume: amount,
        total_trades: 1
      }, {
        onConflict: 'date',
        ignoreDuplicates: false
      });

      return new Response(
        JSON.stringify({
          success: true,
          signature: mockTx,
          adminWallet: ADMIN_WALLET,
          feeCollected: amount * 0.002
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Invalid action' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Jupiter trading error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function getCoinGeckoId(token: string): string {
  const mapping: Record<string, string> = {
    'SOL': 'solana',
    'BONK': 'bonk',
    'JUP': 'jupiter-exchange-solana',
    'WIF': 'dogwifcoin',
    'USDC': 'usd-coin'
  };
  return mapping[token] || token.toLowerCase();
}

function calculateVolumeScore(volume: number, marketCap: number): number {
  const ratio = volume / marketCap;
  if (ratio > 0.4) return 30;
  if (ratio > 0.2) return 25;
  if (ratio > 0.1) return 20;
  if (ratio > 0.05) return 15;
  return 8;
}

function calculateMomentumScore(change24h: number, change7d: number): number {
  const momentum = (change24h * 0.6 + change7d * 0.4);
  if (momentum > 30) return 25;
  if (momentum > 15) return 20;
  if (momentum > 5) return 15;
  if (momentum > 0) return 10;
  return 5;
}

function calculateLiquidityScore(marketCap: number, volume: number): number {
  if (marketCap > 500000000 && volume > 50000000) return 25;
  if (marketCap > 100000000 && volume > 10000000) return 20;
  if (marketCap > 50000000 && volume > 5000000) return 15;
  return 10;
}

function calculateVolatilityScore(high: number, low: number, current: number): number {
  const range = (high - low) / current;
  if (range < 0.03) return 20; // Low volatility is good
  if (range < 0.06) return 15;
  if (range < 0.10) return 10;
  return 5; // High volatility is risky
}
