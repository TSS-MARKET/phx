import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.77.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// PHX Token Mint Address (update this when token launches)
const PHX_TOKEN_MINT = 'UPDATE_WITH_ACTUAL_PHX_MINT_ADDRESS';

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { walletAddress } = await req.json();

    if (!walletAddress) {
      return new Response(
        JSON.stringify({ error: 'Wallet address is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get authenticated user
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Authorization required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Verify JWT token
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Invalid authentication' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if PHX token has launched
    if (PHX_TOKEN_MINT === 'UPDATE_WITH_ACTUAL_PHX_MINT_ADDRESS') {
      // Demo mode - return simulated holdings
      const demoBalance = Math.floor(Math.random() * 15000);
      const tier = calculateTierFromBalance(demoBalance);

      // Update user_tiers with demo data
      const { error: updateError } = await supabase
        .from('user_tiers')
        .upsert({
          user_id: user.id,
          tier,
          wallet_address: walletAddress,
          phx_balance: demoBalance,
          last_verified_at: new Date().toISOString(),
        });

      if (updateError) {
        console.error('Error updating tier:', updateError);
        throw updateError;
      }

      return new Response(
        JSON.stringify({
          tier,
          balance: demoBalance,
          walletAddress,
          demo: true,
          message: 'PHX token not yet launched - Demo mode active'
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Production mode - Query Solana blockchain via QuickNode RPC
    const quicknodeUrl = Deno.env.get('QUICKNODE_API_URL');
    if (!quicknodeUrl) {
      throw new Error('QuickNode API URL not configured');
    }

    try {
      // Use Solana JSON RPC to query token accounts
      const response = await fetch(quicknodeUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          id: 1,
          method: 'getTokenAccountsByOwner',
          params: [
            walletAddress,
            { mint: PHX_TOKEN_MINT },
            { encoding: 'jsonParsed' }
          ]
        })
      });

      const data = await response.json();
      
      let balance = 0;
      if (data.result?.value && data.result.value.length > 0) {
        balance = data.result.value[0].account.data.parsed.info.tokenAmount.uiAmount || 0;
      }

      const tier = calculateTierFromBalance(balance);

      // Store verified tier in database
      const { error: updateError } = await supabase
        .from('user_tiers')
        .upsert({
          user_id: user.id,
          tier,
          wallet_address: walletAddress,
          phx_balance: balance,
          last_verified_at: new Date().toISOString(),
        });

      if (updateError) {
        console.error('Error updating tier:', updateError);
        throw updateError;
      }

      return new Response(
        JSON.stringify({
          tier,
          balance,
          walletAddress,
          demo: false,
          verified: true
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    } catch (solanaError) {
      console.error('Solana blockchain error:', solanaError);
      return new Response(
        JSON.stringify({ 
          error: 'Failed to verify blockchain holdings',
          details: solanaError instanceof Error ? solanaError.message : 'Unknown error'
        }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
  } catch (error) {
    console.error('Verification error:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Verification failed',
        details: error instanceof Error ? error.message : 'Unknown error'
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function calculateTierFromBalance(balance: number): string {
  if (balance >= 12500) return 'elite';
  if (balance >= 2500) return 'premium';
  if (balance >= 500) return 'basic';
  return 'none';
}
