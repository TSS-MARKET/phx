import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.77.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const ADMIN_WALLET = '4BPeopNXjATGrewivH58WNtBAJs9xykvhisTLVPHNsx2';

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { tokens } = await req.json();

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const coingeckoKey = Deno.env.get('COINGECKO_API_KEY')!;
    const lunarCrushKey = Deno.env.get('LUNARCRUSH_API_KEY')!;

    const supabase = createClient(supabaseUrl, supabaseKey);

    // Generate signals for each token
    const signals = await Promise.all(
      tokens.map(async (token: any) => {
        try {
          // Fetch real market data
          const marketData = await fetchMarketData(token.coinId, coingeckoKey);
          const socialData = await fetchSocialData(token.symbol, lunarCrushKey);
          
          // Calculate AI confidence score based on multiple factors
          const volumeScore = calculateVolumeScore(marketData.volume24h, marketData.marketCap);
          const momentumScore = calculateMomentumScore(marketData.priceChange24h, marketData.priceChange7d);
          const liquidityScore = calculateLiquidityScore(marketData.marketCap, marketData.volume24h);
          const socialScore = calculateSocialScore(socialData);
          const technicalScore = calculateTechnicalScore(marketData);

          const aiConfidence = Math.min(100, Math.max(0, Math.round(
            volumeScore * 0.25 +
            momentumScore * 0.20 +
            liquidityScore * 0.20 +
            socialScore * 0.20 +
            technicalScore * 0.15
          )));

          // Ensure confidence is a valid number
          const validConfidence = isNaN(aiConfidence) ? 50 : aiConfidence;

          // Generate recommendation based on comprehensive analysis
          let recommendation = 'HOLD';
          let reasoning = '';

          if (validConfidence >= 80 && momentumScore > 18 && volumeScore > 22) {
            recommendation = 'STRONG BUY';
            reasoning = `🔥 EXCEPTIONAL: High volume surge (${volumeScore}/25), strong momentum (+${marketData.priceChange24h.toFixed(1)}%), and positive social sentiment. Market cap: $${(marketData.marketCap / 1e6).toFixed(1)}M.`;
          } else if (validConfidence >= 65 && momentumScore > 15) {
            recommendation = 'BUY';
            reasoning = `⚡ FAVORABLE: Good entry point with ${validConfidence}% confidence. Volume: $${(marketData.volume24h / 1e6).toFixed(1)}M, Momentum score: ${momentumScore}/20.`;
          } else if (validConfidence >= 45) {
            recommendation = 'HOLD';
            reasoning = `📊 NEUTRAL: Mixed signals. Wait for clearer momentum. Current confidence: ${validConfidence}%.`;
          } else {
            recommendation = 'AVOID';
            reasoning = `⚠️ CAUTION: Low confidence (${validConfidence}%). Weak volume or adverse market conditions detected.`;
          }

          // Calculate entry, TP, and SL based on volatility and confidence
          const volatility = Math.max(0.01, Math.min(0.5, Math.abs(marketData.priceChange24h) / 100));
          const baseMultiplier = Math.max(0.3, validConfidence / 100);
          
          const entryPrice = marketData.currentPrice;
          const targetPrice = entryPrice * (1 + (0.08 + volatility * 0.5) * baseMultiplier);
          const stopLoss = entryPrice * (1 - (0.06 + volatility * 0.2));

          return {
            token: token.symbol,
            symbol: `${token.symbol}/USDC`,
            coinId: token.coinId,
            entryPrice,
            takeProfit: targetPrice,
            stopLoss,
            confidence: validConfidence,
            timestamp: new Date().toISOString(),
            recommendation,
            reasoning,
            marketData: {
              volume24h: marketData.volume24h,
              marketCap: marketData.marketCap,
              priceChange24h: marketData.priceChange24h,
              priceChange7d: marketData.priceChange7d
            }
          };
        } catch (error) {
          console.error(`Error generating signal for ${token.symbol}:`, error);
          return null;
        }
      })
    );

    return new Response(
      JSON.stringify({ signals: signals.filter(Boolean) }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('AI trading signals error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

async function fetchMarketData(coinId: string, apiKey: string) {
  const response = await fetch(
    `https://api.coingecko.com/api/v3/coins/${coinId}?localization=false&tickers=false&community_data=false&developer_data=false`,
    { headers: { 'x-cg-pro-api-key': apiKey } }
  );

  if (!response.ok) throw new Error('Failed to fetch market data');

  const data = await response.json();
  return {
    currentPrice: data.market_data.current_price.usd,
    volume24h: data.market_data.total_volume.usd,
    marketCap: data.market_data.market_cap.usd,
    priceChange24h: data.market_data.price_change_percentage_24h || 0,
    priceChange7d: data.market_data.price_change_percentage_7d || 0,
    high24h: data.market_data.high_24h.usd,
    low24h: data.market_data.low_24h.usd,
    ath: data.market_data.ath.usd,
    atl: data.market_data.atl.usd
  };
}

async function fetchSocialData(symbol: string, apiKey: string) {
  try {
    const response = await fetch(
      `https://lunarcrush.com/api4/public/coins/${symbol}/v1`,
      { headers: { 'Authorization': `Bearer ${apiKey}` } }
    );

    if (!response.ok) return { sentiment: 50, socialVolume: 0 };

    const data = await response.json();
    return {
      sentiment: data.data?.sentiment || 50,
      socialVolume: data.data?.social_volume || 0,
      galaxyScore: data.data?.galaxy_score || 50
    };
  } catch (error) {
    return { sentiment: 50, socialVolume: 0, galaxyScore: 50 };
  }
}

function calculateVolumeScore(volume: number, marketCap: number): number {
  const volumeToMcap = volume / marketCap;
  if (volumeToMcap > 0.3) return 25;
  if (volumeToMcap > 0.15) return 22;
  if (volumeToMcap > 0.08) return 18;
  if (volumeToMcap > 0.04) return 14;
  return 8;
}

function calculateMomentumScore(change24h: number, change7d: number): number {
  const momentum = (change24h * 0.6 + change7d * 0.4);
  if (momentum > 25) return 20;
  if (momentum > 12) return 17;
  if (momentum > 5) return 14;
  if (momentum > 0) return 10;
  if (momentum > -10) return 6;
  return 3;
}

function calculateLiquidityScore(marketCap: number, volume: number): number {
  if (marketCap > 500000000 && volume > 50000000) return 20;
  if (marketCap > 100000000 && volume > 10000000) return 17;
  if (marketCap > 50000000 && volume > 5000000) return 14;
  if (marketCap > 10000000) return 10;
  return 6;
}

function calculateSocialScore(socialData: any): number {
  const { sentiment, socialVolume, galaxyScore } = socialData;
  const avgScore = (sentiment + galaxyScore) / 2;
  const volumeBonus = socialVolume > 1000 ? 5 : 0;
  return Math.min(20, Math.round(avgScore / 5) + volumeBonus);
}

function calculateTechnicalScore(marketData: any): number {
  const { currentPrice, high24h, low24h, ath, atl } = marketData;
  const range24h = high24h - low24h;
  const position = (currentPrice - low24h) / range24h;
  const athDistance = (ath - currentPrice) / ath;
  
  let score = 7.5;
  if (position > 0.7) score += 4;
  else if (position > 0.5) score += 2;
  if (athDistance > 0.8) score += 3.5;
  
  return Math.round(score);
}
