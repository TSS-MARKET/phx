import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { currencies, filter } = await req.json();
    
    const apiKey = Deno.env.get('CRYPTOPANIC_API_KEY') || '47778a4f726b34d0188b2bc1232b1f0d83494cd1';
    // Build URL without restrictive filters to get more news
    let url = `https://cryptopanic.com/api/v1/posts/?auth_token=${apiKey}&public=true`;
    if (currencies) url += `&currencies=${currencies}`;
    if (filter) url += `&filter=${filter}`;

    console.log('Fetching CryptoPanic news:', url);

    const response = await fetch(url);
    
    // Check if response is JSON before parsing
    const contentType = response.headers.get('content-type');
    const isJson = contentType?.includes('application/json');
    
    // If not JSON or not successful, immediately use fallback
    if (!response.ok || !isJson) {
      console.log('CryptoPanic unavailable (non-JSON or error response), using CoinGecko fallback');
      const fallbackUrl = 'https://api.coingecko.com/api/v3/status_updates?per_page=10&page=1';
      const cgRes = await fetch(fallbackUrl, { headers: { 'accept': 'application/json' } });
      const cgData = await cgRes.json();

      const mapped = {
        results: (cgData?.status_updates || []).map((item: any, idx: number) => ({
          id: `${item.project?.id || 'cg'}-${idx}`,
          title: item.project ? `${item.project.name}: ${item.description}` : item.description,
          url: item.project?.homepage || 'https://www.coingecko.com',
          source: { title: 'CoinGecko Status' },
          created_at: item.created_at || new Date().toISOString(),
          currencies: item.project ? [{ code: item.project.symbol?.toUpperCase?.() || 'CRYPTO' }] : [],
          votes: { positive: 0, negative: 0 },
        }))
      };

      return new Response(JSON.stringify(mapped), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const data = await response.json();
    console.log('CryptoPanic response:', data);

    // Fallback: If CryptoPanic quota exceeded, invalid response, or empty results, fetch CoinGecko status updates
    if (!data?.results || data?.status === 'api_error' || data.results.length === 0) {
      const fallbackUrl = 'https://api.coingecko.com/api/v3/status_updates?per_page=10&page=1';
      console.log('CryptoPanic unavailable, using CoinGecko status updates fallback:', fallbackUrl);
      const cgRes = await fetch(fallbackUrl, { headers: { 'accept': 'application/json' } });
      const cgData = await cgRes.json();

      // Map CoinGecko status updates to a CryptoPanic-like shape
      const mapped = {
        results: (cgData?.status_updates || []).map((item: any, idx: number) => ({
          id: `${item.project?.id || 'cg'}-${idx}`,
          title: item.project ? `${item.project.name}: ${item.description}` : item.description,
          url: item.project?.homepage || 'https://www.coingecko.com',
          source: { title: 'CoinGecko Status' },
          created_at: item.created_at || new Date().toISOString(),
          currencies: item.project ? [{ code: item.project.symbol?.toUpperCase?.() || 'CRYPTO' }] : [],
          votes: { positive: 0, negative: 0 },
        }))
      };

      return new Response(JSON.stringify(mapped), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify(data), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in cryptopanic-news function:', error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
