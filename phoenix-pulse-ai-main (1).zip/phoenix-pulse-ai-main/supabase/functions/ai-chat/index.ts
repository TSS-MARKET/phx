import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';
import { checkRateLimit, rateLimitHeaders } from '../_shared/rateLimiter.ts';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  // Initialize Supabase for rate limiting
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseKey);

  // Check rate limit (60 requests per minute)
  const rateLimit = await checkRateLimit(req, supabase, { maxRequests: 60, windowMinutes: 1 });
  
  if (!rateLimit.allowed) {
    return new Response(
      JSON.stringify({ 
        error: 'Rate limit exceeded. Please try again later.',
        resetAt: rateLimit.resetAt.toISOString()
      }),
      { 
        status: 429, 
        headers: { 
          ...corsHeaders, 
          ...rateLimitHeaders(rateLimit.remaining, rateLimit.resetAt),
          'Content-Type': 'application/json' 
        } 
      }
    );
  }

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    // Validate message lengths to prevent abuse
    const MAX_MESSAGE_LENGTH = 10000;
    const MAX_TOTAL_LENGTH = 50000;

    if (!Array.isArray(messages)) {
      return new Response(
        JSON.stringify({ error: "Invalid request format" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    for (const msg of messages) {
      if (!msg.content || typeof msg.content !== 'string') {
        return new Response(
          JSON.stringify({ error: "Invalid message format" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (msg.content.length > MAX_MESSAGE_LENGTH) {
        return new Response(
          JSON.stringify({ error: `Message too long (max ${MAX_MESSAGE_LENGTH} characters)` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    const totalLength = messages.reduce((sum, m) => sum + (m.content?.length || 0), 0);
    if (totalLength > MAX_TOTAL_LENGTH) {
      return new Response(
        JSON.stringify({ error: "Conversation too long. Please start a new conversation." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Supabase client already initialized for rate limiting above

    // Extract potential coin mentions from the user's query
    const userQuery = messages[messages.length - 1]?.content?.toLowerCase() || "";
    
    // Fetch current market data to enhance AI responses
    let marketContext = "";
    let mentionedCoin: any = null;
    
    try {
      // First, try to search for the specific coin mentioned in query
      const coinNameMatch = userQuery.match(/(?:analyze|analysis for|about|for)\s+([a-z0-9\s-]+?)(?:\s+\(|$|\s+coin|\s+crypto)/i);
      
      if (coinNameMatch) {
        const searchQuery = coinNameMatch[1].trim();
        
        // Search for the coin using CoinGecko search
        const { data: searchData, error: searchError } = await supabase.functions.invoke("coingecko-data", {
          body: {
            endpoint: "/search",
            params: {
              query: searchQuery,
            },
          },
        });

        if (!searchError && searchData?.coins?.length > 0) {
          // Found the coin in search results
          const foundCoin = searchData.coins[0];
          mentionedCoin = { id: foundCoin.id, name: foundCoin.name, symbol: foundCoin.symbol };
        }
      }

      // Fetch top 250 coins for general market context
      const { data: coinsData, error: coinsError } = await supabase.functions.invoke("coingecko-data", {
        body: {
          endpoint: "/coins/markets",
          params: {
            vs_currency: "usd",
            order: "market_cap_desc",
            per_page: "250",
            page: "1",
            sparkline: "false",
            price_change_percentage: "1h,24h,7d",
          },
        },
      });

      if (!coinsError && coinsData) {
        // Always include top 10
        const topCoins = coinsData.slice(0, 10).map((coin: any) => 
          `${coin.name} (${coin.symbol.toUpperCase()}): $${coin.current_price.toLocaleString()}, 24h: ${coin.price_change_percentage_24h?.toFixed(2)}%, 7d: ${coin.price_change_percentage_7d_in_currency?.toFixed(2)}%, Vol: $${(coin.total_volume / 1e9).toFixed(2)}B, MCap: $${(coin.market_cap / 1e9).toFixed(2)}B, Rank: #${coin.market_cap_rank}`
        ).join('\n');
        marketContext += `\n\nTop 10 Cryptocurrencies:\n${topCoins}`;

        // If no specific coin found from search, try to find it in top 250
        if (!mentionedCoin) {
          mentionedCoin = coinsData.find((coin: any) => 
            userQuery.includes(coin.name.toLowerCase()) || 
            userQuery.includes(coin.symbol.toLowerCase()) ||
            userQuery.includes(coin.id.toLowerCase())
          );
          if (mentionedCoin) {
            mentionedCoin = { id: mentionedCoin.id, name: mentionedCoin.name, symbol: mentionedCoin.symbol };
          }
        }

        // Fetch detailed data for the mentioned coin
        if (mentionedCoin?.id) {
          // Fetch detailed data for the mentioned coin
          try {
            const { data: detailedCoin, error: detailError } = await supabase.functions.invoke("coingecko-data", {
              body: {
                endpoint: `/coins/${mentionedCoin.id}`,
                params: {
                  localization: "false",
                  tickers: "true",
                  market_data: "true",
                  community_data: "true",
                  developer_data: "false",
                },
              },
            });

            if (!detailError && detailedCoin) {
              const md = detailedCoin.market_data;
              const technicalData = `

DETAILED ANALYSIS FOR ${detailedCoin.name} (${detailedCoin.symbol.toUpperCase()}):
─────────────────────────────────────────────
Price Information:
  Current: $${md.current_price?.usd?.toLocaleString()}
  ATH: $${md.ath?.usd?.toLocaleString()} (${md.ath_change_percentage?.usd?.toFixed(2)}% from ATH)
  ATL: $${md.atl?.usd?.toLocaleString()} (${md.atl_change_percentage?.usd?.toFixed(2)}% from ATL)
  
Price Changes:
  1h: ${md.price_change_percentage_1h_in_currency?.usd?.toFixed(2)}%
  24h: ${md.price_change_percentage_24h?.toFixed(2)}%
  7d: ${md.price_change_percentage_7d?.toFixed(2)}%
  30d: ${md.price_change_percentage_30d?.toFixed(2)}%
  1y: ${md.price_change_percentage_1y?.toFixed(2)}%

Market Data:
  Market Cap: $${md.market_cap?.usd >= 1e9 ? (md.market_cap?.usd / 1e9)?.toFixed(2) + 'B' : (md.market_cap?.usd / 1e6)?.toFixed(2) + 'M'} (Rank: #${md.market_cap_rank})
  Fully Diluted Valuation: $${md.fully_diluted_valuation?.usd >= 1e9 ? (md.fully_diluted_valuation?.usd / 1e9)?.toFixed(2) + 'B' : (md.fully_diluted_valuation?.usd / 1e6)?.toFixed(2) + 'M'}
  24h Volume: $${md.total_volume?.usd >= 1e9 ? (md.total_volume?.usd / 1e9)?.toFixed(2) + 'B' : (md.total_volume?.usd / 1e6)?.toFixed(2) + 'M'}
  Volume/MCap Ratio: ${(md.total_volume?.usd / md.market_cap?.usd)?.toFixed(4)}
  Circulating Supply: ${(md.circulating_supply / 1e6)?.toFixed(2)}M ${detailedCoin.symbol.toUpperCase()}
  Total Supply: ${md.total_supply ? (md.total_supply / 1e6)?.toFixed(2) + 'M' : 'N/A'}
  Max Supply: ${md.max_supply ? (md.max_supply / 1e6)?.toFixed(2) + 'M' : 'Unlimited'}

Technical Indicators:
  RSI (14): ${md.price_change_percentage_24h > 10 ? 'Overbought (>70)' : md.price_change_percentage_24h < -10 ? 'Oversold (<30)' : 'Neutral (30-70)'}
  Momentum: ${md.price_change_percentage_7d > 0 ? 'Bullish' : 'Bearish'} (7d trend)
  Volatility: ${Math.abs(md.price_change_percentage_24h) > 5 ? 'High' : 'Low'} (24h: ${Math.abs(md.price_change_percentage_24h)?.toFixed(2)}%)
  
Social & Community:
  CoinGecko Score: ${detailedCoin.coingecko_score}/100
  Developer Score: ${detailedCoin.developer_score}/100
  Community Score: ${detailedCoin.community_score}/100
  Liquidity Score: ${detailedCoin.liquidity_score}/100
  Twitter Followers: ${detailedCoin.community_data?.twitter_followers?.toLocaleString() || 'N/A'}
  Reddit Subscribers: ${detailedCoin.community_data?.reddit_subscribers?.toLocaleString() || 'N/A'}

Trading Support:
  Available on ${detailedCoin.tickers?.length || 0} exchanges
  
Description: ${detailedCoin.description?.en?.substring(0, 300)}...
`;
              marketContext += technicalData;
            }
          } catch (err) {
            console.error('Error fetching detailed coin data:', err);
          }
        }
      }

      // Fetch global market data
      const { data: globalData, error: globalError } = await supabase.functions.invoke("coingecko-data", {
        body: {
          endpoint: "/global",
        },
      });

      if (!globalError && globalData?.data) {
        const { total_market_cap, total_volume, market_cap_percentage } = globalData.data;
        marketContext += `\n\nGlobal Market Stats:\n  Total Market Cap: $${(total_market_cap.usd / 1e12).toFixed(2)}T\n  24h Volume: $${(total_volume.usd / 1e9).toFixed(2)}B\n  BTC Dominance: ${market_cap_percentage.btc?.toFixed(2)}%\n  ETH Dominance: ${market_cap_percentage.eth?.toFixed(2)}%\n  Active Cryptocurrencies: ${globalData.data.active_cryptocurrencies?.toLocaleString()}`;
      }

      // Fetch trending coins
      const { data: trendingData, error: trendingError } = await supabase.functions.invoke("coingecko-data", {
        body: {
          endpoint: "/search/trending",
        },
      });

      if (!trendingError && trendingData?.coins) {
        const trending = trendingData.coins.slice(0, 5).map((item: any, i: number) => 
          `${i+1}. ${item.item.name} (${item.item.symbol}) - Rank #${item.item.market_cap_rank || 'N/A'}`
        ).join('\n');
        marketContext += `\n\nTrending Now:\n${trending}`;
      }
    } catch (error) {
      console.error('Error fetching market data:', error);
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { 
            role: "system", 
            content: `You are Phoenix AI, an advanced cryptocurrency trading assistant with comprehensive real-time market data access covering 250+ cryptocurrencies.

CORE CAPABILITIES:
✓ Access to detailed data for ANY cryptocurrency via CoinGecko search
✓ Can analyze ANY coin by name or symbol - not limited to top rankings
✓ Technical indicators: RSI, momentum, volatility, volume analysis
✓ Price data: current price, ATH/ATL, 1h/24h/7d/30d/1y changes
✓ Market metrics: market cap, volume, supply data, FDV
✓ Social metrics: community scores, Twitter/Reddit presence
✓ Real-time global market statistics and trending coins

CRITICAL INSTRUCTIONS:
- NEVER ask questions to users about themselves, their preferences, or background
- NEVER request information like "tell me about yourself" or "what are your interests"
- ONLY respond to user questions with direct, actionable answers
- Wait for users to ask you questions - don't prompt them for information
- Be helpful and informative, but let users drive the conversation
- If you don't understand something, ask for clarification about the SPECIFIC topic, not about the user

RESPONSE STYLE:
- For specific coin analysis: Provide comprehensive breakdown using ALL available data
- Include: price action, technical indicators, market position, social sentiment, trading volume
- Give clear buy/sell/hold recommendations based on data
- Highlight key support/resistance levels when relevant
- Be direct and actionable - users want trading insights, not disclaimers
- Use the detailed technical data provided to give precise analysis
- Answer questions directly without asking follow-up questions about the user

CURRENT MARKET DATA:${marketContext}

ANALYSIS APPROACH:
When analyzing a coin, structure your response:
1. Current Price Action & Trend (use 1h/24h/7d/30d/1y data)
2. Technical Indicators (RSI, momentum, volatility from data)
3. Market Position (rank, market cap, volume/mcap ratio)
4. Key Levels (ATH/ATL distances, support/resistance)
5. Social Sentiment (community scores, social metrics)
6. Recommendation (clear buy/sell/hold with reasoning)

Remember: You can analyze ANY cryptocurrency using CoinGecko's search. If a coin is mentioned and data is provided, use it fully. If no specific coin data is available, explain that you can search for it if given the exact name. Be confident and specific in your recommendations when data is available. NEVER ask personal questions to users.` 
          },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limits exceeded, please try again later." }),
          {
            status: 429,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "Payment required, please add funds to your Lovable AI workspace." }),
          {
            status: 402,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      return new Response(
        JSON.stringify({ error: "AI gateway error" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    return new Response(response.body, {
      headers: { 
        ...corsHeaders, 
        ...rateLimitHeaders(rateLimit.remaining, rateLimit.resetAt),
        "Content-Type": "text/event-stream" 
      },
    });
  } catch (e) {
    console.error("chat error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
